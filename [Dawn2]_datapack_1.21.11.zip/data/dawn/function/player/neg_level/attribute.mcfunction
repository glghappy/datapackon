# 挖掘速度降低
execute store result storage dawn:player block_break_speed double 0.02 run scoreboard players get @s dawn.player.neg_level
function dawn:player/neg_level/block_break_speed with storage dawn:player

# 攻击伤害降低
execute store result storage dawn:player attack_damage double 0.01 run scoreboard players get @s dawn.player.neg_level
function dawn:player/neg_level/attack_damage with storage dawn:player

# # 移动速度降低
# execute store result storage dawn:player movement_speed double 0.01 run scoreboard players get @s dawn.player.neg_level
# function dawn:player/neg_level/movement_speed with storage dawn:player
