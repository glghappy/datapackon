
tag @s add summon

execute if items entity @s weapon.mainhand iron_axe[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:weapon/vindicator
