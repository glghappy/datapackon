scoreboard players reset @s time

execute store result score @s dawn.time.h run time query daytime
execute store result score @s dawn.time.m run time query daytime

scoreboard players operation @s dawn.time.h /= #1000 dawn.time.h
scoreboard players add @s dawn.time.h 6

execute if score @s dawn.time.h matches 24.. run scoreboard players remove @s dawn.time.h 24

scoreboard players operation @s dawn.time.m %= #1000 dawn.time.h
scoreboard players operation @s dawn.time.m /= #17 dawn.time.m

# 播报
tellraw @s [{"translate": "broadcast.dawn.time", "color": "white", "italic": false,"with": [{"score": {"name": "@s","objective": "dawn.time.h"}},{"score": {"name": "@s","objective": "dawn.time.m"}}]}]
