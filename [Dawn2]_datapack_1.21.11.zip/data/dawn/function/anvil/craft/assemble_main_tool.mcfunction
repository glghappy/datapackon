
# 获取头部材质
data modify storage dawn:anvil_item_model head_material set from block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".material.type

# 获取工具类型
data modify storage dawn:anvil_item_model head_type set from block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".item.type

# 获取手柄材质
data remove storage dawn:anvil_item_model handle_type

execute if data block ~ ~ ~ {Items:[{Slot:13b, components:{"minecraft:custom_data":{"item": {"category": "component", "type": "stick"}}}}]} run data modify storage dawn:anvil_item_model handle_type set from block ~ ~ ~ Items.[{Slot: 13b}].components."minecraft:custom_data".material.type

execute if predicate dawn:anvil/material/handle/stick run data modify storage dawn:anvil_item_model handle_type set value 'wooden'
execute if predicate dawn:anvil/material/handle/bamboo run data modify storage dawn:anvil_item_model handle_type set value 'bamboo'
execute if predicate dawn:anvil/material/handle/bone run data modify storage dawn:anvil_item_model handle_type set value 'bone'
execute if predicate dawn:anvil/material/handle/poison_bone run data modify storage dawn:anvil_item_model handle_type set value 'poison_bone'
execute if predicate dawn:anvil/material/handle/wither_bone run data modify storage dawn:anvil_item_model handle_type set value 'wither_bone'
execute if predicate dawn:anvil/material/handle/blaze_rod run data modify storage dawn:anvil_item_model handle_type set value 'blaze'
execute if predicate dawn:anvil/material/handle/breeze_rod run data modify storage dawn:anvil_item_model handle_type set value 'breeze'
execute if predicate dawn:anvil/material/handle/obsidian_stick run data modify storage dawn:anvil_item_model handle_type set value 'obsidian'
execute if predicate dawn:anvil/material/handle/netherite_stick run data modify storage dawn:anvil_item_model handle_type set value 'netherite'

# 合成物品
# execute if predicate dawn:anvil/material/handle/is_handle run 
function dawn:anvil/craft/assemble_loot_tool with storage dawn:anvil_item_model
