
# 取值范围0~750
execute store result score @s dawn.enchantment.eternal_frost run attribute @s movement_speed get -10000
scoreboard players add @s dawn.enchantment.eternal_frost 1000
scoreboard players set @s[scores={dawn.enchantment.eternal_frost=..-1}] dawn.enchantment.eternal_frost 0
scoreboard players set @s[scores={dawn.enchantment.eternal_frost=751..}] dawn.enchantment.eternal_frost 750
