
execute if items block ~ ~ ~ container.19 *[item_model="dawn:blaze_coal"] run return 1

execute if score @s dawn.smeltery.fuel_level matches 4..4 run return 1
