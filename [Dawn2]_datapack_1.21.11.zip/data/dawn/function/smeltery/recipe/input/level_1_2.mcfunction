
# execute if function dawn:smeltery/recipe/copper_vanilla run return 1
# execute if function dawn:smeltery/recipe/gold_vanilla run return 1

# execute if function dawn:smeltery/recipe/copper run return 1
# execute if function dawn:smeltery/recipe/gold run return 1
# execute if function dawn:smeltery/recipe/iron run return 1
# execute if function dawn:smeltery/recipe/steel run return 1
# execute if function dawn:smeltery/recipe/rose_gold run return 1
# execute if function dawn:smeltery/recipe/ancient_metal run return 1
# execute if function dawn:smeltery/recipe/mithril run return 1

execute if function dawn:smeltery/recipe/input/level_1 run return 1
execute if function dawn:smeltery/recipe/input/level_2 run return 1