
$data modify entity @s item.components."minecraft:item_model" set value 'dawn:$(anvil_material)_$(anvil_type)'
