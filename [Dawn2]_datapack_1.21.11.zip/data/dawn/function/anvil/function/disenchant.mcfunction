
# 显示成品

# 复制物品
item replace block ~ ~ ~ container.16 from block ~ ~ ~ container.10

# 移除附魔
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:enchantments"

# 恢复初始附魔
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:enchantments" set from block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".initial_enchantments

# =合并刻印附魔=
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:enchantments" merge from block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".engrave_enchantments

# 恢复强化槽
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".enhancement_slot set from block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".quality.base_enhancement_slot

# 修改强化槽 ($enhancement)
execute store result storage dawn:input enhancement int 1 run data get block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".enhancement_slot
function dawn:anvil/function/modify_enhancement_slot with storage dawn:input

# 重置锻造宝石
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".experience_crystal.cost set value 1

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_disenchant set value true

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
