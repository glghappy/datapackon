advancement revoke @s only dawn:consume_item/cooked_beef

scoreboard players add @s dawn.player.protein 80704
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000
