
# 获取经验水晶需求量
scoreboard objectives add dawn.anvil.item.experience_crystal dummy
execute store result score @s dawn.anvil.item.experience_crystal run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".experience_crystal.cost


# 获取原料份数 (dawn.anvil.item.count)
scoreboard objectives add dawn.anvil.item.count dummy
execute store result score @s dawn.anvil.item.count run data get block ~ ~ ~ Items[{Slot:13b}].count

# 对比
execute if score @s dawn.anvil.item.experience_crystal <= @s dawn.anvil.item.count run function dawn:anvil/function/crystal_forge3