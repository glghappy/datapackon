
# add
data modify entity @s Offers.Recipes append value {maxUses:1, sell:{count:1, id:"minecraft:stone"}, buy:{count:8, id:"minecraft:emerald"}, buyB:{count:64, id:"minecraft:rotten_flesh"}, priceMultiplier: 0.05f, xp:50}

loot replace entity @s armor.head loot dawn:twisted_flesh
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head
item replace entity @s armor.head with air