
scoreboard players remove @s[scores={dawn.enchantment.feral_fury.time=1..}] dawn.enchantment.feral_fury.time 1
scoreboard players reset @s[scores={dawn.enchantment.feral_fury.time=..0}] dawn.enchantment.feral_fury.effect

execute store result storage dawn:player enchantment_feral_fury_damage float 0.15 run scoreboard players get @s dawn.enchantment.feral_fury.effect

execute store result storage dawn:player enchantment_feral_fury_speed float 0.006 run scoreboard players get @s dawn.enchantment.feral_fury.effect

function dawn:enchantment/feral_fury_function with storage dawn:player
