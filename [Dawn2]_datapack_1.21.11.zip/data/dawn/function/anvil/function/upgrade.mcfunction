
# 获取品质和上限 （dawn.anvil.item.quality）（dawn.anvil.item.max_quality）
scoreboard objectives add dawn.anvil.item.quality dummy
execute store result score @s dawn.anvil.item.quality run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".quality.level
scoreboard objectives add dawn.anvil.item.max_quality dummy
execute store result score @s dawn.anvil.item.max_quality run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".quality.max_level

# 可以升级
# execute if score @s dawn.anvil.item.quality < @s dawn.anvil.item.max_quality run say canquality
execute if score @s dawn.anvil.item.quality < @s dawn.anvil.item.max_quality run function dawn:anvil/function/upgrade2

