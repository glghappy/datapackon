
$execute unless data entity @s {item:{components:{"minecraft:custom_data":{input:$(input_before)}}}} run function dawn:smeltery/input_change
