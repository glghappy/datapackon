
$damage @s $(bleeding) dawn:bleeding