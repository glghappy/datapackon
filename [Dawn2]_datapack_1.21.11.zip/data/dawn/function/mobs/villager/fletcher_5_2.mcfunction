
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:stone"}, buy:{count:2, id:"minecraft:emerald"}, buyB:{count:5, id:"minecraft:arrow"}, priceMultiplier: 0.05f, xp:30}
loot replace entity @s armor.head loot dawn:weapon/tipped_arrow
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head
