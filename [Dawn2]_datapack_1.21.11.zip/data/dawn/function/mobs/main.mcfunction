
# 声音
function dawn:mobs/sound/main


# 村民
function dawn:mobs/villager/main


# 盔甲

# 召唤 + 属性修改 + 武器修改

    # 纯武器部分
    execute as @e[type=minecraft:drowned, tag=!summon] run function dawn:mobs/summon/drowned
    execute as @e[type=minecraft:vex, tag=!summon] run function dawn:mobs/summon/vex
    execute as @e[type=minecraft:vindicator, tag=!summon] run function dawn:mobs/summon/vindicator
    execute as @e[type=minecraft:illusioner, tag=!summon] run function dawn:mobs/summon/illusioner
    execute as @e[type=minecraft:pillager, tag=!summon] run function dawn:mobs/summon/pillager

    # 骷髅类
    execute as @e[type=minecraft:wither_skeleton, tag=!summon] at @s run function dawn:mobs/summon/wither_skeleton

    # 蜘蛛类
    execute as @e[type=minecraft:spider, tag=!summon] at @s run function dawn:mobs/summon/spider
    execute as @e[type=minecraft:cave_spider, tag=!summon] at @s run function dawn:mobs/summon/cave_spider

    # 僵尸类
    execute as @e[type=minecraft:zombie, tag=!summon] at @s run function dawn:mobs/summon/zombie
    execute as @e[type=minecraft:zombie_villager, tag=!summon] at @s run function dawn:mobs/summon/zombie_villager
    execute as @e[type=minecraft:husk, tag=!summon] at @s run function dawn:mobs/summon/husk

    # 召唤
    execute as @e[type=minecraft:creeper, tag=!summon] at @s run function dawn:mobs/summon/creeper

    # 替换
    execute as @e[type=minecraft:mooshroom, tag=!summon] at @s run function dawn:mobs/summon/mooshroom

    # 召唤 + 属性
    execute as @e[type=minecraft:enderman, tag=!summon] at @s run function dawn:mobs/summon/enderman

    # 纯属性修改
    execute as @e[type=minecraft:cow, tag=!summon] run function dawn:mobs/summon/cow
    execute as @e[type=minecraft:pig, tag=!summon] run function dawn:mobs/summon/pig
    execute as @e[type=minecraft:sheep, tag=!summon] run function dawn:mobs/summon/sheep
    execute as @e[type=minecraft:goat, tag=!summon] run function dawn:mobs/summon/goat
    execute as @e[type=minecraft:blaze, tag=!summon] run function dawn:mobs/summon/blaze

    # 属性 + 武器

    # 召唤 + 属性 + 武器
    execute as @e[type=minecraft:zombified_piglin, tag=!summon] at @s run function dawn:mobs/summon/zombified_piglin




# ————————————————————

# special effect
execute as @e[type=#dawn:zombies_transform, tag=ban_transform] run data modify entity @s InWaterTime set value -1
execute as @e[type=skeleton, tag=ban_transform] run data modify entity @s StrayConversionTime set value -1


# boss
execute as @e[tag=dark_mage] store result score @s dawn.entity.health run data get entity @s Health


# twisted_flesh
execute as @e[tag=dawn.twisted_flesh, type=glow_item_frame] at @s run function dawn:mobs/twisted_flesh/place
execute as @e[type=item_display, tag=dawn.twisted_flesh] at @s run function dawn:mobs/twisted_flesh/main

# boss
execute as @e[type=zombie, tag=boss] run data modify entity @s InWaterTime set value -1
execute as @e[type=zombie, tag=boss] run weather thunder 8s

# corrupt_bleeding_weeper
bossbar set corrupt_bleeding_weeper players
execute as @e[tag=corrupt_bleeding_weeper] at @s run function dawn:mobs/boss/corrupt_bleeding_weeper

# wither
execute as @e[type=wither, tag=!summon] run function dawn:mobs/boss/wither_summon
execute as @e[type=wither, tag=summon] at @s run function dawn:mobs/boss/wither_main
execute at @e[type=wither, tag=crazy_wither] as @n[type=wither_skull, tag=!tagged] run function dawn:mobs/boss/crazy_wither_skill

# ender_dragon
execute as @e[type=ender_dragon, tag=!summon] run function dawn:mobs/boss/ender_dragon_summon
execute as @e[type=dragon_fireball, tag=!tagged] at @s run function dawn:mobs/boss/ender_dragon_skill