
tag @s add summon

attribute @s minecraft:max_health base set 12
data modify entity @s Health set value 12
