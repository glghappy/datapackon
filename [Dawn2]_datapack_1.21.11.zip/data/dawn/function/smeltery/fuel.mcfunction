
$scoreboard players set @s dawn.smeltery.fuel_time $(fuel_time)

$scoreboard players set @s dawn.smeltery.fuel_level $(fuel_level)

execute unless items block ~ ~ ~ container.19 lava_bucket run item modify block ~ ~ ~ container.19 dawn:remove_1

execute if items block ~ ~ ~ container.19 lava_bucket run item replace block ~ ~ ~ container.19 with bucket
