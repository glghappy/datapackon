
scoreboard players add @s dawn.enchantment.kinetic_absorption 1
scoreboard players set @s[scores={dawn.enchantment.kinetic_absorption=21..}] dawn.enchantment.kinetic_absorption 20
