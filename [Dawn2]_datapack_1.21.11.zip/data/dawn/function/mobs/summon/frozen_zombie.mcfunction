
# Frozen Zombie 冻尸 (ban_transform)
summon minecraft:zombie ~ ~ ~ {CustomName: "Frozen Zombie", Tags: ["summon", "ban_transform", "equipment_summon", "frozen_zombie"], Health: 20.0f, equipment: {feet: {components: {"!minecraft:attribute_modifiers": {}, "!minecraft:enchantable": {}, "minecraft:equippable": {equip_sound: "minecraft:intentionally_empty", slot: "feet", asset_id: "dawn:air"}, "!minecraft:repairable": {}, "minecraft:enchantments": {"minecraft:binding_curse": 1, "minecraft:freezing_immunity": 1}, "!minecraft:max_damage": {}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_model": {}, "!minecraft:item_name": {}, "!minecraft:damage": {}}, count: 1, id: "minecraft:leather_boots"}}, drop_chances: {head: 0.0f, mainhand: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, CanBreakDoors: 1b, CanPickUpLoot: 1b, attributes: [{id: "minecraft:follow_range", base: 40.0d}, {id: "minecraft:movement_speed", base: 0.23d}, {id: "minecraft:armor", base: 5.0d}], DeathLootTable: "dawn:entities/frozen_zombie"}

tp @s ~ -255 ~

kill @s