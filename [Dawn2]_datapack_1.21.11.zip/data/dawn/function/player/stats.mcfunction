scoreboard players reset @s stats

tellraw @s [{"text": "----------------------------------------"}]

# day [参照day/check]

# 不是血月
execute if score #day dawn.day matches 0 run \
tellraw @s [{"translate": "broadcast.dawn.day", "color": "white", "italic": false,"with": [{"score": {"name": "#day","objective": "dawn.day"}}]}]

execute unless score #calculate1 dawn.day matches 0 run \
tellraw @s [{"translate": "broadcast.dawn.day", "color": "white", "italic": false,"with": [{"score": {"name": "#day","objective": "dawn.day"}}]}]

# 是血月
execute unless score #day dawn.day matches 0 \
unless score #calculate2 dawn.day matches 0 \
if score #calculate1 dawn.day matches 0 \
run \
tellraw @s [{"translate": "broadcast.dawn.day", "color": "red", "italic": false,"with": [{"score": {"name": "#day","objective": "dawn.day"}}]}]

# 是蓝月
execute unless score #day dawn.day matches 0 \
if score #calculate2 dawn.day matches 0 \
run \
tellraw @s [{"translate": "broadcast.dawn.day", "color": "#0088ff", "italic": false,"with": [{"score": {"name": "#day","objective": "dawn.day"}}]}]



# nutrition
scoreboard players set #1600 dawn.player.value 1600
scoreboard players set #480 dawn.player.value 480

scoreboard players operation @s dawn.player.protein2 = @s dawn.player.protein
scoreboard players operation @s dawn.player.protein2 /= #1600 dawn.player.value

scoreboard players operation @s dawn.player.phytonutrients2 = @s dawn.player.phytonutrients
scoreboard players operation @s dawn.player.phytonutrients2 /= #1600 dawn.player.value

scoreboard players operation @s dawn.player.insulin2 = @s dawn.player.insulin
scoreboard players operation @s dawn.player.insulin2 /= #480 dawn.player.value

tellraw @s [{"translate": "broadcast.dawn.protein", "color": "gold", "italic": false,"with": [{"score": {"name": "@s","objective": "dawn.player.protein"}},{"score": {"name": "@s","objective": "dawn.player.protein2"}}]}]
tellraw @s [{"translate": "broadcast.dawn.phytonutrients", "color": "green", "italic": false,"with": [{"score": {"name": "@s","objective": "dawn.player.phytonutrients"}},{"score": {"name": "@s","objective": "dawn.player.phytonutrients2"}}]}]
tellraw @s [{"translate": "broadcast.dawn.insulin", "color": "dark_purple", "italic": false,"with": [{"score": {"name": "@s","objective": "dawn.player.insulin"}},{"score": {"name": "@s","objective": "dawn.player.insulin2"}}]}]



tellraw @s [{"text": "----------------------------------------"}]
