
# 初始化
execute as @e[type=end_crystal] at @s if dimension minecraft:the_end if entity @e[type=ender_dragon] unless entity @n[type=marker, distance=..0.5, tag=end_crystal] run summon marker ~ ~ ~ {Tags:["end_crystal"]}

# 水晶保护
execute as @e[type=end_crystal, tag=!protect] at @s if dimension minecraft:the_end if entity @e[type=ender_dragon] unless entity @n[type=shulker, distance=..0.5, tag=end_crystal] run function dawn:end_crystal/protect

# effect
execute as @e[type=marker, tag=end_crystal] at @s run function dawn:end_crystal/effect