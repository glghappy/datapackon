
advancement revoke @s only dawn:enchantment/surging_remove_1

scoreboard players remove @s dawn.enchantment.surging 4
scoreboard players set @s[scores={dawn.enchantment.surging=..-1}] dawn.enchantment.surging 0
