
tag @s add sell_2

# 3
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:26, id:"minecraft:flint"}, priceMultiplier: 0.05f, demand:-12, xp:10}

# 4
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:stone"}, buy:{count:2, id:"minecraft:emerald"}, priceMultiplier: 0.05f, demand:-12, xp:5}
loot replace entity @s armor.head loot dawn:bow/copper_bow
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head


item replace entity @s armor.head with air
