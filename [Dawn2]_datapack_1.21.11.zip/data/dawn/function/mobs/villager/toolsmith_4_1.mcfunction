
data modify entity @s Offers.Recipes[-1] set value {maxUses:6, sell:{count:1, id:"minecraft:stone"}, buy:{count:13, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:15}
loot replace entity @s armor.head loot dawn:tool/steel_wooden_war_hammer
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head
