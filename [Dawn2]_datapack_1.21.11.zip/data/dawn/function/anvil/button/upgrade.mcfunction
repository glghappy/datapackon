
# 检测是否强化成功


# 失败
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_quality_fail:1b}}}] run function dawn:anvil/button/upgrade_fail

# 成功
execute unless data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_quality_fail:1b}}}] run function dawn:anvil/button/upgrade_success


