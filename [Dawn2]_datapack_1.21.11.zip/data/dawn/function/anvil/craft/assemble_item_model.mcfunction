
$data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:item_model" set value "dawn:$(head_material)_$(handle)_$(head_type)"
