
#
tag @s add summon

# Snow Spider 雪蛛
execute if biome ~ ~ ~ #minecraft:spawns_cold_variant_farm_animals run return run function dawn:mobs/summon/snow_spider

# Sand Spider 沙蛛
execute if biome ~ ~ ~ #minecraft:spawns_gold_rabbits run return run function dawn:mobs/summon/sand_spider

# Black Widow Spider 黑寡妇蜘蛛
execute if predicate dawn:random/0.3 if biome ~ ~ ~ #minecraft:is_jungle run return run function dawn:mobs/summon/black_widow_spider

# Jungle Spider 丛林蜘蛛
execute if biome ~ ~ ~ #minecraft:is_jungle run return run function dawn:mobs/summon/jungle_spider

# Wood Spider 木蜘蛛
execute if predicate dawn:random/0.4 if biome ~ ~ ~ #minecraft:is_forest run return run function dawn:mobs/summon/wood_spider

# Night Spider 夜蛛
execute if predicate dawn:random/0.3 if dimension dawn:underworld run return run function dawn:mobs/summon/night_spider
execute if predicate dawn:random/0.2 if dimension minecraft:overworld if predicate dawn:location/deepslate_cave run return run function dawn:mobs/summon/night_spider

# Phase Spider 相位蜘蛛 (silent)
execute if predicate dawn:random/0.3 if dimension dawn:underworld run return run function dawn:mobs/summon/phase_spider
execute if predicate dawn:random/0.2 if dimension minecraft:overworld if predicate dawn:location/deepslate_cave run return run function dawn:mobs/summon/phase_spider

# Demon Spider 恶魔蜘蛛
execute if predicate dawn:random/0.2 if dimension dawn:underworld run return run function dawn:mobs/summon/demon_spider
execute if predicate dawn:random/0.1 if dimension minecraft:overworld if predicate dawn:location/deepslate_cave run return run function dawn:mobs/summon/demon_spider


#
attribute @s max_health base set 10
data modify entity @s Health set value 10