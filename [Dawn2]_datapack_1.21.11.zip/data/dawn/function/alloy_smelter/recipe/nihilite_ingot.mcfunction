# 排列 1: 槽位顺序 (container.1 -> container.2 -> container.3)
execute \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.3 minecraft:wither_rose[count=2] \
run return 1

# 排列 2: 槽位顺序 (container.1 -> container.3 -> container.2)
execute \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.2 minecraft:wither_rose[count=2] \
run return 1

# 排列 3: 槽位顺序 (container.2 -> container.1 -> container.3)
execute \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.3 minecraft:wither_rose[count=2] \
run return 1

# 排列 4: 槽位顺序 (container.2 -> container.3 -> container.1)
execute \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.1 minecraft:wither_rose[count=2] \
run return 1

# 排列 5: 槽位顺序 (container.3 -> container.1 -> container.2)
execute \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.2 minecraft:wither_rose[count=2] \
run return 1

# 排列 6: 槽位顺序 (container.3 -> container.2 -> container.1)
execute \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.1 minecraft:wither_rose[count=2] \
run return 1

# 排列 7: 槽位顺序 (container.1 -> container.2 -> container.3)
execute \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.3 minecraft:wither_skeleton_skull[count=1] \
run return 1

# 排列 8: 槽位顺序 (container.1 -> container.3 -> container.2)
execute \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.2 minecraft:wither_skeleton_skull[count=1] \
run return 1

# 排列 9: 槽位顺序 (container.2 -> container.1 -> container.3)
execute \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.3 minecraft:wither_skeleton_skull[count=1] \
run return 1

# 排列 10: 槽位顺序 (container.2 -> container.3 -> container.1)
execute \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.1 minecraft:wither_skeleton_skull[count=1] \
run return 1

# 排列 11: 槽位顺序 (container.3 -> container.1 -> container.2)
execute \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.2 minecraft:wither_skeleton_skull[count=1] \
run return 1

# 排列 12: 槽位顺序 (container.3 -> container.2 -> container.1)
execute \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:ancient_metal_ingot"] \
if items block ~ ~ ~ container.1 minecraft:wither_skeleton_skull[count=1] \
run return 1

