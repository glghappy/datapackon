
# scoreboard players add @e[nbt={active_effects:[{id:"minecraft:poison"}]}] dawn.effect.poison 1
# scoreboard players add @e[nbt={active_effects:[{id:"minecraft:poison", amplifier:1b}]}] dawn.effect.poison 1
# scoreboard players add @e[nbt={active_effects:[{id:"minecraft:poison", amplifier:2b}]}] dawn.effect.poison 2
# scoreboard players add @e[nbt={active_effects:[{id:"minecraft:poison", amplifier:3b}]}] dawn.effect.poison 4

# scoreboard players reset @e[nbt=!{active_effects:[{id:"minecraft:poison"}]}] dawn.effect.poison


# scoreboard players reset @e[nbt={HurtTime:9s}] dawn.effect.poison





# by：Minecraft_hyr

scoreboard players reset @e[type=!#dawn:ignore_poison, scores={dawn.effect.poison=1..}, predicate=dawn:entity/poison/remove] dawn.effect.poison

execute as @e[type=!#dawn:ignore_poison, predicate=dawn:entity/poison/any] run function dawn:damage/poison_amplifier
