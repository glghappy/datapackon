
# 移除成品清除标记
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear


# 扣除材料
item replace block ~ ~ ~ container.10 with minecraft:air


# 记录砧耐久消耗 （dawn.anvil.item.operation）
scoreboard objectives add dawn.anvil.item.operation dummy
execute store result score @s dawn.anvil.item.operation run data get block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_damage


# 扣除锤子耐久
# 获取损坏值 （dawn.anvil.item.damage）
scoreboard objectives add dawn.anvil.item.damage dummy
scoreboard objectives add dawn.anvil.item.max_damage dummy
execute store result score @s dawn.anvil.item.damage run data get block ~ ~ ~ Items[{Slot:13b}].components."minecraft:damage"
execute store result score @s dawn.anvil.item.max_damage run data get block ~ ~ ~ Items[{Slot:13b}].components."minecraft:max_damage"
execute store result storage dawn:damage damage int 1 run scoreboard players operation @s dawn.anvil.item.damage += @s dawn.anvil.item.operation
# 扣除
data modify block ~ ~ ~ Items[{Slot:13b}].components."minecraft:damage" set from storage dawn:damage damage
# execute if score @s dawn.anvil.item.damage >= @s dawn.anvil.item.max_damage run item replace block ~ ~ ~ container.13 with minecraft:air
    # 特异性修复：工具耐久不能为250，否则会变为0
    # 1.最大耐久不为0时，正常
    execute if score @s dawn.anvil.item.damage >= @s dawn.anvil.item.max_damage unless score @s dawn.anvil.item.max_damage matches 1 run item replace block ~ ~ ~ container.13 with minecraft:air
    # 2.最大耐久为0时，当损伤大于250视为损坏
    execute if score @s dawn.anvil.item.damage matches 250.. if score @s dawn.anvil.item.max_damage matches 1 run item replace block ~ ~ ~ container.13 with minecraft:air
# tellraw @a {score:{name:"@s", objective:dawn.anvil.item.damage}}
# tellraw @a {score:{name:"@s", objective:dawn.anvil.item.max_damage}}

# 移除成品附加标记
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_double_ingot
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_damage


# 播放声音
playsound minecraft:block.anvil.use block @a ~ ~ ~


# 扣除铁砧耐久
function dawn:anvil/button/anvil_damage


# 耐久显示
function dawn:anvil/durability
