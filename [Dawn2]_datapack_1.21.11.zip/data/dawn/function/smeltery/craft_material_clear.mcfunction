
scoreboard players set @s dawn.smeltery.craft_finish 1000000

data remove entity @s item.components."minecraft:custom_data".output_material_1
data remove entity @s item.components."minecraft:custom_data".output_material_2
