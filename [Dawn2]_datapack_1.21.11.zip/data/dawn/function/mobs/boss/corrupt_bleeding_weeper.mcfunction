bossbar add corrupt_bleeding_weeper "悲血腐泪者"

bossbar set corrupt_bleeding_weeper color purple
execute as @s[tag=level2] run bossbar set corrupt_bleeding_weeper color red
execute as @s[tag=level2, nbt={active_effects:[{id:"minecraft:resistance", amplifier:4b}]}] run bossbar set corrupt_bleeding_weeper color yellow

execute as @a[distance=..32] run bossbar set corrupt_bleeding_weeper players @s
# execute as @a[distance=33..] run bossbar set corrupt_bleeding_weeper players

execute store result bossbar corrupt_bleeding_weeper value run data get entity @s Health
execute store result bossbar corrupt_bleeding_weeper max run attribute @s max_health get

execute store result score @s dawn.entity.health run data get entity @s Health