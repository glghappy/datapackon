
# Stone Creeper 石化苦力怕
execute if predicate dawn:random/0.2 run return run function dawn:mobs/summon/stone_creeper

# Shadow Creeper 暗影苦力怕
execute if predicate dawn:random/0.15 run return run function dawn:mobs/summon/shadow_creeper

# Infernal Creeper 地狱苦力怕
execute if predicate dawn:random/0.1 run return run function dawn:mobs/summon/infernal_creeper
