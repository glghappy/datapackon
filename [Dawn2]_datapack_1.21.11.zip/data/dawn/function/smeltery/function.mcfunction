
# -------------------------------------------------------------------------------------------------

# 检测原料体积 [dawn.smeltery.input]

execute store result score @s dawn.smeltery.input run function dawn:smeltery/recipe/input
execute store result score @s dawn.smeltery.input run function dawn:smeltery/recipe/copper_vanilla
execute store result score @s dawn.smeltery.input run function dawn:smeltery/recipe/gold_vanilla

scoreboard players operation @s dawn.smeltery.input *= @s dawn.smeltery.count

# -------------------------------------------------------------------------------------------------

# 展示可烧制部件并记录相应输出数据

execute if predicate dawn:smeltery/output/only_nugget run scoreboard players set @s[scores={dawn.smeltery.button=1..}] dawn.smeltery.button 0
execute if predicate dawn:smeltery/output/only_nugget run function dawn:smeltery/recipe/nugget
execute if score @s dawn.smeltery.input matches 10 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":1}


execute if score @s dawn.smeltery.input matches 90 run scoreboard players set @s[scores={dawn.smeltery.button=6..}] dawn.smeltery.button 5
execute if score @s dawn.smeltery.input matches 90 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":1}
execute if score @s dawn.smeltery.input matches 90 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":9}
execute if score @s dawn.smeltery.input matches 90 if score @s dawn.smeltery.button matches 2 run function dawn:smeltery/show_model {"folder": "component", "model": "hatchet", "name": "手斧", "count":1}
execute if score @s dawn.smeltery.input matches 90 if score @s dawn.smeltery.button matches 3 run function dawn:smeltery/show_model {"folder": "component", "model": "knife", "name": "小刀", "count":1}
execute if score @s dawn.smeltery.input matches 90 if score @s dawn.smeltery.button matches 4 run function dawn:smeltery/show_model {"folder": "component", "model": "shovel", "name": "锹", "count":1}
execute if score @s dawn.smeltery.input matches 90 if score @s dawn.smeltery.button matches 5 run function dawn:smeltery/show_model {"folder": "component", "model": "stick", "name": "棒", "count":1}


execute if score @s dawn.smeltery.input matches 180 run scoreboard players set @s[scores={dawn.smeltery.button=7..}] dawn.smeltery.button 6
execute if score @s dawn.smeltery.input matches 180 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":2}
execute if score @s dawn.smeltery.input matches 180 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":18}
execute if score @s dawn.smeltery.input matches 180 if score @s dawn.smeltery.button matches 2 run function dawn:smeltery/show_model {"folder": "component", "model": "halberd", "name": "戟", "count":1}
execute if score @s dawn.smeltery.input matches 180 if score @s dawn.smeltery.button matches 3 run function dawn:smeltery/show_model {"folder": "component", "model": "hoe", "name": "锄", "count":1}
execute if score @s dawn.smeltery.input matches 180 if score @s dawn.smeltery.button matches 4 run function dawn:smeltery/show_model {"folder": "component", "model": "longsword", "name": "长剑", "count":1}
execute if score @s dawn.smeltery.input matches 180 if score @s dawn.smeltery.button matches 5 run function dawn:smeltery/show_model {"folder": "component", "model": "scythe", "name": "镰刀", "count":1}
execute if score @s dawn.smeltery.input matches 180 if score @s dawn.smeltery.button matches 6 run function dawn:smeltery/show_model {"folder": "component", "model": "sword", "name": "剑", "count":1}


execute if score @s dawn.smeltery.input matches 270 run scoreboard players set @s[scores={dawn.smeltery.button=5..}] dawn.smeltery.button 4
execute if score @s dawn.smeltery.input matches 270 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":3}
execute if score @s dawn.smeltery.input matches 270 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":27}
execute if score @s dawn.smeltery.input matches 270 if score @s dawn.smeltery.button matches 2 run function dawn:smeltery/show_model {"folder": "component", "model": "axe", "name": "斧", "count":1}
execute if score @s dawn.smeltery.input matches 270 if score @s dawn.smeltery.button matches 3 run function dawn:smeltery/show_model {"folder": "bow_limb", "model": "bow_limb", "name": "弓臂", "count":1}
execute if score @s dawn.smeltery.input matches 270 if score @s dawn.smeltery.button matches 4 run function dawn:smeltery/show_model {"folder": "component", "model": "pickaxe", "name": "镐", "count":1}


execute if score @s dawn.smeltery.input matches 360 run scoreboard players set @s[scores={dawn.smeltery.button=5..}] dawn.smeltery.button 4
execute if score @s dawn.smeltery.input matches 360 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":4}
execute if score @s dawn.smeltery.input matches 360 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":36}
execute if score @s dawn.smeltery.input matches 360 if score @s dawn.smeltery.button matches 2 run function dawn:smeltery/show_model {"folder": "component", "model": "battle_axe", "name": "战斧", "count":1}
execute if score @s dawn.smeltery.input matches 360 if score @s dawn.smeltery.button matches 3 run function dawn:smeltery/show_model {"folder": "plating", "model": "boots", "name": "靴子", "count":1}
execute if score @s dawn.smeltery.input matches 360 if score @s dawn.smeltery.button matches 4 run function dawn:smeltery/show_model {"folder": "component", "model": "mattock", "name": "鹤嘴锄", "count":1}


execute if score @s dawn.smeltery.input matches 450 run scoreboard players set @s[scores={dawn.smeltery.button=4..}] dawn.smeltery.button 3
execute if score @s dawn.smeltery.input matches 450 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":5}
execute if score @s dawn.smeltery.input matches 450 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":45}
execute if score @s dawn.smeltery.input matches 450 if score @s dawn.smeltery.button matches 2 run function dawn:smeltery/show_model {"folder": "plating", "model": "helmet", "name": "头盔", "count":1}
execute if score @s dawn.smeltery.input matches 450 if score @s dawn.smeltery.button matches 3 run function dawn:smeltery/show_model {"folder": "component", "model": "war_hammer", "name": "战锤", "count":1}


execute if score @s dawn.smeltery.input matches 540 run scoreboard players set @s[scores={dawn.smeltery.button=2..}] dawn.smeltery.button 1
execute if score @s dawn.smeltery.input matches 540 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":6}
execute if score @s dawn.smeltery.input matches 540 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":54}


execute if score @s dawn.smeltery.input matches 630 run scoreboard players set @s[scores={dawn.smeltery.button=3..}] dawn.smeltery.button 2
execute if score @s dawn.smeltery.input matches 630 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":7}
execute if score @s dawn.smeltery.input matches 630 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":63}
execute if score @s dawn.smeltery.input matches 630 if score @s dawn.smeltery.button matches 2 run function dawn:smeltery/show_model {"folder": "plating", "model": "leggings", "name": "护腿", "count":1}


execute if score @s dawn.smeltery.input matches 720 run scoreboard players set @s[scores={dawn.smeltery.button=2..}] dawn.smeltery.button 1
execute if score @s dawn.smeltery.input matches 720 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":8}
execute if score @s dawn.smeltery.input matches 720 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "plating", "model": "chestplate", "name": "胸甲", "count":1}


execute if score @s dawn.smeltery.input matches 810 run scoreboard players set @s[scores={dawn.smeltery.button=2..}] dawn.smeltery.button 1
execute if score @s dawn.smeltery.input matches 810 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":9}
execute if score @s dawn.smeltery.input matches 810 if score @s dawn.smeltery.button matches 1 run function dawn:smeltery/show_model {"folder": "block", "model": "block", "name": "块", "count":1}
