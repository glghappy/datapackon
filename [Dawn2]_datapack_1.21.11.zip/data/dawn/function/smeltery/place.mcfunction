# cobblestone → 1
# obsidian → 2
# netherrack → 3

# cobblestone
execute as @s[tag=dawn.cobblestone] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:cobblestone_smeltery", custom_data:{smeltery:{material:cobblestone}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.smeltery", "dawn.cobblestone", "smelterylevel.1"], view_range:8}
execute as @s[tag=dawn.cobblestone] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.cobblestone_smeltery"}} replace

# obsidian
execute as @s[tag=dawn.obsidian] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:obsidian_smeltery", custom_data:{smeltery:{material:obsidian}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.smeltery", "dawn.obsidian", "smelterylevel.2"], view_range:8}
execute as @s[tag=dawn.obsidian] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.obsidian_smeltery"}} replace

# netherrack
execute as @s[tag=dawn.netherrack] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:netherrack_smeltery", custom_data:{smeltery:{material:netherrack}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.smeltery", "dawn.netherrack", "smelterylevel.3"], view_range:8}
execute as @s[tag=dawn.netherrack] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.netherrack_smeltery"}} replace

# Rotation
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=-45..45] run data modify entity @s Rotation set value [180.0f, 0.0f]
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=45..135] run data modify entity @s Rotation set value [270.0f, 0.0f]
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=135..-135] run data modify entity @s Rotation set value [0.0f, 0.0f]
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=-135..-45] run data modify entity @s Rotation set value [90.0f, 0.0f]

# summon marker
execute align xyz positioned ~.5 ~.5 ~.5 run summon minecraft:marker ~ ~ ~ {Tags:["dawn.smeltery"]}

# 设置初始值
execute as @n[type=minecraft:item_display, distance=...5] run scoreboard players set @s dawn.smeltery.button -1
execute as @n[type=minecraft:item_display, distance=...5] run scoreboard players set @s dawn.smeltery.fuel_time 0

# kill
kill @s


# 数量检测
execute store result score #smeltery dawn.smeltery.check if entity @e[type=minecraft:item_display, tag=dawn.smeltery]
execute if score #smeltery dawn.smeltery.check matches 3.. run tellraw @p [{"translate": "broadcast.dawn.smeltery", "color": "red", "italic": false,"with": [{"score": {"name": "#smeltery","objective": "dawn.smeltery.check"}}]}]