
# 工具匠
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:toolsmith",level:1}},tag=!sell_1] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/toolsmith_1
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:toolsmith",level:2}},tag=!sell_2] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/toolsmith_2
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:toolsmith",level:3}},tag=!sell_3] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/toolsmith_3
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:toolsmith",level:4}},tag=!sell_4] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/toolsmith_4
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:toolsmith",level:5}},tag=!sell_5] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/toolsmith_5

# 盔甲匠
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:armorer",level:1}},tag=!sell_1] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/armorer_1
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:armorer",level:2}},tag=!sell_2] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/armorer_2
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:armorer",level:3}},tag=!sell_3] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/armorer_3
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:armorer",level:4}},tag=!sell_4] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/armorer_4
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:armorer",level:5}},tag=!sell_5] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/armorer_5

# 制箭师
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fletcher",level:2}},tag=!sell_2] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/fletcher_2
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fletcher",level:3}},tag=!sell_3] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/fletcher_3
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fletcher",level:4}},tag=!sell_4] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/fletcher_4
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fletcher",level:5}},tag=!sell_5] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/fletcher_5

# 皮匠
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:leatherworker",level:1}},tag=!sell_1] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/leatherworker_1
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:leatherworker",level:2}},tag=!sell_2] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/leatherworker_2
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:leatherworker",level:3}},tag=!sell_3] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/leatherworker_3
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:leatherworker",level:4}},tag=!sell_4] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/leatherworker_4
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:leatherworker",level:5}},tag=!sell_5] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/leatherworker_5

# 牧羊人
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:shepherd",level:1}},tag=!sell_1] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/shepherd_1

# 流浪商人
execute as @e[type=wandering_trader, tag=!sell_1] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/wandering_trader_1

# 图书管理员
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:librarian",level:5}},tag=!sell_5] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/librarian_5

# 牧师
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:cleric",level:5}},tag=!sell_5] at @s unless entity @s[nbt={NoAI:1b}] run function dawn:mobs/villager/cleric_5
