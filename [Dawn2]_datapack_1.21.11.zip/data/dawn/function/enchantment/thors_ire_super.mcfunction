
tag @s add thors_ire

execute as @s at @e[distance=..16, tag=!thors_ire, type=#dawn:hostile_mobs] run summon minecraft:lightning_bolt ~ ~ ~

execute as @e[distance=..16, tag=!thors_ire, type=#dawn:hostile_mobs] run effect give @s minecraft:slowness 4 4 true

tag @s remove thors_ire
