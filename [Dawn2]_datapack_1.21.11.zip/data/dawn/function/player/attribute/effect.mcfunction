
# 最大属性加成 等级
$scoreboard players set @s[scores={dawn.player.level.operation=$(max_level)..}] dawn.player.level.operation $(max_level)

# 基础触及距离
$attribute @s minecraft:block_interaction_range base set $(block_interaction_range)
$attribute @s minecraft:entity_interaction_range base set $(entity_interaction_range)

# 基础挖掘速度
$attribute @s minecraft:block_break_speed base set $(block_break_speed)
