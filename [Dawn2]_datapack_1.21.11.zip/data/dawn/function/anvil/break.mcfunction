# break barrel again
execute if block ~ ~ ~ barrel run setblock ~ ~ ~ air destroy

# durability 1.. (loot)
execute if score @s dawn.anvil.durability matches 1.. run function dawn:anvil/loot
# execute if score @s dawn.anvil.durability matches ..0 run playsound minecraft:block.anvil.destroy block @a ~ ~ ~

# modify Durability
data modify entity @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:glow_item_frame"}}] Item.components."minecraft:entity_data".Item.components.custom_data.anvil.durability set from entity @s item.components."minecraft:custom_data".anvil.durability

# 获取并修改掉落物damage
scoreboard objectives add dawn.anvil.damage dummy
scoreboard objectives add dawn.anvil.durability dummy
execute store result score @s dawn.anvil.damage run data get entity @n[type=minecraft:item_display] item.components."minecraft:custom_data".anvil.max_durability
execute store result score @s dawn.anvil.durability run data get entity @n[type=minecraft:item_display] item.components."minecraft:custom_data".anvil.durability
execute store result entity @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:glow_item_frame"}}] Item.components."minecraft:damage" int 1 run scoreboard players operation @s dawn.anvil.damage -= @s dawn.anvil.durability

# 修改掉落物纹理
data modify entity @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:glow_item_frame"}}] Item.components."minecraft:item_model" set from entity @s item.components."minecraft:item_model"

# kill item
execute as @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:barrel"}}] run kill @s

# kill self
kill @s

# playsound
# playsound block.anvil.break block @a ~ ~ ~