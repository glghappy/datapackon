
attribute @s max_health modifier remove enchantment.sectumsempra
attribute @s max_health modifier add enchantment.sectumsempra -8 add_value