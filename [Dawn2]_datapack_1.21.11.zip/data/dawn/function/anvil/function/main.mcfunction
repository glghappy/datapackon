
# 检测原料是否为烟火之星（1-是， 0-否）
scoreboard objectives add dawn.anvil.firework_check dummy
execute store success score @s dawn.anvil.firework_check run function dawn:anvil/function/firework_star_check


# 修复，检测材料（0-成功， 1-失败）
scoreboard objectives add dawn.anvil.repair_check dummy
data modify storage dawn:repair_material item set from block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".repair.item
execute if score @s dawn.anvil.firework_check matches 0 store success score @s dawn.anvil.repair_check run data modify storage dawn:repair_material item set from block ~ ~ ~ Items[{Slot:13b}].id
execute if score @s dawn.anvil.firework_check matches 1 store success score @s dawn.anvil.repair_check run data modify storage dawn:repair_material item set from block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".id
execute if score @s dawn.anvil.repair_check matches 0 run function dawn:anvil/function/repair


# 提升品质，检测材料（0-成功， 1-失败）
scoreboard objectives add dawn.anvil.upgrade_check dummy
data modify storage dawn:upgrade_material item set from block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".upgrade.item
execute if score @s dawn.anvil.firework_check matches 0 store success score @s dawn.anvil.upgrade_check run data modify storage dawn:upgrade_material item set from block ~ ~ ~ Items[{Slot:13b}].id
execute if score @s dawn.anvil.firework_check matches 1 store success score @s dawn.anvil.upgrade_check run data modify storage dawn:upgrade_material item set from block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".id
execute if score @s dawn.anvil.upgrade_check matches 0 run function dawn:anvil/function/upgrade


# 使用强化宝石，提升品质
# execute if predicate dawn:anvil/material/refining_gem run function dawn:anvil/function/poor_upgrade


# 附魔
function dawn:anvil/function/enchantment


# 祛魔
execute if predicate dawn:anvil/material/bottle_of_disenchanting run function dawn:anvil/function/disenchant


# 经验水晶
execute if predicate dawn:anvil/material/experience_crystal run function dawn:anvil/function/crystal_forge


# 发光
execute if predicate dawn:anvil/material/glow_ink_sac run function dawn:anvil/function/glow_up
execute if predicate dawn:anvil/material/ink_sac run function dawn:anvil/function/glow_down

