# 排列 1: 槽位顺序 (container.1 -> container.2 -> container.3)
execute \
if items block ~ ~ ~ container.1 *[count=4, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.2 minecraft:netherite_scrap[count=2] \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:steel_ingot"] \
run return 1

# 排列 2: 槽位顺序 (container.1 -> container.3 -> container.2)
execute \
if items block ~ ~ ~ container.1 *[count=4, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.3 minecraft:netherite_scrap[count=2] \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:steel_ingot"] \
run return 1

# 排列 3: 槽位顺序 (container.2 -> container.1 -> container.3)
execute \
if items block ~ ~ ~ container.2 *[count=4, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.1 minecraft:netherite_scrap[count=2] \
if items block ~ ~ ~ container.3 *[count=2, item_model="dawn:steel_ingot"] \
run return 1

# 排列 4: 槽位顺序 (container.2 -> container.3 -> container.1)
execute \
if items block ~ ~ ~ container.2 *[count=4, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.3 minecraft:netherite_scrap[count=2] \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:steel_ingot"] \
run return 1

# 排列 5: 槽位顺序 (container.3 -> container.1 -> container.2)
execute \
if items block ~ ~ ~ container.3 *[count=4, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.1 minecraft:netherite_scrap[count=2] \
if items block ~ ~ ~ container.2 *[count=2, item_model="dawn:steel_ingot"] \
run return 1

# 排列 6: 槽位顺序 (container.3 -> container.2 -> container.1)
execute \
if items block ~ ~ ~ container.3 *[count=4, item_model="dawn:vibranium_nugget"] \
if items block ~ ~ ~ container.2 minecraft:netherite_scrap[count=2] \
if items block ~ ~ ~ container.1 *[count=2, item_model="dawn:steel_ingot"] \
run return 1

