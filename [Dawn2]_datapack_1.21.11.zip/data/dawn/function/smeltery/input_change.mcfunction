
# 提示
# say "原料改变"

# 变化数量后，重置button值
scoreboard players set @s dawn.smeltery.button 0

# 重置烧炼状态
data modify entity @s item.components."minecraft:custom_data".smelting set value false

# 重置烧制进度
scoreboard players set @s dawn.smeltery.craft_time 0

# 重置部分GUI
execute as @n[tag=dawn.smeltery, type=marker] run function dawn:smeltery/gui_part
