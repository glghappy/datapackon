# scoreboard objectives add dawn.anvil.durability dummy
# scoreboard objectives add dawn.anvil.maxdurability dummy
# scoreboard objectives add dawn.anvil.durability.op dummy
# scoreboard players set 100 dawn.anvil.durability.op 100
# scoreboard objectives add dawn.anvil.custommodel dummy

# scoreboard objectives add dawn.anvil.item.durability dummy
# scoreboard objectives add dawn.anvil.item.maxdurability dummy
# scoreboard objectives add dawn.anvil.item.temp dummy
# scoreboard objectives add dawn.anvil.item.damage dummy
# scoreboard objectives add dawn.anvil.item.count dummy
# scoreboard objectives add dawn.anvil.item.operation dummy
# scoreboard objectives add dawn.anvil.item.operation2 dummy

# scoreboard objectives add dawn.anvil.item.quality dummy
# scoreboard objectives add dawn.anvil.item.maxquality dummy
# scoreboard objectives add dawn.anvil.item.quality.op dummy

# scoreboard objectives add dawn.anvil.item.enchant dummy
# scoreboard objectives add dawn.anvil.item.strength dummy
# scoreboard objectives add dawn.anvil.item.ability dummy

# scoreboard objectives add dawn.anvil.item.nbtlvl dummy

# scoreboard objectives add dawn.anvil.item.check dummy

# scoreboard objectives add dawn.anvil.item.enchlvl dummy
# scoreboard objectives add dawn.anvil.item.enchlvl2 dummy

# scoreboard objectives add dawn.anvil.item.disenchant dummy

# scoreboard objectives add dawn.anvil.item.attribute dummy