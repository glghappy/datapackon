
data modify entity @s item.components."minecraft:item_model" set value "dawn:alloy_smelter_on"

execute if block ~1 ~ ~ #air run setblock ~1 ~ ~ light[level=12]
execute if block ~-1 ~ ~ #air run setblock ~-1 ~ ~ light[level=12]
execute if block ~ ~1 ~ #air run setblock ~ ~1 ~ light[level=12]
execute if block ~ ~-1 ~ #air run setblock ~ ~-1 ~ light[level=12]
execute if block ~ ~ ~1 #air run setblock ~ ~ ~1 light[level=12]
execute if block ~ ~ ~-1 #air run setblock ~ ~ ~-1 light[level=12]
