
execute if items block ~ ~ ~ container.19 minecraft:blaze_rod run return 1
execute if items block ~ ~ ~ container.19 *[item_model="dawn:blaze_coal"] run return 1

execute if score @s dawn.smeltery.fuel_level matches 3..4 run return 1
