
fill ~-1 ~ ~-1 ~1 ~4 ~1 air destroy