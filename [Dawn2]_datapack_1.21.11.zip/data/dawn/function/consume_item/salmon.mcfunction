advancement revoke @s only dawn:consume_item/salmon

scoreboard players add @s dawn.player.protein 7072
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000
