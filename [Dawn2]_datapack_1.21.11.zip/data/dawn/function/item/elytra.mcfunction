kill @s
loot spawn ~ ~ ~ loot dawn:elytra