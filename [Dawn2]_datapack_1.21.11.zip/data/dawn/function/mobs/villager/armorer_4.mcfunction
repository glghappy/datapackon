
tag @s add sell_4

# 7 [-2]

# 8 [-1]

item replace entity @s armor.head with air
