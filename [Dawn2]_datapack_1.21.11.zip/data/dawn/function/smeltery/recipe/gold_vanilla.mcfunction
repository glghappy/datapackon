
execute if items block ~ ~ ~ container.1 minecraft:gold_nugget run return 10

execute if items block ~ ~ ~ container.1 minecraft:glistering_melon_slice run return 80
execute if items block ~ ~ ~ container.1 minecraft:golden_carrot run return 80

execute if items block ~ ~ ~ container.1 minecraft:gold_ingot run return 90
execute if items block ~ ~ ~ container.1 minecraft:powered_rail run return 90
execute if items block ~ ~ ~ container.1 minecraft:raw_gold run return 90
execute if items block ~ ~ ~ container.1 minecraft:gold_ore run return 90
execute if items block ~ ~ ~ container.1 minecraft:deepslate_gold_ore run return 90
execute if items block ~ ~ ~ container.1 minecraft:nether_gold_ore run return 90

execute if items block ~ ~ ~ container.1 minecraft:golden_apple run return 180
execute if items block ~ ~ ~ container.1 minecraft:light_weighted_pressure_plate run return 180

execute if items block ~ ~ ~ container.1 minecraft:golden_horse_armor run return 270

execute if items block ~ ~ ~ container.1 minecraft:clock run return 360

execute if items block ~ ~ ~ container.1 minecraft:gold_block run return 810
execute if items block ~ ~ ~ container.1 minecraft:raw_gold_block run return 810
