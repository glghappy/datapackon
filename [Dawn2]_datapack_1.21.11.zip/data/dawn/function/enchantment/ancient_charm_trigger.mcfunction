


xp add @s 1 points

# execute store result score @s dawn.enchantment.ancient_charm run data get entity @s equipment.head.components."minecraft:custom_data".ancient_charm

# execute if score @s dawn.enchantment.ancient_charm matches ..200 run function dawn:enchantment/ancient_charm_trigger_head_2
