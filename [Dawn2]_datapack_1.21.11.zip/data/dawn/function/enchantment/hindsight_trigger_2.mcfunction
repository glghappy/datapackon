
# advancement revoke @s only dawn:enchantment/hindsight_2

effect give @s resistance 6 1 false
