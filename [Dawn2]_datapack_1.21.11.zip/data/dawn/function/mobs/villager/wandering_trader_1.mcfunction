
tag @s add sell_1

# 
loot replace entity @s armor.head loot dawn:tool/iron_iron_pickaxe
data modify entity @s Offers.Recipes[{sell:{id:"minecraft:iron_pickaxe"}}].sell set from entity @s equipment.head

item replace entity @s armor.head with air
