
# food bar
execute store result score @s dawn.player.foodSaturationLevel run data get entity @s foodSaturationLevel
scoreboard players operation @s dawn.player.foodLevel_show = @s dawn.player.foodLevel
scoreboard players operation @s dawn.player.foodSaturationLevel_show = @s dawn.player.foodSaturationLevel

execute as @s[level=..4] run function dawn:player/food/function {max_point:6, remove:14}
execute as @s[level=5..9] run function dawn:player/food/function {max_point:8, remove:12}
execute as @s[level=10..14] run function dawn:player/food/function {max_point:10, remove:10}
execute as @s[level=15..19] run function dawn:player/food/function {max_point:12, remove:8}
execute as @s[level=20..24] run function dawn:player/food/function {max_point:14, remove:6}
execute as @s[level=25..29] run function dawn:player/food/function {max_point:16, remove:4}
execute as @s[level=30..34] run function dawn:player/food/function {max_point:18, remove:2}
execute as @s[level=35..] run function dawn:player/food/function {max_point:20, remove:0}



# 饥饿伤害
execute as @s[level=..4, scores={dawn.player.foodLevel=..14}] run function dawn:player/food/starve
execute as @s[level=5..9, scores={dawn.player.foodLevel=..12}] run function dawn:player/food/starve
execute as @s[level=10..14, scores={dawn.player.foodLevel=..10}] run function dawn:player/food/starve
execute as @s[level=15..19, scores={dawn.player.foodLevel=..8}] run function dawn:player/food/starve
execute as @s[level=20..24, scores={dawn.player.foodLevel=..6}] run function dawn:player/food/starve
execute as @s[level=25..29, scores={dawn.player.foodLevel=..4}] run function dawn:player/food/starve
execute as @s[level=30..34, scores={dawn.player.foodLevel=..2}] run function dawn:player/food/starve
execute as @s[level=35.., scores={dawn.player.foodLevel=..0}] run function dawn:player/food/starve

scoreboard players reset @s[level=..4, scores={dawn.player.foodLevel=15..}] dawn.player.starve
scoreboard players reset @s[level=5..9, scores={dawn.player.foodLevel=13..}] dawn.player.starve
scoreboard players reset @s[level=10..14, scores={dawn.player.foodLevel=11..}] dawn.player.starve
scoreboard players reset @s[level=15..19, scores={dawn.player.foodLevel=9..}] dawn.player.starve
scoreboard players reset @s[level=20..24, scores={dawn.player.foodLevel=7..}] dawn.player.starve
scoreboard players reset @s[level=25..29, scores={dawn.player.foodLevel=5..}] dawn.player.starve
scoreboard players reset @s[level=30..34, scores={dawn.player.foodLevel=3..}] dawn.player.starve
scoreboard players reset @s[level=35.., scores={dawn.player.foodLevel=1..}] dawn.player.starve
