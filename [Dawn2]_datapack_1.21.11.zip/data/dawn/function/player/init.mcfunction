
scoreboard players set @s dawn.player.protein 160000
scoreboard players set @s dawn.player.phytonutrients 160000

function dawn:player/prologue