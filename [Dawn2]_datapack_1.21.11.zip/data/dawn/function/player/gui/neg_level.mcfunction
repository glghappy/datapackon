$data merge storage title:io {  \
    text: {"text":"$(neg_level)","color":"#E00000", "shadow_color":[0, 0, 0, 1]},  \
    font: "minecraft:default_mod",  \
    neg_font: "minecraft:default_neg",  \
    x: 0,  y: 26,  \
    align: "middle",  \
    origin: "down"  \
}
function title:new_text