
advancement revoke @s only dawn:enchantment/surging_add_2

scoreboard players set @s dawn.enchantment.surging 100

effect give @s minecraft:fire_resistance 12 0 true