
# 获取原料份数 (dawn.anvil.item.count)
scoreboard objectives add dawn.anvil.item.count dummy
execute store result score @s dawn.anvil.item.count run data get block ~ ~ ~ Items[{Slot:13b}].count

#antiaquatic
execute if predicate dawn:anvil/enchantment/antiaquatic if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"antiaquatic", "count":5}
execute if predicate dawn:anvil/enchantment/antiaquatic_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"antiaquatic", "count":1}

#aqua_affinity
execute if predicate dawn:anvil/enchantment/aqua_affinity if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"aqua_affinity", "count":1}
execute if predicate dawn:anvil/enchantment/aqua_affinity_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"aqua_affinity", "count":1}

#autosmelt
execute if predicate dawn:anvil/enchantment/autosmelt if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"autosmelt", "count":3}
execute if predicate dawn:anvil/enchantment/autosmelt_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"autosmelt", "count":1}

#bane_of_arthropods
execute if predicate dawn:anvil/enchantment/bane_of_arthropods if score @s dawn.anvil.item.count matches 10.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_arthropods", "count":10}
execute if predicate dawn:anvil/enchantment/bane_of_arthropods_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_arthropods", "count":1}

#bane_of_dragon
execute if predicate dawn:anvil/enchantment/bane_of_dragon if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_dragon", "count":1}
execute if predicate dawn:anvil/enchantment/bane_of_dragon_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_dragon", "count":1}

#bane_of_proboscis
execute if predicate dawn:anvil/enchantment/bane_of_proboscis if score @s dawn.anvil.item.count matches 20.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_proboscis", "count":20}
execute if predicate dawn:anvil/enchantment/bane_of_proboscis_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_proboscis", "count":1}

#bane_of_skeleton
execute if predicate dawn:anvil/enchantment/bane_of_skeleton if score @s dawn.anvil.item.count matches 12.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_skeleton", "count":12}
execute if predicate dawn:anvil/enchantment/bane_of_skeleton_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"bane_of_skeleton", "count":1}

#betrayers_arrow
execute if predicate dawn:anvil/enchantment/betrayers_arrow if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"betrayers_arrow", "count":1}
execute if predicate dawn:anvil/enchantment/betrayers_arrow_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"betrayers_arrow", "count":1}

#betrayers_edge
execute if predicate dawn:anvil/enchantment/betrayers_edge if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"betrayers_edge", "count":1}
execute if predicate dawn:anvil/enchantment/betrayers_edge_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"betrayers_edge", "count":1}

#betrayers_protection
execute if predicate dawn:anvil/enchantment/betrayers_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"betrayers_protection", "count":1}
execute if predicate dawn:anvil/enchantment/betrayers_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"betrayers_protection", "count":1}

#binding_curse
execute if predicate dawn:anvil/enchantment/binding_curse if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"binding_curse", "count":1}
execute if predicate dawn:anvil/enchantment/binding_curse_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"binding_curse", "count":1}

#blast_protection
execute if predicate dawn:anvil/enchantment/blast_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"blast_protection", "count":1}
execute if predicate dawn:anvil/enchantment/blast_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"blast_protection", "count":1}

#blazing_speed
execute if predicate dawn:anvil/enchantment/blazing_speed if score @s dawn.anvil.item.count matches 6.. run function dawn:anvil/function/enchantment3 {"enchantment":"blazing_speed", "count":6}
execute if predicate dawn:anvil/enchantment/blazing_speed_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"blazing_speed", "count":1}

#bleeding
execute if predicate dawn:anvil/enchantment/bleeding if score @s dawn.anvil.item.count matches 20.. run function dawn:anvil/function/enchantment3 {"enchantment":"bleeding", "count":20}
execute if predicate dawn:anvil/enchantment/bleeding_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"bleeding", "count":1}

#blessing_of_water
execute if predicate dawn:anvil/enchantment/blessing_of_water if score @s dawn.anvil.item.count matches 4.. run function dawn:anvil/function/enchantment3 {"enchantment":"blessing_of_water", "count":4}
execute if predicate dawn:anvil/enchantment/blessing_of_water_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"blessing_of_water", "count":1}

#breach
execute if predicate dawn:anvil/enchantment/breach if score @s dawn.anvil.item.count matches 15.. run function dawn:anvil/function/enchantment3 {"enchantment":"breach", "count":15}
execute if predicate dawn:anvil/enchantment/breach_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"breach", "count":1}

#butchering
execute if predicate dawn:anvil/enchantment/butchering if score @s dawn.anvil.item.count matches 12.. run function dawn:anvil/function/enchantment3 {"enchantment":"butchering", "count":12}
execute if predicate dawn:anvil/enchantment/butchering_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"butchering", "count":1}

#channeling
execute if predicate dawn:anvil/enchantment/channeling if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"channeling", "count":1}
execute if predicate dawn:anvil/enchantment/channeling_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"channeling", "count":1}

#cleaving
execute if predicate dawn:anvil/enchantment/cleaving if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"cleaving", "count":1}
execute if predicate dawn:anvil/enchantment/cleaving_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"cleaving", "count":1}

#collapsing
execute if predicate dawn:anvil/enchantment/collapsing if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"collapsing", "count":1}
execute if predicate dawn:anvil/enchantment/collapsing_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"collapsing", "count":1}

#cooling
execute if predicate dawn:anvil/enchantment/cooling if score @s dawn.anvil.item.count matches 15.. run function dawn:anvil/function/enchantment3 {"enchantment":"cooling", "count":15}
execute if predicate dawn:anvil/enchantment/cooling_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"cooling", "count":1}

#crystalize
execute if predicate dawn:anvil/enchantment/crystalize if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"crystalize", "count":1}
execute if predicate dawn:anvil/enchantment/crystalize_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"crystalize", "count":1}

#dash
execute if predicate dawn:anvil/enchantment/dash if score @s dawn.anvil.item.count matches 4.. run function dawn:anvil/function/enchantment3 {"enchantment":"dash", "count":4}
execute if predicate dawn:anvil/enchantment/dash_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"dash", "count":1}

#density
execute if predicate dawn:anvil/enchantment/density if score @s dawn.anvil.item.count matches 20.. run function dawn:anvil/function/enchantment3 {"enchantment":"density", "count":20}
execute if predicate dawn:anvil/enchantment/density_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"density", "count":1}

#depth_strider
execute if predicate dawn:anvil/enchantment/depth_strider if score @s dawn.anvil.item.count matches 6.. run function dawn:anvil/function/enchantment3 {"enchantment":"depth_strider", "count":6}
execute if predicate dawn:anvil/enchantment/depth_strider_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"depth_strider", "count":1}

#desolate_edge
execute if predicate dawn:anvil/enchantment/desolate_edge if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"desolate_edge", "count":3}
execute if predicate dawn:anvil/enchantment/desolate_edge_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"desolate_edge", "count":1}

#divine_execution
execute if predicate dawn:anvil/enchantment/divine_execution if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"divine_execution", "count":1}
execute if predicate dawn:anvil/enchantment/divine_execution_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"divine_execution", "count":1}

#dodge
execute if predicate dawn:anvil/enchantment/dodge if score @s dawn.anvil.item.count matches 2.. run function dawn:anvil/function/enchantment3 {"enchantment":"dodge", "count":2}
execute if predicate dawn:anvil/enchantment/dodge_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"dodge", "count":1}

#efficiency
execute if predicate dawn:anvil/enchantment/efficiency if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"efficiency", "count":3}
execute if predicate dawn:anvil/enchantment/efficiency_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"efficiency", "count":1}

#ember_edge
execute if predicate dawn:anvil/enchantment/ember_edge if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"ember_edge", "count":3}
execute if predicate dawn:anvil/enchantment/ember_edge_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"ember_edge", "count":1}

#end_protection
execute if predicate dawn:anvil/enchantment/end_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"end_protection", "count":1}
execute if predicate dawn:anvil/enchantment/end_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"end_protection", "count":1}

#enderman_repression
execute if predicate dawn:anvil/enchantment/enderman_repression if score @s dawn.anvil.item.count matches 8.. run function dawn:anvil/function/enchantment3 {"enchantment":"enderman_repression", "count":8}
execute if predicate dawn:anvil/enchantment/enderman_repression_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"enderman_repression", "count":1}

#endurance
execute if predicate dawn:anvil/enchantment/endurance if score @s dawn.anvil.item.count matches 16.. run function dawn:anvil/function/enchantment3 {"enchantment":"endurance", "count":16}
execute if predicate dawn:anvil/enchantment/endurance_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"endurance", "count":1}

#eternal_flame
execute if predicate dawn:anvil/enchantment/eternal_flame if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"eternal_flame", "count":1}
execute if predicate dawn:anvil/enchantment/eternal_flame_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"eternal_flame", "count":1}

#eternal_frost
execute if predicate dawn:anvil/enchantment/eternal_frost if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"eternal_frost", "count":1}
execute if predicate dawn:anvil/enchantment/eternal_frost_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"eternal_frost", "count":1}

#experienced
execute if predicate dawn:anvil/enchantment/experienced if score @s dawn.anvil.item.count matches 10.. run function dawn:anvil/function/enchantment3 {"enchantment":"experienced", "count":10}
execute if predicate dawn:anvil/enchantment/experienced_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"experienced", "count":1}

#extend
execute if predicate dawn:anvil/enchantment/extend if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"extend", "count":5}
execute if predicate dawn:anvil/enchantment/extend_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"extend", "count":1}

#feather_falling
execute if predicate dawn:anvil/enchantment/feather_falling if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"feather_falling", "count":1}
execute if predicate dawn:anvil/enchantment/feather_falling_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"feather_falling", "count":1}

#feral_fury
execute if predicate dawn:anvil/enchantment/feral_fury if score @s dawn.anvil.item.count matches 8.. run function dawn:anvil/function/enchantment3 {"enchantment":"feral_fury", "count":8}
execute if predicate dawn:anvil/enchantment/feral_fury_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"feral_fury", "count":1}

#fire_aspect
execute if predicate dawn:anvil/enchantment/fire_aspect if score @s dawn.anvil.item.count matches 8.. run function dawn:anvil/function/enchantment3 {"enchantment":"fire_aspect", "count":8}
execute if predicate dawn:anvil/enchantment/fire_aspect_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"fire_aspect", "count":1}

#fire_protection
execute if predicate dawn:anvil/enchantment/fire_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"fire_protection", "count":1}
execute if predicate dawn:anvil/enchantment/fire_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"fire_protection", "count":1}

#flame
execute if predicate dawn:anvil/enchantment/flame if score @s dawn.anvil.item.count matches 10.. run function dawn:anvil/function/enchantment3 {"enchantment":"flame", "count":10}
execute if predicate dawn:anvil/enchantment/flame_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"flame", "count":1}

#fleet
execute if predicate dawn:anvil/enchantment/fleet if score @s dawn.anvil.item.count matches 6.. run function dawn:anvil/function/enchantment3 {"enchantment":"fleet", "count":6}
execute if predicate dawn:anvil/enchantment/fleet_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"fleet", "count":1}

#fortune
execute if predicate dawn:anvil/enchantment/fortune if score @s dawn.anvil.item.count matches 6.. run function dawn:anvil/function/enchantment3 {"enchantment":"fortune", "count":6}
execute if predicate dawn:anvil/enchantment/fortune_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"fortune", "count":1}

#free_action
execute if predicate dawn:anvil/enchantment/free_action if score @s dawn.anvil.item.count matches 32.. run function dawn:anvil/function/enchantment3 {"enchantment":"free_action", "count":32}
execute if predicate dawn:anvil/enchantment/free_action_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"free_action", "count":1}

#frost_shockwave
execute if predicate dawn:anvil/enchantment/frost_shockwave if score @s dawn.anvil.item.count matches 8.. run function dawn:anvil/function/enchantment3 {"enchantment":"frost_shockwave", "count":8}
execute if predicate dawn:anvil/enchantment/frost_shockwave_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"frost_shockwave", "count":1}

#frost_walker
execute if predicate dawn:anvil/enchantment/frost_walker if score @s dawn.anvil.item.count matches 24.. run function dawn:anvil/function/enchantment3 {"enchantment":"frost_walker", "count":24}
execute if predicate dawn:anvil/enchantment/frost_walker_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"frost_walker", "count":1}

#glacial_edge
execute if predicate dawn:anvil/enchantment/glacial_edge if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"glacial_edge", "count":3}
execute if predicate dawn:anvil/enchantment/glacial_edge_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"glacial_edge", "count":1}

#glowing
execute if predicate dawn:anvil/enchantment/glowing if score @s dawn.anvil.item.count matches 12.. run function dawn:anvil/function/enchantment3 {"enchantment":"glowing", "count":12}
execute if predicate dawn:anvil/enchantment/glowing_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"glowing", "count":1}

#greed
execute if predicate dawn:anvil/enchantment/greed if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"greed", "count":1}
execute if predicate dawn:anvil/enchantment/greed_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"greed", "count":1}

#harvesting
execute if predicate dawn:anvil/enchantment/harvesting if score @s dawn.anvil.item.count matches 24.. run function dawn:anvil/function/enchantment3 {"enchantment":"harvesting", "count":24}
execute if predicate dawn:anvil/enchantment/harvesting_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"harvesting", "count":1}

#hellish
execute if predicate dawn:anvil/enchantment/hellish if score @s dawn.anvil.item.count matches 2.. run function dawn:anvil/function/enchantment3 {"enchantment":"hellish", "count":2}
execute if predicate dawn:anvil/enchantment/hellish_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"hellish", "count":1}

#hindsight
execute if predicate dawn:anvil/enchantment/hindsight if score @s dawn.anvil.item.count matches 4.. run function dawn:anvil/function/enchantment3 {"enchantment":"hindsight", "count":4}
execute if predicate dawn:anvil/enchantment/hindsight_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"hindsight", "count":1}

#impaling
execute if predicate dawn:anvil/enchantment/impaling if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"impaling", "count":5}
execute if predicate dawn:anvil/enchantment/impaling_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"impaling", "count":1}

#impervious
execute if predicate dawn:anvil/enchantment/impervious if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"impervious", "count":1}
execute if predicate dawn:anvil/enchantment/impervious_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"impervious", "count":1}

#infinity
execute if predicate dawn:anvil/enchantment/infinity if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"infinity", "count":1}
execute if predicate dawn:anvil/enchantment/infinity_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"infinity", "count":1}

#invigorating
execute if predicate dawn:anvil/enchantment/invigorating if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"invigorating", "count":1}
execute if predicate dawn:anvil/enchantment/invigorating_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"invigorating", "count":1}

#kinetic_absorption
execute if predicate dawn:anvil/enchantment/kinetic_absorption if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"kinetic_absorption", "count":1}
execute if predicate dawn:anvil/enchantment/kinetic_absorption_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"kinetic_absorption", "count":1}

#knockback
execute if predicate dawn:anvil/enchantment/knockback if score @s dawn.anvil.item.count matches 2.. run function dawn:anvil/function/enchantment3 {"enchantment":"knockback", "count":2}
execute if predicate dawn:anvil/enchantment/knockback_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"knockback", "count":1}

#last_whisper
execute if predicate dawn:anvil/enchantment/last_whisper if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"last_whisper", "count":1}
execute if predicate dawn:anvil/enchantment/last_whisper_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"last_whisper", "count":1}

#lava_walker
execute if predicate dawn:anvil/enchantment/lava_walker if score @s dawn.anvil.item.count matches 16.. run function dawn:anvil/function/enchantment3 {"enchantment":"lava_walker", "count":16}
execute if predicate dawn:anvil/enchantment/lava_walker_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"lava_walker", "count":1}

#leaping
execute if predicate dawn:anvil/enchantment/leaping if score @s dawn.anvil.item.count matches 2.. run function dawn:anvil/function/enchantment3 {"enchantment":"leaping", "count":2}
execute if predicate dawn:anvil/enchantment/leaping_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"leaping", "count":1}

#light_drive
execute if predicate dawn:anvil/enchantment/light_drive if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"light_drive", "count":1}
execute if predicate dawn:anvil/enchantment/light_drive_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"light_drive", "count":1}

#looting
execute if predicate dawn:anvil/enchantment/looting if score @s dawn.anvil.item.count matches 20.. run function dawn:anvil/function/enchantment3 {"enchantment":"looting", "count":20}
execute if predicate dawn:anvil/enchantment/looting_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"looting", "count":1}

#loyalty
execute if predicate dawn:anvil/enchantment/loyalty if score @s dawn.anvil.item.count matches 6.. run function dawn:anvil/function/enchantment3 {"enchantment":"loyalty", "count":6}
execute if predicate dawn:anvil/enchantment/loyalty_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"loyalty", "count":1}

#luck_of_the_sea
execute if predicate dawn:anvil/enchantment/luck_of_the_sea if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"luck_of_the_sea", "count":1}
execute if predicate dawn:anvil/enchantment/luck_of_the_sea_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"luck_of_the_sea", "count":1}

#lure
execute if predicate dawn:anvil/enchantment/lure if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"lure", "count":1}
execute if predicate dawn:anvil/enchantment/lure_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"lure", "count":1}

#magic_protection
execute if predicate dawn:anvil/enchantment/magic_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"magic_protection", "count":1}
execute if predicate dawn:anvil/enchantment/magic_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"magic_protection", "count":1}

#melee_protection
execute if predicate dawn:anvil/enchantment/melee_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"melee_protection", "count":1}
execute if predicate dawn:anvil/enchantment/melee_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"melee_protection", "count":1}

#mending
execute if predicate dawn:anvil/enchantment/mending if score @s dawn.anvil.item.count matches 4.. run function dawn:anvil/function/enchantment3 {"enchantment":"mending", "count":4}
execute if predicate dawn:anvil/enchantment/mending_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"mending", "count":1}

#momentum
execute if predicate dawn:anvil/enchantment/momentum if score @s dawn.anvil.item.count matches 12.. run function dawn:anvil/function/enchantment3 {"enchantment":"momentum", "count":12}
execute if predicate dawn:anvil/enchantment/momentum_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"momentum", "count":1}

#multishot
execute if predicate dawn:anvil/enchantment/multishot if score @s dawn.anvil.item.count matches 8.. run function dawn:anvil/function/enchantment3 {"enchantment":"multishot", "count":8}
execute if predicate dawn:anvil/enchantment/multishot_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"multishot", "count":1}

#nether_protection
execute if predicate dawn:anvil/enchantment/nether_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"nether_protection", "count":1}
execute if predicate dawn:anvil/enchantment/nether_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"nether_protection", "count":1}

#night_vision
execute if predicate dawn:anvil/enchantment/night_vision if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"night_vision", "count":1}
execute if predicate dawn:anvil/enchantment/night_vision_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"night_vision", "count":1}

#piercing
execute if predicate dawn:anvil/enchantment/piercing if score @s dawn.anvil.item.count matches 6.. run function dawn:anvil/function/enchantment3 {"enchantment":"piercing", "count":6}
execute if predicate dawn:anvil/enchantment/piercing_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"piercing", "count":1}

#poison
execute if predicate dawn:anvil/enchantment/poison if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"poison", "count":1}
execute if predicate dawn:anvil/enchantment/poison_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"poison", "count":1}

#power
execute if predicate dawn:anvil/enchantment/power if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"power", "count":3}
execute if predicate dawn:anvil/enchantment/power_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"power", "count":1}

#projectile_protection
execute if predicate dawn:anvil/enchantment/projectile_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"projectile_protection", "count":1}
execute if predicate dawn:anvil/enchantment/projectile_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"projectile_protection", "count":1}

#protection
execute if predicate dawn:anvil/enchantment/protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"protection", "count":1}
execute if predicate dawn:anvil/enchantment/protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"protection", "count":1}

#punch
execute if predicate dawn:anvil/enchantment/punch if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"punch", "count":3}
execute if predicate dawn:anvil/enchantment/punch_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"punch", "count":1}

#quick_charge
execute if predicate dawn:anvil/enchantment/quick_charge if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"quick_charge", "count":5}
execute if predicate dawn:anvil/enchantment/quick_charge_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"quick_charge", "count":1}

#recuperation
execute if predicate dawn:anvil/enchantment/recuperation if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"recuperation", "count":1}
execute if predicate dawn:anvil/enchantment/recuperation_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"recuperation", "count":1}

#regeneration
execute if predicate dawn:anvil/enchantment/regeneration if score @s dawn.anvil.item.count matches 4.. run function dawn:anvil/function/enchantment3 {"enchantment":"regeneration", "count":4}
execute if predicate dawn:anvil/enchantment/regeneration_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"regeneration", "count":1}

#respiration
execute if predicate dawn:anvil/enchantment/respiration if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"respiration", "count":3}
execute if predicate dawn:anvil/enchantment/respiration_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"respiration", "count":1}

#riptide
execute if predicate dawn:anvil/enchantment/riptide if score @s dawn.anvil.item.count matches 3.. run function dawn:anvil/function/enchantment3 {"enchantment":"riptide", "count":3}
execute if predicate dawn:anvil/enchantment/riptide_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"riptide", "count":1}

#sanctified_bulwark
execute if predicate dawn:anvil/enchantment/sanctified_bulwark if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"sanctified_bulwark", "count":1}
execute if predicate dawn:anvil/enchantment/sanctified_bulwark_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"sanctified_bulwark", "count":1}

#sawing
execute if predicate dawn:anvil/enchantment/sawing if score @s dawn.anvil.item.count matches 10.. run function dawn:anvil/function/enchantment3 {"enchantment":"sawing", "count":10}
execute if predicate dawn:anvil/enchantment/sawing_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"sawing", "count":1}

#sectumsempra
execute if predicate dawn:anvil/enchantment/sectumsempra if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"sectumsempra", "count":1}
execute if predicate dawn:anvil/enchantment/sectumsempra_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"sectumsempra", "count":1}

#severing
execute if predicate dawn:anvil/enchantment/severing if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"severing", "count":1}
execute if predicate dawn:anvil/enchantment/severing_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"severing", "count":1}

#shadow_ambush
execute if predicate dawn:anvil/enchantment/shadow_ambush if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"shadow_ambush", "count":1}
execute if predicate dawn:anvil/enchantment/shadow_ambush_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"shadow_ambush", "count":1}

#sharpness
execute if predicate dawn:anvil/enchantment/sharpness if score @s dawn.anvil.item.count matches 15.. run function dawn:anvil/function/enchantment3 {"enchantment":"sharpness", "count":15}
execute if predicate dawn:anvil/enchantment/sharpness_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"sharpness", "count":1}

#silk_touch
execute if predicate dawn:anvil/enchantment/silk_touch if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"silk_touch", "count":1}
execute if predicate dawn:anvil/enchantment/silk_touch_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"silk_touch", "count":1}

#silky_shears
execute if predicate dawn:anvil/enchantment/silky_shears if score @s dawn.anvil.item.count matches 10.. run function dawn:anvil/function/enchantment3 {"enchantment":"silky_shears", "count":10}
execute if predicate dawn:anvil/enchantment/silky_shears_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"silky_shears", "count":1}

#smite
execute if predicate dawn:anvil/enchantment/smite if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"smite", "count":5}
execute if predicate dawn:anvil/enchantment/smite_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"smite", "count":1}

#soul_devour
execute if predicate dawn:anvil/enchantment/soul_devour if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"soul_devour", "count":1}
execute if predicate dawn:anvil/enchantment/soul_devour_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"soul_devour", "count":1}

#soul_speed
execute if predicate dawn:anvil/enchantment/soul_speed if score @s dawn.anvil.item.count matches 32.. run function dawn:anvil/function/enchantment3 {"enchantment":"soul_speed", "count":32}
execute if predicate dawn:anvil/enchantment/soul_speed_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"soul_speed", "count":1}

#speedy
execute if predicate dawn:anvil/enchantment/speedy if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"speedy", "count":5}
execute if predicate dawn:anvil/enchantment/speedy_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"speedy", "count":1}

#step_up
execute if predicate dawn:anvil/enchantment/step_up if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"step_up", "count":5}
execute if predicate dawn:anvil/enchantment/step_up_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"step_up", "count":1}

#stun
execute if predicate dawn:anvil/enchantment/stun if score @s dawn.anvil.item.count matches 12.. run function dawn:anvil/function/enchantment3 {"enchantment":"stun", "count":12}
execute if predicate dawn:anvil/enchantment/stun_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"stun", "count":1}

#surging
execute if predicate dawn:anvil/enchantment/surging if score @s dawn.anvil.item.count matches 8.. run function dawn:anvil/function/enchantment3 {"enchantment":"surging", "count":8}
execute if predicate dawn:anvil/enchantment/surging_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"surging", "count":1}

#sweeping_edge
execute if predicate dawn:anvil/enchantment/sweeping_edge if score @s dawn.anvil.item.count matches 4.. run function dawn:anvil/function/enchantment3 {"enchantment":"sweeping_edge", "count":4}
execute if predicate dawn:anvil/enchantment/sweeping_edge_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"sweeping_edge", "count":1}

#swift_sneak
execute if predicate dawn:anvil/enchantment/swift_sneak if score @s dawn.anvil.item.count matches 15.. run function dawn:anvil/function/enchantment3 {"enchantment":"swift_sneak", "count":15}
execute if predicate dawn:anvil/enchantment/swift_sneak_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"swift_sneak", "count":1}

#swiftstrike
execute if predicate dawn:anvil/enchantment/swiftstrike if score @s dawn.anvil.item.count matches 5.. run function dawn:anvil/function/enchantment3 {"enchantment":"swiftstrike", "count":5}
execute if predicate dawn:anvil/enchantment/swiftstrike_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"swiftstrike", "count":1}

#thorns
execute if predicate dawn:anvil/enchantment/thorns if score @s dawn.anvil.item.count matches 15.. run function dawn:anvil/function/enchantment3 {"enchantment":"thorns", "count":15}
execute if predicate dawn:anvil/enchantment/thorns_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"thorns", "count":1}

#thors_aegis
execute if predicate dawn:anvil/enchantment/thors_aegis if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"thors_aegis", "count":1}
execute if predicate dawn:anvil/enchantment/thors_aegis_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"thors_aegis", "count":1}

#thors_benediction
execute if predicate dawn:anvil/enchantment/thors_benediction if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"thors_benediction", "count":1}
execute if predicate dawn:anvil/enchantment/thors_benediction_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"thors_benediction", "count":1}

#thors_ire
execute if predicate dawn:anvil/enchantment/thors_ire if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"thors_ire", "count":1}
execute if predicate dawn:anvil/enchantment/thors_ire_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"thors_ire", "count":1}

#truce
execute if predicate dawn:anvil/enchantment/truce if score @s dawn.anvil.item.count matches 24.. run function dawn:anvil/function/enchantment3 {"enchantment":"truce", "count":24}
execute if predicate dawn:anvil/enchantment/truce_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"truce", "count":1}

#unbreakable
execute if predicate dawn:anvil/enchantment/unbreakable if score @s dawn.anvil.item.count matches 2.. run function dawn:anvil/function/enchantment3 {"enchantment":"unbreakable", "count":2}
execute if predicate dawn:anvil/enchantment/unbreakable_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"unbreakable", "count":1}

#unbreaking
execute if predicate dawn:anvil/enchantment/unbreaking if score @s dawn.anvil.item.count matches 12.. run function dawn:anvil/function/enchantment3 {"enchantment":"unbreaking", "count":12}
execute if predicate dawn:anvil/enchantment/unbreaking_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"unbreaking", "count":1}

#underworld_mining
execute if predicate dawn:anvil/enchantment/underworld_mining if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"underworld_mining", "count":1}
execute if predicate dawn:anvil/enchantment/underworld_mining_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"underworld_mining", "count":1}

#underworld_protection
execute if predicate dawn:anvil/enchantment/underworld_protection if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"underworld_protection", "count":1}
execute if predicate dawn:anvil/enchantment/underworld_protection_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"underworld_protection", "count":1}

#vampiric
execute if predicate dawn:anvil/enchantment/vampiric if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"vampiric", "count":1}
execute if predicate dawn:anvil/enchantment/vampiric_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"vampiric", "count":1}

#vanishing_curse
execute if predicate dawn:anvil/enchantment/vanishing_curse if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"vanishing_curse", "count":1}
execute if predicate dawn:anvil/enchantment/vanishing_curse_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"vanishing_curse", "count":1}

#viper
execute if predicate dawn:anvil/enchantment/viper if score @s dawn.anvil.item.count matches 2.. run function dawn:anvil/function/enchantment3 {"enchantment":"viper", "count":2}
execute if predicate dawn:anvil/enchantment/viper_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"viper", "count":1}

#weave
execute if predicate dawn:anvil/enchantment/weave if score @s dawn.anvil.item.count matches 6.. run function dawn:anvil/function/enchantment3 {"enchantment":"weave", "count":6}
execute if predicate dawn:anvil/enchantment/weave_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"weave", "count":1}

#wind_burst
execute if predicate dawn:anvil/enchantment/wind_burst if score @s dawn.anvil.item.count matches 15.. run function dawn:anvil/function/enchantment3 {"enchantment":"wind_burst", "count":15}
execute if predicate dawn:anvil/enchantment/wind_burst_book if score @s dawn.anvil.item.count matches 1.. run function dawn:anvil/function/enchantment3 {"enchantment":"wind_burst", "count":1}

# 成功生成 117 组附魔JSON文件到 enchantments 目录下
