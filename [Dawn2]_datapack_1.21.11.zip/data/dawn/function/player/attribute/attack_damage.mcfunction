
attribute @s minecraft:attack_damage modifier remove level.attack_damage

$attribute @s minecraft:attack_damage modifier add level.attack_damage $(attack_damage) add_multiplied_base
