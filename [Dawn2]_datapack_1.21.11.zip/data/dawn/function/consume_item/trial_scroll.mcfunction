advancement revoke @s only dawn:consume_item/trial_scroll

execute store result score @s dawn.locate run locate structure trial_chambers

tellraw @s[scores={dawn.locate=1..}] [{"translate":"broadcast.dawn.trial_chambers", "color": "white", "italic": false, "with": [{"score": {"name": "@s","objective": "dawn.locate"}}]}]

tellraw @s[scores={dawn.locate=0}] [{"translate":"broadcast.dawn.no", "color": "red", "italic": false}]
