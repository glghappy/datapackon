data modify entity @s angry_at set from entity @p UUID

data modify entity @s anger_end_time set value 400
