
# 检测工具和部件“款式”是否相同（0-成功， 1-失败）
scoreboard objectives add dawn.anvil.item_type_check dummy
data modify storage dawn:item_type_check type set from block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".item.type
execute store success score @s dawn.anvil.item_type_check run data modify storage dawn:item_type_check type set from block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".item.type
execute if score @s dawn.anvil.item_type_check matches 1 run function dawn:anvil/craft/engrave_main

# say ty