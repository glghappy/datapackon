# 游戏规则
scoreboard objectives add dawn.gamerule dummy
