
tag @s add sell_5

# 9
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:8, id:"minecraft:tripwire_hook"}, priceMultiplier: 0.05f, xp:30}

# 10
function dawn:mobs/villager/fletcher_5_1
execute if predicate dawn:random/0.5 run function dawn:mobs/villager/fletcher_5_2


item replace entity @s armor.head with air
