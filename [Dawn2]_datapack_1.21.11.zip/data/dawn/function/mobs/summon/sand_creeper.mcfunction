
# Sand Creeper 沙漠苦力怕
summon minecraft:creeper ~ ~ ~ {CustomName: "Sand Creeper", Tags: ["summon", "sand_creeper"], Health: 16.0f, attributes: [{id: "minecraft:max_health", base: 16.0d}, {id: "minecraft:movement_speed", base: 0.27d}], Fuse: 25s, ExplosionRadius: 3b}

tp @s ~ -255 ~

kill @s