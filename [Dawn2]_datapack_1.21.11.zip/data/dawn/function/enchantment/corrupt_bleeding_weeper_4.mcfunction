scoreboard players reset @s dawn.entity.corrupt_bleeding_weeper

effect give @s instant_damage 2 0 true

summon zombie ~1 ~ ~1
summon husk ~1 ~ ~-1
summon zombie_villager ~-1 ~ ~1
summon drowned ~-1 ~ ~-1