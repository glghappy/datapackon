
# Stone Creeper 石化苦力怕
summon minecraft:creeper ~ ~ ~ {CustomName: "Stone Creeper", Tags: ["summon", "stone_creeper"], DeathLootTable: "dawn:entities/stone_creeper", attributes: [{id: "minecraft:knockback_resistance", base: 0.4d}, {id: "minecraft:movement_speed", base: 0.23d}, {id: "minecraft:armor", base: 2.0d}], ExplosionRadius: 4b}

tp @s ~ -255 ~

kill @s