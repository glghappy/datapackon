scoreboard players reset @s dawn.player.death

scoreboard players reset @s[scores={dawn.player.neg_level=1..}] dawn.player.neg_level 

scoreboard players remove @s[level=0] dawn.player.neg_level 1

scoreboard players set @s[scores={dawn.player.neg_level=..-41}] dawn.player.neg_level -40