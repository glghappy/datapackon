# say 160
xp add @s -160 points