# 排列 1: 槽位顺序 (container.1 -> container.2 -> container.3)
execute \
if items block ~ ~ ~ container.1 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.2 minecraft:glowstone_dust[count=16] \
if items block ~ ~ ~ container.3 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 2: 槽位顺序 (container.1 -> container.3 -> container.2)
execute \
if items block ~ ~ ~ container.1 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.3 minecraft:glowstone_dust[count=16] \
if items block ~ ~ ~ container.2 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 3: 槽位顺序 (container.2 -> container.1 -> container.3)
execute \
if items block ~ ~ ~ container.2 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.1 minecraft:glowstone_dust[count=16] \
if items block ~ ~ ~ container.3 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 4: 槽位顺序 (container.2 -> container.3 -> container.1)
execute \
if items block ~ ~ ~ container.2 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.3 minecraft:glowstone_dust[count=16] \
if items block ~ ~ ~ container.1 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 5: 槽位顺序 (container.3 -> container.1 -> container.2)
execute \
if items block ~ ~ ~ container.3 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.1 minecraft:glowstone_dust[count=16] \
if items block ~ ~ ~ container.2 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 6: 槽位顺序 (container.3 -> container.2 -> container.1)
execute \
if items block ~ ~ ~ container.3 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.2 minecraft:glowstone_dust[count=16] \
if items block ~ ~ ~ container.1 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 7: 槽位顺序 (container.1 -> container.2 -> container.3)
execute \
if items block ~ ~ ~ container.1 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.2 minecraft:glowstone[count=4] \
if items block ~ ~ ~ container.3 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 8: 槽位顺序 (container.1 -> container.3 -> container.2)
execute \
if items block ~ ~ ~ container.1 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.3 minecraft:glowstone[count=4] \
if items block ~ ~ ~ container.2 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 9: 槽位顺序 (container.2 -> container.1 -> container.3)
execute \
if items block ~ ~ ~ container.2 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.1 minecraft:glowstone[count=4] \
if items block ~ ~ ~ container.3 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 10: 槽位顺序 (container.2 -> container.3 -> container.1)
execute \
if items block ~ ~ ~ container.2 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.3 minecraft:glowstone[count=4] \
if items block ~ ~ ~ container.1 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 11: 槽位顺序 (container.3 -> container.1 -> container.2)
execute \
if items block ~ ~ ~ container.3 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.1 minecraft:glowstone[count=4] \
if items block ~ ~ ~ container.2 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

# 排列 12: 槽位顺序 (container.3 -> container.2 -> container.1)
execute \
if items block ~ ~ ~ container.3 minecraft:gold_ingot[count=4] \
if items block ~ ~ ~ container.2 minecraft:glowstone[count=4] \
if items block ~ ~ ~ container.1 *[count=1, item_model="dawn:nether_star_shard"] \
run return 1

