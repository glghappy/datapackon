schedule function dawn:player/natural_hunger 1s
