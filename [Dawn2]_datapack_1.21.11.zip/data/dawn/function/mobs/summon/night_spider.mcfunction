
# Night Spider 夜蛛
summon minecraft:spider ~ ~ ~ {CustomName: "Night Spider", Tags: ["summon", "night_spider"], Health: 10.0f, equipment: {mainhand: {components: {"minecraft:max_stack_size": 1, "minecraft:enchantments": {"minecraft:attack_blindness": 1}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_model": {}, "!minecraft:item_name": {}}, count: 1, id: "minecraft:firework_star"}, feet: {components: {"!minecraft:attribute_modifiers": {}, "minecraft:equippable": {equip_sound: "minecraft:block.stone.hit", slot: "feet", asset_id: "dawn:air"}, "!minecraft:enchantable": {}, "minecraft:item_model": "minecraft:barrier", "!minecraft:repairable": {}, "minecraft:enchantments": {"minecraft:dark_invisibility": 1}, "!minecraft:max_damage": {}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_name": {}, "!minecraft:damage": {}}, count: 1, id: "minecraft:leather_boots"}}, drop_chances: {mainhand: 0.0f, head: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, attributes: [{id: "minecraft:max_health", base: 10.0d}, {id: "minecraft:movement_speed", base: 0.3d}, {id: "minecraft:scale", base: 0.8d}]}

tp @s ~ -255 ~

kill @s