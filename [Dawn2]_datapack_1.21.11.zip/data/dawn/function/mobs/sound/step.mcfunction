schedule function dawn:mobs/sound/step 15t

execute as @e[nbt={Silent:1b}] at @s store result score @s dawn.motion_x run data get entity @s Motion[0] 10000
execute as @e[nbt={Silent:1b}] at @s store result score @s dawn.motion_z run data get entity @s Motion[2] 10000

execute as @e[nbt={Silent:1b}] at @s run scoreboard players operation @s dawn.motion += @s dawn.motion_x
execute as @e[nbt={Silent:1b}] at @s run scoreboard players operation @s dawn.motion += @s dawn.motion_z

execute as @e[nbt={Silent:1b}] at @s if score @s dawn.motion matches 1.. run function dawn:mobs/sound/step_check
execute as @e[nbt={Silent:1b}] at @s if score @s dawn.motion matches ..-1 run function dawn:mobs/sound/step_check