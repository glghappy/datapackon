
scoreboard players add @s dawn.enchantment.blessing_of_water 1

execute if score @s dawn.enchantment.blessing_of_water matches 40.. run function dawn:enchantment/blessing_of_water_effect