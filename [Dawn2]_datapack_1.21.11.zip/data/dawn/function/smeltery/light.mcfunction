
data modify entity @s[tag=dawn.cobblestone] item.components."minecraft:item_model" set value "dawn:cobblestone_smeltery_on"
data modify entity @s[tag=dawn.obsidian] item.components."minecraft:item_model" set value "dawn:obsidian_smeltery_on"
data modify entity @s[tag=dawn.netherrack] item.components."minecraft:item_model" set value "dawn:netherrack_smeltery_on"

execute if block ~1 ~ ~ #air run setblock ~1 ~ ~ light[level=12]
execute if block ~-1 ~ ~ #air run setblock ~-1 ~ ~ light[level=12]
execute if block ~ ~1 ~ #air run setblock ~ ~1 ~ light[level=12]
execute if block ~ ~-1 ~ #air run setblock ~ ~-1 ~ light[level=12]
execute if block ~ ~ ~1 #air run setblock ~ ~ ~1 light[level=12]
execute if block ~ ~ ~-1 #air run setblock ~ ~ ~-1 light[level=12]
