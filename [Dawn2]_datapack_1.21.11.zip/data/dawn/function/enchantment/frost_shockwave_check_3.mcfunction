
execute unless score @s dawn.enchantment.frost_shockwave.cd matches 1.. run function dawn:enchantment/frost_shockwave_trigger_3
