
attribute @s minecraft:attack_damage modifier remove neg_level.attack_damage

$attribute @s minecraft:attack_damage modifier add neg_level.attack_damage $(attack_damage) add_multiplied_base
