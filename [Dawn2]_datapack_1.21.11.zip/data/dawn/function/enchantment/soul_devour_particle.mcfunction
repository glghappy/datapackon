
particle dust{color:[0.000, 0.200, 0.031], scale:1.5} ~ ~1 ~ 0.6 0.6 0.6 0 30 normal
