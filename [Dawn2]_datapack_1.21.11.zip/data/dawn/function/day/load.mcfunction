
scoreboard objectives add dawn.day dummy

schedule function dawn:day/check 1s
