
execute if items block ~ ~ ~ container.19 minecraft:blaze_rod run return 1
