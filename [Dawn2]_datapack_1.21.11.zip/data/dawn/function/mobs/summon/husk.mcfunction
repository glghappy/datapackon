
tag @s add summon

execute if items entity @s weapon.mainhand iron_sword[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:tool/iron_wooden_sword
execute if items entity @s weapon.mainhand iron_shovel[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:tool/iron_wooden_shovel
