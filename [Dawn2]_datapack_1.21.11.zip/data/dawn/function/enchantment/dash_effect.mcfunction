
# execute as @e[scores={dawn.enchantment.dash=1..29}] at @s run particle dust{color:[0.922, 0.867, 0.412], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal
# execute as @e[scores={dawn.enchantment.dash=30..47}] at @s run particle dust{color:[0.922, 0.718, 0.275], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal
# execute as @e[scores={dawn.enchantment.dash=48..59}] at @s run particle dust{color:[0.922, 0.494, 0.122], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal
# execute as @e[scores={dawn.enchantment.dash=60..}] at @s run particle dust{color:[0.922, 0.298, 0.090], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal

# scoreboard players remove @s[scores={dawn.enchantment.dash=1..}] dawn.enchantment.dash 1
# scoreboard players reset @s[scores={dawn.enchantment.dash=..0}] dawn.enchantment.dash

# execute store result storage dawn:player enchantment_dash float 0.05 run scoreboard players get @s dawn.enchantment.dash
# function dawn:enchantment/dash_function with storage dawn:player
# execute store result storage dawn:player enchantment_dash2 float 0.015 run scoreboard players get @s dawn.enchantment.dash
# function dawn:enchantment/dash_function with storage dawn:player



# by：Minecraft_hyr

execute as @s[scores={dawn.enchantment.dash=1..29}] at @s run particle dust{color:[0.922, 0.867, 0.412], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal
execute as @s[scores={dawn.enchantment.dash=30..47}] at @s run particle dust{color:[0.922, 0.718, 0.275], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal
execute as @s[scores={dawn.enchantment.dash=48..59}] at @s run particle dust{color:[0.922, 0.494, 0.122], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal
execute as @s[scores={dawn.enchantment.dash=60..}] at @s run particle dust{color:[0.922, 0.298, 0.090], scale:0.5} ~ ~1 ~ 0.2 0.4 0.2 0.1 1 normal

execute store result storage dawn:player enchantment_dash float 0.05 run scoreboard players get @s dawn.enchantment.dash
execute store result storage dawn:player enchantment_dash2 float 0.015 run scoreboard players get @s dawn.enchantment.dash
function dawn:enchantment/dash_function with storage dawn:player

scoreboard players remove @s dawn.enchantment.dash 1
execute if score @s dawn.enchantment.dash matches 1.. run return fail
scoreboard players reset @s dawn.enchantment.dash
