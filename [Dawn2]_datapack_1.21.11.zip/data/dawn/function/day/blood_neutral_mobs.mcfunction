
effect give @s minecraft:speed 18 0 false
effect give @s minecraft:resistance 18 0 false
