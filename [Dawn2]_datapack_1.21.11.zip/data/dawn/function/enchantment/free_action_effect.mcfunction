
attribute @s movement_speed modifier remove enchantment.free_action
$attribute @s movement_speed modifier add enchantment.free_action $(free_action) add_multiplied_total
