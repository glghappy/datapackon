# 返还物品
function dawn:alloy_smelter/return_items

# 重置GUI
function dawn:alloy_smelter/gui

# 清除
execute unless block ~ ~ ~ minecraft:barrel run kill @s
