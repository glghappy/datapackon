advancement revoke @s only dawn:consume_item/beetroot_soup

scoreboard players add @s dawn.player.phytonutrients 11000
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000

scoreboard players add @s dawn.player.insulin 6000
effect give @s[scores={dawn.player.insulin=48000..}] minecraft:nausea 10 0 false
effect give @s[scores={dawn.player.insulin=96000..}] minecraft:nausea 18 0 false
effect give @s[scores={dawn.player.insulin=144000..}] minecraft:nausea 24 0 false
effect give @s[scores={dawn.player.insulin=144000..}] minecraft:poison 5 0 false