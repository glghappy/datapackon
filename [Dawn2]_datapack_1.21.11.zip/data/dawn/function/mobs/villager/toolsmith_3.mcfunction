
tag @s add sell_3

# 5
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:1, id:"minecraft:lava_bucket"}, priceMultiplier: 0.05f, xp:15}

# 6
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:bell"}, buy:{count:36, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:10}
