
#
tag @s add summon

#
execute if items entity @s weapon.mainhand bow[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:weapon/bow
