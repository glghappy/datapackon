schedule function dawn:enchantment/attack_palsy_effect 2t

execute as @a[scores={dawn.enchantment.attack_palsy=1..}] at @s run tp @s @s

scoreboard players remove @a[scores={dawn.enchantment.attack_palsy=1..}] dawn.enchantment.attack_palsy 1
