
# 在【原料改变/烧炼被动终止】时触发

# GUI【不包括空白格子和火焰】
item replace block ~ ~ ~ container.0 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:smeltery_gui"]
item replace block ~ ~ ~ container.3 with firework_star[minecraft:item_name="无", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:smeltery_show_empty"]
item replace block ~ ~ ~ container.4 with firework_star[minecraft:item_name="无", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.5 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:smeltery_craft_0"]
item replace block ~ ~ ~ container.12 with firework_star[minecraft:item_name="无", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.13 with firework_star[minecraft:item_name="无", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.21 with firework_star[minecraft:item_name="上页", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.22 with firework_star[minecraft:item_name="下页", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.23 with firework_star[minecraft:item_name="冶炼", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]

execute if data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run data modify block ~ ~ ~ Items.[{Slot:0b}].components."minecraft:item_model" set value "dawn:smeltery_gui_stop"
execute if data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run data modify block ~ ~ ~ Items.[{Slot:4b}].components."minecraft:item_model" set value "dawn:smeltery_show_true"

execute if data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run data modify block ~ ~ ~ Items.[{Slot:21b}].components."minecraft:item_name" set value "禁用"
execute if data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run data modify block ~ ~ ~ Items.[{Slot:22b}].components."minecraft:item_name" set value "禁用"
execute if data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run data modify block ~ ~ ~ Items.[{Slot:23b}].components."minecraft:item_name" set value "禁用"
