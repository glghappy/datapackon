
# 移除成品清除标记
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear

# 扣除材料
item replace block ~ ~ ~ container.13 with air

# 移除原本工具
item replace block ~ ~ ~ container.10 with air

# 移除成品附加标记
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_disenchant

# 播放声音
playsound minecraft:block.anvil.use block @a ~ ~ ~