advancement revoke @s only dawn:consume_item/golden_carrot

scoreboard players add @s dawn.player.phytonutrients 20995
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
