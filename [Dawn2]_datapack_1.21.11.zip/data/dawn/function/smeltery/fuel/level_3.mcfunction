
execute if items block ~ ~ ~ container.19 minecraft:blaze_rod run return 1

execute if score @s dawn.smeltery.fuel_level matches 3 run return 1
