advancement revoke @s only dawn:consume_item/cereal

scoreboard players add @s dawn.player.insulin 3500
effect give @s[scores={dawn.player.insulin=48000..}] minecraft:nausea 10 0 false
effect give @s[scores={dawn.player.insulin=96000..}] minecraft:nausea 18 0 false
effect give @s[scores={dawn.player.insulin=144000..}] minecraft:nausea 24 0 false
effect give @s[scores={dawn.player.insulin=144000..}] minecraft:poison 5 0 false