
execute if items block ~ ~ ~ container.19 minecraft:lava_bucket run return 1

execute if score @s dawn.smeltery.fuel_level matches 2 run return 1
