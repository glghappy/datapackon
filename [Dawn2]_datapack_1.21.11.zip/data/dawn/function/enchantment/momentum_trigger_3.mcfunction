
scoreboard players set @s dawn.enchantment.momentum 55
scoreboard players set @s dawn.enchantment.momentum.time 21

