
scoreboard players add @s dawn.enchantment.dash 2
scoreboard players set @s[scores={dawn.enchantment.dash=48..}] dawn.enchantment.dash 48
