
# 脚步声
scoreboard objectives add dawn.motion dummy
scoreboard objectives add dawn.motion_x dummy
scoreboard objectives add dawn.motion_z dummy

schedule function dawn:mobs/sound/step 15t



# 低语
schedule function dawn:mobs/sound/6s/earth_elemental 1t
schedule function dawn:mobs/sound/6s/ghoul 2t
schedule function dawn:mobs/sound/6s/phase_spider 3t



# 流血
scoreboard objectives add dawn.entity.health dummy
