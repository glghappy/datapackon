# 返还物品
function dawn:smeltery/return_items

# 按钮（左/右）[dawn.smeltery.button]
execute unless data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} unless predicate dawn:smeltery/left run scoreboard players remove @n[type=item_display, tag=dawn.smeltery, distance=...5, scores={dawn.smeltery.button=1..}] dawn.smeltery.button 1
execute unless data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} unless predicate dawn:smeltery/right run scoreboard players add @n[type=item_display, tag=dawn.smeltery, distance=...5] dawn.smeltery.button 1

# 按钮（work）
execute unless data entity @n[type=item_display, tag=dawn.smeltery, distance=...5] {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} unless predicate dawn:smeltery/work run tag @n[type=item_display, tag=dawn.smeltery, distance=...5] add dawn.smeltery.work

# 重置GUI
function dawn:smeltery/gui

# 清除
execute unless block ~ ~ ~ minecraft:barrel run kill @s
