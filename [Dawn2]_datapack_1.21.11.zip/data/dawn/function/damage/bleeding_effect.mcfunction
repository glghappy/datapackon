
execute store result storage dawn.entity bleeding float 0.04 run data get entity @s Health

function dawn:damage/bleeding_effect2 with storage dawn.entity

scoreboard players reset @s dawn.effect.bleeding_cd