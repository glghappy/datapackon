
scoreboard players set @s dawn.enchantment.attack_palsy 20