
execute if function dawn:smeltery/recipe/copper_vanilla run return 1
execute if function dawn:smeltery/recipe/gold_vanilla run return 1

execute if function dawn:smeltery/recipe/copper run return 1
execute if function dawn:smeltery/recipe/gold run return 1
execute if function dawn:smeltery/recipe/iron run return 1
execute if function dawn:smeltery/recipe/steel run return 1
execute if function dawn:smeltery/recipe/rose_gold run return 1
execute if function dawn:smeltery/recipe/ancient_metal run return 1
