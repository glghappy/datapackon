
effect give @s minecraft:slowness 18 1 false
effect give @s minecraft:weakness 18 0 false
