
# 显示成品

# 复制物品
item replace block ~ ~ ~ container.16 from block ~ ~ ~ container.10



# 提升等级 （dawn.anvil.item.quality）
execute store result storage dawn:input quality int 1 run scoreboard players add @s dawn.anvil.item.quality 1
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".quality.level set from storage dawn:input quality



# 提升强化槽 (dawn.anvil.item.enhancement)
scoreboard objectives add dawn.anvil.item.enhancement dummy
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".enhancement_slot
scoreboard players add @s dawn.anvil.item.enhancement 1
execute if score @s dawn.anvil.item.quality matches 6 run scoreboard players add @s dawn.anvil.item.enhancement 1
execute store result storage dawn:input enhancement int 1 run scoreboard players get @s dawn.anvil.item.enhancement
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".enhancement_slot set from storage dawn:input enhancement



# 提升基础强化槽 (dawn.anvil.item.enhancement)
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".quality.base_enhancement_slot
scoreboard players add @s dawn.anvil.item.enhancement 1
execute if score @s dawn.anvil.item.quality matches 6 run scoreboard players add @s dawn.anvil.item.enhancement 1
execute store result storage dawn:input base_enhancement int 1 run scoreboard players get @s dawn.anvil.item.enhancement
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".quality.base_enhancement_slot set from storage dawn:input base_enhancement



# 记录耗材
execute store result storage dawn:input material_cost int 1 run scoreboard players get @s dawn.anvil.item.upgrade.count
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_cost set from storage dawn:input material_cost



# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_upgrade set value true



# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true



# 记录失败
execute if score @s dawn.anvil.item.quality matches 2 if predicate dawn:random/0.2 run data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_quality_fail set value true
execute if score @s dawn.anvil.item.quality matches 3 if predicate dawn:random/0.4 run data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_quality_fail set value true
execute if score @s dawn.anvil.item.quality matches 4 if predicate dawn:random/0.6 run data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_quality_fail set value true
execute if score @s dawn.anvil.item.quality matches 5 if predicate dawn:random/0.8 run data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_quality_fail set value true
execute if score @s dawn.anvil.item.quality matches 6 if predicate dawn:random/0.9 run data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_quality_fail set value true



# 修改lore
# 品质
execute if score @s dawn.anvil.item.quality matches 0 run data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[1] set value '{"translate": "lore.dawn.qualitylevel.0", "color": "gray", "italic": false}'
execute if score @s dawn.anvil.item.quality matches 1 run data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[1] set value '{"translate": "lore.dawn.qualitylevel.1", "color": "gray", "italic": false}'
execute if score @s dawn.anvil.item.quality matches 2 run data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[1] set value '{"translate": "lore.dawn.qualitylevel.2", "color": "gray", "italic": false}'
execute if score @s dawn.anvil.item.quality matches 3 run data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[1] set value '{"translate": "lore.dawn.qualitylevel.3", "color": "gray", "italic": false}'
execute if score @s dawn.anvil.item.quality matches 4 run data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[1] set value '{"translate": "lore.dawn.qualitylevel.4", "color": "gray", "italic": false}'
execute if score @s dawn.anvil.item.quality matches 5 run data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[1] set value '{"translate": "lore.dawn.qualitylevel.5", "color": "gray", "italic": false}'
execute if score @s dawn.anvil.item.quality matches 6 run data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[1] set value '{"translate": "lore.dawn.qualitylevel.6", "color": "gray", "italic": false}'



# 修改强化槽
function dawn:anvil/function/modify_enhancement_slot with storage dawn:input

