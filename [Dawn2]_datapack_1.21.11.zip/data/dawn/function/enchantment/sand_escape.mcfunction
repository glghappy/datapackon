particle minecraft:block{block_state:sand} ~ ~1 ~ 0.5 0.5 0.5 1 20 normal

spreadplayers ~ ~ 8 8 under 0 false @s