kill @s[type=item, nbt={Item:{id:"minecraft:amethyst_shard", count:1}}]

execute store result storage dawn:item count int 0.99 run data get entity @s Item.count

data modify entity @s Item.count set from storage dawn:item count

loot spawn ~ ~ ~ loot dawn:empty_crystal_shard
