
execute if items block ~ ~ ~ container.19 minecraft:coal run return 1

execute if score @s dawn.smeltery.fuel_level matches 1 run return 1
