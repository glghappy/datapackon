
# execute if score #fatal_poison dawn.gamerule matches 1 run function dawn:damage/poison_main

# execute as @e[scores={dawn.effect.bleeding=1..}] run function dawn:damage/bleeding_main



# by：Minecraft_hyr

execute if score #fatal_poison dawn.gamerule matches 1 run function dawn:damage/poison_main

execute as @e[type=!#dawn:non_living, scores={dawn.effect.bleeding=1..}] run function dawn:damage/bleeding_main