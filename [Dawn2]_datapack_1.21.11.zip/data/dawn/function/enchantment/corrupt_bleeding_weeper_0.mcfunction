fill ~-1 ~ ~-1 ~1 ~5 ~1 air destroy

