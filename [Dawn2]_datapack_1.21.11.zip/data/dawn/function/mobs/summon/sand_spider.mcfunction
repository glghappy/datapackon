
# Sand Spider 沙蛛
summon minecraft:spider ~ ~ ~ {CustomName: "Sand Spider", Tags: ["summon", "sand_spider"], Health: 12.0f, equipment: {feet: {components: {"!minecraft:attribute_modifiers": {}, "minecraft:equippable": {equip_sound: "minecraft:block.stone.hit", slot: "feet", asset_id: "dawn:air"}, "!minecraft:enchantable": {}, "minecraft:item_model": "minecraft:barrier", "!minecraft:repairable": {}, "minecraft:enchantments": {"minecraft:sand_escape": 1}, "!minecraft:max_damage": {}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_name": {}, "!minecraft:damage": {}}, count: 1, id: "minecraft:leather_boots"}}, drop_chances: {mainhand: 0.0f, head: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, attributes: [{id: "minecraft:max_health", base: 12.0d}, {id: "minecraft:movement_speed", base: 0.32d}, {id: "minecraft:scale", base: 0.8d}]}

tp @s ~ -255 ~

kill @s