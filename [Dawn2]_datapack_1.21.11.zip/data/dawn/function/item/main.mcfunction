
# elytra
execute as @e[type=item, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:elytra"}}] at @s unless entity @s[type=item, nbt={Item:{id:"minecraft:elytra", components:{"minecraft:custom_data":{"id": "dawn:elytra"}}}}] run function dawn:item/elytra

# amethyst_shard
execute as @e[type=item, nbt={Item:{id:"minecraft:amethyst_shard"}}] at @s if block ~ ~ ~ water_cauldron[level=3] run function dawn:item/amethyst_shard

