
execute if predicate dawn:smeltery/input/cobblestone if score @s dawn.smeltery.fuel_level matches 1..4 run scoreboard players add @s dawn.smeltery.craft_time 3

execute if predicate dawn:smeltery/input/mithril if score @s dawn.smeltery.fuel_level matches 2..4 run scoreboard players add @s dawn.smeltery.craft_time 3

execute if predicate dawn:smeltery/input/vibranium if score @s dawn.smeltery.fuel_level matches 3..4 run scoreboard players add @s dawn.smeltery.craft_time 3

execute if predicate dawn:smeltery/input/adamantium if score @s dawn.smeltery.fuel_level matches 4 run scoreboard players add @s dawn.smeltery.craft_time 3