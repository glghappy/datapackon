advancement revoke @s only dawn:soul_blood_totem

scoreboard objectives add dawn.soul_blood_totem dummy

#
execute store result score #entity dawn.soul_blood_totem run attribute @s minecraft:max_health modifier value get soul_blood_totem
execute store result storage dawn:entity soul_blood_totem byte 1 run scoreboard players remove #entity dawn.soul_blood_totem 2

function dawn:player/attribute/soul_blood_totem with storage dawn:entity

#
execute if items entity @s container.* minecraft:zombie_head run return run function dawn:player/soul_blood_totem_add
execute if items entity @s weapon.offhand minecraft:zombie_head run function dawn:player/soul_blood_totem_add