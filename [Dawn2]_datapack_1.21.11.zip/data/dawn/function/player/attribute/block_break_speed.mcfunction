
attribute @s minecraft:block_break_speed modifier remove level.block_break_speed

$attribute @s minecraft:block_break_speed modifier add level.block_break_speed $(block_break_speed) add_multiplied_base
