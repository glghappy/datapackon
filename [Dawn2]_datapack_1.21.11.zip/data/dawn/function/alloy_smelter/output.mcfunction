
# 清除烧制状态
data modify entity @s item.components."minecraft:custom_data".smelting set value false

# 清除合成时间
scoreboard players set @s dawn.alloy_smelter.craft_time 0

# 清除原料
item replace block ~ ~ ~ container.1 with air
item replace block ~ ~ ~ container.2 with air
item replace block ~ ~ ~ container.3 with air

# 掉落物品
data modify storage dawn:alloy_smelter material set from entity @s item.components."minecraft:custom_data".output_material

function dawn:alloy_smelter/loot with storage dawn:alloy_smelter
