
tag @s add summon

attribute @s minecraft:max_health base set 16
data modify entity @s Health set value 16
