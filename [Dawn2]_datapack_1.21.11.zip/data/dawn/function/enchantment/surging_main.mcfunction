# attribute
attribute @s minecraft:movement_speed modifier remove surging.movement_speed
attribute @s minecraft:attack_damage modifier remove surging.attack_damage
attribute @s minecraft:attack_speed modifier remove surging.attack_speed

# execute as @s[scores={dawn.enchantment.surging=50..}] run function dawn:enchantment/surging_effect

scoreboard players remove @s[tag=disengage, scores={dawn.enchantment.surging=1..}] dawn.enchantment.surging 1

# particle
# execute if score @s dawn.enchantment.surging matches 50..69 run particle dust{color:[0.01, 0.518, 0.99], scale:0.5} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal
# execute if score @s dawn.enchantment.surging matches 70..89 run particle dust{color:[0.01, 0.235, 0.99], scale:0.5} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal
# execute if score @s dawn.enchantment.surging matches 90.. run particle dust{color:[0.4, 0.01, 0.99], scale:0.5} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal

