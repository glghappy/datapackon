advancement revoke @s only dawn:player/disengage

# tellraw @s "您已失去脱战状态"

scoreboard players set @s dawn.player.disengage 600
