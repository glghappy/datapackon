
tag @s add sell_3

# 5
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:1, id:"minecraft:lava_bucket"}, priceMultiplier: 0.05f, xp:15}

# 6
function dawn:mobs/villager/armorer_3_1
execute if predicate dawn:random/0.5 run function dawn:mobs/villager/armorer_3_2

item replace entity @s armor.head with air
