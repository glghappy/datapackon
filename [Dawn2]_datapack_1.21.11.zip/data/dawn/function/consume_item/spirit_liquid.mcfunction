advancement revoke @s only dawn:consume_item/spirit_liquid

attribute @s minecraft:max_health modifier remove enchantment.sectumsempra

#
execute store result score #entity dawn.soul_blood_totem run attribute @s minecraft:max_health modifier value get soul_blood_totem
execute if score #entity dawn.soul_blood_totem matches ..-2 run scoreboard players add #entity dawn.soul_blood_totem 2
execute store result storage dawn:entity soul_blood_totem byte 1 run scoreboard players get #entity dawn.soul_blood_totem

function dawn:player/attribute/soul_blood_totem with storage dawn:entity