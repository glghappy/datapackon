# 重置烧炼状态
data modify entity @s item.components."minecraft:custom_data".smelting set value false

# 
execute as @n[tag=dawn.smeltery, type=marker] run function dawn:smeltery/gui_part
