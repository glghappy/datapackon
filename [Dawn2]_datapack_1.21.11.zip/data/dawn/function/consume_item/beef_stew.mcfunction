advancement revoke @s only dawn:consume_item/beef_stew

scoreboard players add @s dawn.player.protein 131789
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000

scoreboard players add @s dawn.player.phytonutrients 14643
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
