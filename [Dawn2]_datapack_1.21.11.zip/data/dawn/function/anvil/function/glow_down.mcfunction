
# 获取成功
scoreboard objectives add dawn.anvil.item.enchantment_glint_override dummy
execute store result score @s dawn.anvil.item.enchantment_glint_override run data get block ~ ~ ~ Items[{Slot:10b}].components.minecraft:enchantment_glint_override
execute if score @s dawn.anvil.item.enchantment_glint_override matches 1 run function dawn:anvil/function/glow_down2
