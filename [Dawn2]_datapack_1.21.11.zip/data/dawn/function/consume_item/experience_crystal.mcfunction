advancement revoke @s only dawn:consume_item/experience_crystal

xp add @s 100 points