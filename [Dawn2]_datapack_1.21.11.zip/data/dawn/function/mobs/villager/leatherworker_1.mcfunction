
tag @s add sell_1

# 1
data modify entity @s Offers.Recipes[-2] set value {maxUses:16, sell:{count:1, id:"minecraft:emerald"}, buy:{count:6, id:"minecraft:leather"}, priceMultiplier: 0.05f, demand:-16, xp:2}

# 2
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:stone"}, buy:{count:7, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:1}
loot replace entity @s armor.head loot dawn:armor/leather_chestplate
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head

item replace entity @s armor.head with air
