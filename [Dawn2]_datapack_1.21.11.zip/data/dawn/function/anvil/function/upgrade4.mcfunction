
$execute store result storage dawn:input max_damage int $(quality_multiply) run data get block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:max_damage"

# $say $(quality_multiply)