
playsound minecraft:entity.iron_golem.death hostile @a ~ ~ ~ 0.5

kill @s