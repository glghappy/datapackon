
attribute @s minecraft:movement_speed modifier remove enchantment.dash
attribute @s minecraft:jump_strength modifier remove enchantment.dash

$attribute @s minecraft:movement_speed modifier add enchantment.dash $(enchantment_dash) add_multiplied_total
$attribute @s minecraft:jump_strength modifier add enchantment.dash $(enchantment_dash2) add_multiplied_total