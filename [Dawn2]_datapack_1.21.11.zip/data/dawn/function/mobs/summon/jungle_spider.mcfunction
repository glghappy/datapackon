
# Jungle Spider 丛林蜘蛛
summon minecraft:spider ~ ~ ~ {CustomName: "Jungle Spider", Tags: ["summon", "jungle_spider"], Health: 8.0f, equipment: {mainhand: {components: {"minecraft:max_stack_size": 1, "minecraft:enchantments": {"minecraft:attack_weakness": 1}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_model": {}, "!minecraft:item_name": {}}, count: 1, id: "minecraft:firework_star"}}, drop_chances: {mainhand: 0.0f, head: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, attributes: [{id: "minecraft:max_health", base: 8.0d}, {id: "minecraft:movement_speed", base: 0.3d}, {id: "minecraft:scale", base: 0.7d}]}

tp @s ~ -255 ~

kill @s