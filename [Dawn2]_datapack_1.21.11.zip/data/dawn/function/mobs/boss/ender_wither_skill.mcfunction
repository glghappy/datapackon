
tag @s add tagged

data modify entity @s acceleration_power set value 0.25
data modify entity @s dangerous set value true

summon fireball ~ ~ ~

data modify entity @n[type=fireball] Motion set from entity @s Motion
data modify entity @n[type=fireball] UUID set from entity @s UUID
data modify entity @n[type=fireball] acceleration_power set value 0.15
data modify entity @n[type=fireball] ExplosionPower set value 2

summon splash_potion ~ ~ ~ {Item: {components: {"minecraft:potion_contents": {potion: "minecraft:harming"}}, count: 1, id: "minecraft:splash_potion"}}
data modify entity @n[type=splash_potion] Motion set from entity @s Motion
data modify entity @n[type=splash_potion] UUID set from entity @s UUID