
scoreboard players set @s dawn.enchantment.enderman_repression 160
