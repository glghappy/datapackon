advancement revoke @s only dawn:consume_item/poisonous_potato

scoreboard players add @s dawn.player.phytonutrients 4000
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
