
# effect
execute as @s[scores={dawn.enchantment.surging=50..}] run function dawn:enchantment/surging_effect

# particle
execute if score @s dawn.enchantment.surging matches 50..69 run particle dust{color:[0.01, 0.518, 0.99], scale:0.5} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal
execute if score @s dawn.enchantment.surging matches 70..89 run particle dust{color:[0.01, 0.235, 0.99], scale:0.5} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal
execute if score @s dawn.enchantment.surging matches 90.. run particle dust{color:[0.4, 0.01, 0.99], scale:0.5} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal
