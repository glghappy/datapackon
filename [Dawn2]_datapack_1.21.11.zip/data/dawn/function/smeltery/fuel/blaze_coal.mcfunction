
execute if items block ~ ~ ~ container.19 *[item_model="dawn:blaze_coal"] run return 1
