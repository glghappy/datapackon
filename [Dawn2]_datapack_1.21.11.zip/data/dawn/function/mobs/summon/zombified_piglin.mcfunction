
# tag
tag @s add summon


# summon

# Infernal Creeper 地狱苦力怕
execute if dimension minecraft:the_nether if predicate dawn:random/0.1 run return run function dawn:mobs/summon/infernal_creeper

# Demon Spider 恶魔蜘蛛
execute if dimension minecraft:the_nether if predicate dawn:random/0.1 run return run function dawn:mobs/summon/demon_spider

# Earth Elemental N (ban_transform)(equipment)(silent)
execute if dimension minecraft:the_nether if predicate dawn:random/0.08 run return run function dawn:mobs/summon/earth_elemental_n


# attribute
attribute @s minecraft:attack_damage base set 8


# weapon
execute if items entity @s weapon.mainhand golden_sword[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:weapon/zombified_piglin
