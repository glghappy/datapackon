
weather thunder 30s
