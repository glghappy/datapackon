
attribute @s minecraft:movement_speed modifier remove neg_level.movement_speed

$attribute @s minecraft:movement_speed modifier add neg_level.movement_speed $(movement_speed) add_multiplied_base
