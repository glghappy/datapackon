
execute store result score @s dawn.entity.health run data get entity @s Health
execute as @s[tag=!level2] if score @s dawn.entity.health matches ..300 run function dawn:mobs/boss/wither_change


execute store result score @s dawn.entity.health run data get entity @s Health
execute as @s[tag=level2, tag=!level3] if score @s dawn.entity.health matches ..300 \
unless score #day dawn.day matches 1 \
unless score #calculate2 dawn.day matches 1 \
if score #calculate1 dawn.day matches 1 \

