
# 获取强化槽 (dawn.anvil.item.enhancement)
scoreboard objectives add dawn.anvil.item.enhancement dummy
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".enhancement_slot

execute if score @s dawn.anvil.item.enhancement matches 1.. run function dawn:anvil/function/enchantment2
# execute if score @s dawn.anvil.item.enhancement matches 1.. run say hi