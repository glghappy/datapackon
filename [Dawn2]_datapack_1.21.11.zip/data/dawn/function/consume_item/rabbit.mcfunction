advancement revoke @s only dawn:consume_item/rabbit

scoreboard players add @s dawn.player.protein 16224
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000
