# place item_display and barrel
execute as @e[tag=dawn.alloy_smelter, type=glow_item_frame] at @s run function dawn:alloy_smelter/place

# # marker
# execute as @e[tag=dawn.alloy_smelter, type=marker] at @s unless predicate dawn:alloy_smelter/gui run function dawn:alloy_smelter/marker

# marker
execute as @e[tag=dawn.alloy_smelter, type=marker, predicate=!dawn:alloy_smelter/gui] at @s run function dawn:alloy_smelter/marker

# item_display (break)
execute as @e[tag=dawn.alloy_smelter, type=item_display] at @s run function dawn:alloy_smelter/item_display
