# 排列 1: 槽位顺序 (container.1 -> container.2 -> container.3)
execute \
if items block ~ ~ ~ container.1 *[count=1, item_model="dawn:blaze_crystal"] \
if items block ~ ~ ~ container.2 *[count=4, item_model="dawn:steel_ingot"] \
if items block ~ ~ ~ container.3 minecraft:lava_bucket[count=1] \
run return 1

# 排列 2: 槽位顺序 (container.1 -> container.3 -> container.2)
execute \
if items block ~ ~ ~ container.1 *[count=1, item_model="dawn:blaze_crystal"] \
if items block ~ ~ ~ container.3 *[count=4, item_model="dawn:steel_ingot"] \
if items block ~ ~ ~ container.2 minecraft:lava_bucket[count=1] \
run return 1

# 排列 3: 槽位顺序 (container.2 -> container.1 -> container.3)
execute \
if items block ~ ~ ~ container.2 *[count=1, item_model="dawn:blaze_crystal"] \
if items block ~ ~ ~ container.1 *[count=4, item_model="dawn:steel_ingot"] \
if items block ~ ~ ~ container.3 minecraft:lava_bucket[count=1] \
run return 1

# 排列 4: 槽位顺序 (container.2 -> container.3 -> container.1)
execute \
if items block ~ ~ ~ container.2 *[count=1, item_model="dawn:blaze_crystal"] \
if items block ~ ~ ~ container.3 *[count=4, item_model="dawn:steel_ingot"] \
if items block ~ ~ ~ container.1 minecraft:lava_bucket[count=1] \
run return 1

# 排列 5: 槽位顺序 (container.3 -> container.1 -> container.2)
execute \
if items block ~ ~ ~ container.3 *[count=1, item_model="dawn:blaze_crystal"] \
if items block ~ ~ ~ container.1 *[count=4, item_model="dawn:steel_ingot"] \
if items block ~ ~ ~ container.2 minecraft:lava_bucket[count=1] \
run return 1

# 排列 6: 槽位顺序 (container.3 -> container.2 -> container.1)
execute \
if items block ~ ~ ~ container.3 *[count=1, item_model="dawn:blaze_crystal"] \
if items block ~ ~ ~ container.2 *[count=4, item_model="dawn:steel_ingot"] \
if items block ~ ~ ~ container.1 minecraft:lava_bucket[count=1] \
run return 1

