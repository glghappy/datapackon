
# GUI
item replace block ~ ~ ~ container.0 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:anvil_gui"]
item replace block ~ ~ ~ container.1 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:anvil_durability_0"]

item replace block ~ ~ ~ container.2 with firework_star[minecraft:item_name="", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.3 with firework_star[minecraft:item_name="", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.4 with firework_star[minecraft:item_name="", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.5 with firework_star[minecraft:item_name="", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.6 with firework_star[minecraft:item_name="", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.7 with firework_star[minecraft:item_name="", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]

item replace block ~ ~ ~ container.8 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.9 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]

item replace block ~ ~ ~ container.11 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.12 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]

item replace block ~ ~ ~ container.14 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.15 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]

item replace block ~ ~ ~ container.17 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.18 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.19 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.20 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.21 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.22 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.23 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:anvil_button"]
item replace block ~ ~ ~ container.24 with firework_star[minecraft:item_name="锻造", minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.25 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.26 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]

# 耐久显示
execute as @n[type=item_display, tag=dawn.anvil] at @s run function dawn:anvil/durability