
$loot replace block ~ ~ ~ container.16 loot dawn:$(folder)/$(material)_$(type)

$data modify block ~ ~ ~ Items.[{Slot:16b}].count set value $(count)