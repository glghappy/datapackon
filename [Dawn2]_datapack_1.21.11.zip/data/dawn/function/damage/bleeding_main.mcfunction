
scoreboard players remove @s dawn.effect.bleeding 1

scoreboard players add @s dawn.effect.bleeding_cd 1

execute if score @s dawn.effect.bleeding_cd matches 25.. run function dawn:damage/bleeding_effect

scoreboard players reset @s[scores={dawn.effect.bleeding=0}] dawn.effect.bleeding_cd