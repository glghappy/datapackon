advancement revoke @s only dawn:consume_item/tropical_fish

scoreboard players add @s dawn.player.protein 3536
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000
