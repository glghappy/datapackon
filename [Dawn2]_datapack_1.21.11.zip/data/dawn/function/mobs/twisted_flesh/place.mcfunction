
#
summon minecraft:item_display ~ ~0.45 ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:twisted_flesh_entity", item_name:{"translate": "item.dawn.twisted_flesh"}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[0.75f, 0.9f, 0.75f]}, brightness:{sky:15, block:0}, Tags:["dawn.twisted_flesh"], view_range:8}

kill @s