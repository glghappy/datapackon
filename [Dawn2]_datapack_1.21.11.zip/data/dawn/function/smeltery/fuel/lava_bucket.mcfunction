
execute if items block ~ ~ ~ container.19 minecraft:lava_bucket run return 1
