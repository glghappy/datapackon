
#
tag @s remove dawn.smeltery.work

# 检测是否可烧炼
execute if data entity @s {item:{components:{"minecraft:custom_data":{"can_work": 1b}}}} run data modify entity @s item.components."minecraft:custom_data".smelting set value true

execute if data entity @s {item:{components:{"minecraft:custom_data":{"can_work": 1b}}}} as @n[tag=dawn.smeltery, type=marker] run function dawn:smeltery/gui

