
execute if items block ~ ~ ~ container.19 minecraft:coal run return 1
