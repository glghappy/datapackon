
# 获取铁砧损坏形式 ["anvil", "chipped_anvil", "damaged_anvil"]
data modify storage dawn:anvil anvil_type set value 'anvil'
execute if score @s dawn.anvil.durability.op matches 34..66 run data modify storage dawn:anvil anvil_type set value 'chipped_anvil'
execute if score @s dawn.anvil.durability.op matches 0..33 run data modify storage dawn:anvil anvil_type set value 'damaged_anvil'

# 获取材质（material）
data modify storage dawn:anvil anvil_material set from entity @n[type=minecraft:item_display] item.components."minecraft:custom_data".anvil.material

# 改变材质
function dawn:anvil/anvil_item_model_change with storage dawn:anvil
