
$data modify block ~ ~ ~ Items.[{Slot: 1b}].components."minecraft:item_model" set value 'dawn:anvil_durability_$(durability_show)'
