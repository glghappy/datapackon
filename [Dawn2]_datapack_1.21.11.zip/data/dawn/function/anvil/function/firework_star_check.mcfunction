
execute if data block ~ ~ ~ Items[{Slot:13b, id:"minecraft:firework_star"}] run return 1

return fail