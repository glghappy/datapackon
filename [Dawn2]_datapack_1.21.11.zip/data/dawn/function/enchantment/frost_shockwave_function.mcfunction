
attribute @s minecraft:movement_speed modifier add enchantment.frost_shockwave -0.3 add_multiplied_total

attribute @s minecraft:attack_speed modifier add enchantment.frost_shockwave -0.3 add_multiplied_total
