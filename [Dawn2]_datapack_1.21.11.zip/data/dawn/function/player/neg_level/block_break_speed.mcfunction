
attribute @s minecraft:block_break_speed modifier remove neg_level.block_break_speed

$attribute @s minecraft:block_break_speed modifier add neg_level.block_break_speed $(block_break_speed) add_multiplied_base
