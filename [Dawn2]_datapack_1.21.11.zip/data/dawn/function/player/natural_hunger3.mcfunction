effect give @s hunger 1 29 true

scoreboard players reset @s dawn.player.natural_hunger