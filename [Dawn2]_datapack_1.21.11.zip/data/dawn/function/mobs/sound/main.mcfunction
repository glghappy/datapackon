
# phase_spider
execute as @e[tag=phase_spider, nbt={HurtTime:9s}] at @s run playsound dawn:mobs.phase_spider.hurt hostile @a ~ ~ ~ 0.5
execute as @e[type=item, nbt={Item:{components:{"minecraft:custom_data":{"phase_spider": true}}}}] at @s run function dawn:mobs/sound/phase_spider_death


# ghoul
execute as @e[tag=ghoul, nbt={HurtTime:9s}] at @s run playsound dawn:mobs.ghoul.hurt hostile @a ~ ~ ~ 0.5
execute as @e[type=item, nbt={Item:{components:{"minecraft:custom_data":{"ghoul": true}}}}] at @s run function dawn:mobs/sound/ghoul_death


# earth_elemental
execute as @e[tag=earth_elemental, nbt={HurtTime:9s}] at @s run playsound minecraft:entity.iron_golem.hurt hostile @a ~ ~ ~ 0.5
execute as @e[type=item, nbt={Item:{components:{"minecraft:custom_data":{"earth_elemental": true}}}}] at @s run function dawn:mobs/sound/earth_elemental_death

