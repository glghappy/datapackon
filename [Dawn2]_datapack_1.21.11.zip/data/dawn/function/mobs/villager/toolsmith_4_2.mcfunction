
data modify entity @s Offers.Recipes[-1] set value {maxUses:6, sell:{count:1, id:"minecraft:stone"}, buy:{count:11, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:15}
loot replace entity @s armor.head loot dawn:tool/steel_wooden_battle_axe
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head
