
tag @s add summon

attribute @s minecraft:attack_damage base set 9