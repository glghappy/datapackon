tellraw @s {"text": "--------------------------------------------------"}
tellraw @s {"translate":"broadcast.dawn.installed_datapack"}
tellraw @s {"translate":"broadcast.dawn.installed_resourcepack", "fallback":"您 未 安 装 资 源 包 ！ ！ ！"}
tellraw @s {"text": "--------------------------------------------------"}
tellraw @s {"translate":"broadcast.dawn.author_mite"}
tellraw @s {"translate":"broadcast.dawn.author_dawn"}
tellraw @s [{"translate":"broadcast.dawn.bilibili"},{"text": "https://space.bilibili.com/123355042","color": "blue","underlined": true,"click_event":{"action":"open_url","url":"https://space.bilibili.com/123355042"}}]
tellraw @s [{"translate":"broadcast.dawn.douyin"},{"text": "https://www.douyin.com/user/heyejun","color": "blue","underlined": true,"click_event":{"action":"open_url","url":"https://www.douyin.com/user/MS4wLjABAAAAXL3JVLNdyIVQwA4qKOuWcsmRmUwKsRglffXuaejB2XI"}}]
tellraw @s {"translate":"broadcast.dawn.free"}
tellraw @s {"text": "--------------------------------------------------"}
