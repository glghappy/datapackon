fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:torch
fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:wall_torch
fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:soul_torch
fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:soul_wall_torch
fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:redstone_torch
fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:redstone_wall_torch
fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:light