
tag @s add sell_1

# 1
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:15, id:"minecraft:coal"}, priceMultiplier: 0.05f, demand:-16, xp:2}

# 2
function dawn:mobs/villager/toolsmith_1_1
execute if predicate dawn:random/0.5 run function dawn:mobs/villager/toolsmith_1_2
execute if predicate dawn:random/0.33 run function dawn:mobs/villager/toolsmith_1_3
execute if predicate dawn:random/0.25 run function dawn:mobs/villager/toolsmith_1_4
execute if predicate dawn:random/0.2 run function dawn:mobs/villager/toolsmith_1_5

item replace entity @s armor.head with air
