
# 检测耗材

# 获取原料份数 (dawn.anvil.item.count)
scoreboard objectives add dawn.anvil.item.count dummy
execute store result score @s dawn.anvil.item.count run data get block ~ ~ ~ Items[{Slot:13b}].count

# 获取强化所需份数 (dawn.anvil.item.upgrade.count)
scoreboard objectives add dawn.anvil.item.upgrade.count dummy
execute store result score @s dawn.anvil.item.upgrade.count run data get block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".upgrade.count

# 成功
# execute if score @s dawn.anvil.item.count >= @s dawn.anvil.item.upgrade.count run say "原料充足"
execute if score @s dawn.anvil.item.count >= @s dawn.anvil.item.upgrade.count run function dawn:anvil/function/upgrade3
