# 如果生命值未满
execute store result score @s dawn.player.max_health run attribute @s max_health get
execute if score @s dawn.player.health < @s dawn.player.max_health run function dawn:player/natural_regeneration4

scoreboard players reset @s dawn.player.natural_regeneration