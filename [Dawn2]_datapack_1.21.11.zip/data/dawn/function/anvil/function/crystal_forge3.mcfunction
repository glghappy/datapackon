
# 显示成品

# 复制物品
item replace block ~ ~ ~ container.16 from block ~ ~ ~ container.10

# 记录耗材
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_cost set from block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".experience_crystal.cost

# 耗材翻倍
execute store result storage dawn:input experience_crystal int 2 run data get block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".experience_crystal.cost
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".experience_crystal.cost set from storage dawn:input experience_crystal

# 提升强化槽 (dawn.anvil.item.enhancement)
scoreboard objectives add dawn.anvil.item.enhancement dummy
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".enhancement_slot
scoreboard players add @s dawn.anvil.item.enhancement 1
execute store result storage dawn:input enhancement int 1 run scoreboard players get @s dawn.anvil.item.enhancement
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".enhancement_slot set from storage dawn:input enhancement

# 修改强化槽
function dawn:anvil/function/modify_enhancement_slot with storage dawn:input

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_crystal set value true

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
