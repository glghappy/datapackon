# crossbow （off在上，防止主手损坏时检测到副手）
execute if predicate dawn:player/crossbow_offhand as @e[type=#minecraft:arrows,distance=..8,sort=nearest,limit=1,nbt={inGround:0b},tag=!tagged] run function dawn:player/bow/offhand
execute if predicate dawn:player/crossbow_mainhand as @e[type=#minecraft:arrows,distance=..8,sort=nearest,limit=1,nbt={inGround:0b},tag=!tagged] run function dawn:player/bow/mainhand

scoreboard players reset @s dawn.player.used_crossbow
