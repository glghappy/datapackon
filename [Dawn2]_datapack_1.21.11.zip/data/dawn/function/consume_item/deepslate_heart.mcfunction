advancement revoke @s only dawn:consume_item/deepslate_heart

scoreboard players add @s dawn.effect.deepslate_heart 320
