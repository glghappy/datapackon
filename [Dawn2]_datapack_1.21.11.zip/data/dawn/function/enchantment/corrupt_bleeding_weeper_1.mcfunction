
execute as @e[distance=..16, type=!#minecraft:undead, type=!silverfish] run effect give @s wither 2 1 false