
attribute @s minecraft:max_health modifier remove enchantment.sectumsempra
$attribute @s minecraft:max_health modifier add enchantment.sectumsempra $(sectumsempra) add_value