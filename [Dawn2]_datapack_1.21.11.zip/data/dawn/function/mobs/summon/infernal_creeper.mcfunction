
# Infernal Creeper 地狱苦力怕
summon minecraft:creeper ~ ~ ~ {CustomName: "Infernal Creeper", Tags: ["summon", "infernal_creeper"], Fuse: 20s, ExplosionRadius: 8b, Health: 30.0f, drop_chances: {mainhand: 0.0f, head: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, attributes: [{id: "minecraft:max_health", base: 30.0d}, {id: "minecraft:burning_time", base: 1.0d}, {id: "minecraft:movement_speed", base: 0.25d}], equipment: {feet: {components: {"!minecraft:attribute_modifiers": {}, "minecraft:equippable": {equip_sound: "minecraft:block.stone.hit", slot: "feet", asset_id: "dawn:air"}, "!minecraft:enchantable": {}, "minecraft:item_model": "minecraft:barrier", "!minecraft:repairable": {}, "minecraft:enchantments": {"minecraft:fire_immunity": 1}, "!minecraft:max_damage": {}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_name": {}, "!minecraft:damage": {}}, count: 1, id: "minecraft:leather_boots"}}, DeathLootTable: "dawn:entities/infernal_creeper"}

tp @s ~ -255 ~

kill @s