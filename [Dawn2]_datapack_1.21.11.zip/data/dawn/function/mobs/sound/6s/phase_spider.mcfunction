schedule function dawn:mobs/sound/6s/phase_spider 6s

execute as @e[tag=phase_spider] at @s run playsound dawn:mobs.phase_spider.say hostile @a ~ ~ ~ 0.4