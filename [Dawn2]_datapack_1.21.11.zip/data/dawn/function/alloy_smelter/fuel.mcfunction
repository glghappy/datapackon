
$scoreboard players set @s dawn.alloy_smelter.fuel_time $(fuel_time)

item modify block ~ ~ ~ container.20 dawn:remove_1
