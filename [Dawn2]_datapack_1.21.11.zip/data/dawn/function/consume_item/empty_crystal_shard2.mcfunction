
xp add @s -100 points

loot spawn ~ ~ ~ loot dawn:experience_crystal

data modify entity @n[type=item, nbt={Item:{components:{"minecraft:item_model":"dawn:experience_crystal"}}}] PickupDelay set value 0
