
scoreboard players add @s dawn.enchantment.truce 80