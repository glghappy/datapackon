
scoreboard objectives add dawn.alloy_smelter.fuel_time dummy

scoreboard objectives add dawn.alloy_smelter.craft_finish dummy

scoreboard objectives add dawn.alloy_smelter.craft_time dummy

scoreboard objectives add dawn.alloy_smelter.craft_calculate dummy

scoreboard objectives add dawn.alloy_smelter.craft_show dummy

