
attribute @s[level=..4] minecraft:max_health base set 6

attribute @s[level=5..9] minecraft:max_health base set 8

attribute @s[level=10..14] minecraft:max_health base set 10

attribute @s[level=15..19] minecraft:max_health base set 12

attribute @s[level=20..24] minecraft:max_health base set 14

attribute @s[level=25..29] minecraft:max_health base set 16

attribute @s[level=30..34] minecraft:max_health base set 18

attribute @s[level=35..] minecraft:max_health base set 20
