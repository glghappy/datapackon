
execute if block ~1 ~ ~ light run setblock ~1 ~ ~ air
execute if block ~-1 ~ ~ light run setblock ~-1 ~ ~ air
execute if block ~ ~1 ~ light run setblock ~ ~1 ~ air
execute if block ~ ~-1 ~ light run setblock ~ ~-1 ~ air
execute if block ~ ~ ~1 light run setblock ~ ~ ~1 air
execute if block ~ ~ ~-1 light run setblock ~ ~ ~-1 air
