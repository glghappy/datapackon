
# by：Minecraft_hyr

attribute @s minecraft:movement_speed modifier remove stun.movement_speed
attribute @s minecraft:jump_strength modifier remove stun.jump_strength
attribute @s minecraft:attack_damage modifier remove stun.attack_damage
attribute @s minecraft:attack_speed modifier remove stun.attack_speed
