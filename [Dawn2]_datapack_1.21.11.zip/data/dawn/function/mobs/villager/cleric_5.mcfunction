
tag @s add sell_5

# 是血月
execute unless score #day dawn.day matches 1 \
unless score #calculate2 dawn.day matches 1 \
if score #calculate1 dawn.day matches 1 \
run function dawn:mobs/villager/cleric_5_2
