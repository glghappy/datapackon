
scoreboard players remove @s[scores={dawn.enchantment.momentum.time=1..}] dawn.enchantment.momentum.time 1

scoreboard players reset @s[scores={dawn.enchantment.momentum.time=..0}] dawn.enchantment.momentum
scoreboard players reset @s[scores={dawn.enchantment.momentum.time=..0}] dawn.enchantment.momentum.time

execute store result storage dawn:player enchantment_momentum int 1 run scoreboard players get @s dawn.enchantment.momentum
function dawn:enchantment/momentum_function with storage dawn:player
