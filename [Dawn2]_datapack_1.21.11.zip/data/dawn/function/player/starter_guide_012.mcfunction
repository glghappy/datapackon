
loot give @s loot dawn:starter_guide