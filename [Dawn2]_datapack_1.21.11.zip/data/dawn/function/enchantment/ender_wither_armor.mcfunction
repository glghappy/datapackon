fill ~-2 ~ ~-2 ~2 ~3 ~2 air destroy

weather thunder 10t