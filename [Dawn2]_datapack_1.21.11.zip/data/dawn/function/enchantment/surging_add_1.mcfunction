
advancement revoke @s only dawn:enchantment/surging_add_1

scoreboard players add @s dawn.enchantment.surging 5
scoreboard players set @s[scores={dawn.enchantment.surging=100..}] dawn.enchantment.surging 100