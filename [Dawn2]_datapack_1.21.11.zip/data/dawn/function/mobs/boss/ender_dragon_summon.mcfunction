tag @s add summon

attribute @s max_health base set 1000
attribute @s armor base set 8

data modify entity @s Health set value 1000