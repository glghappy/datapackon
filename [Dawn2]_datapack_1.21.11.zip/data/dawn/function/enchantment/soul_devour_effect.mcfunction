
function dawn:enchantment/soul_devour_effect_2 with storage dawn:entity

particle dust{color:[1, 0.1, 0.1], scale:0.6} ~ ~1 ~ 0.5 0.6 0.5 0 20 normal

