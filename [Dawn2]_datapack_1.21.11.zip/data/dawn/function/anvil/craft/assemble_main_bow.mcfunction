
# 获取材质
data modify storage dawn:anvil_item_model bow_material set from block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".material.type

# 合成物品
function dawn:anvil/craft/assemble_loot_bow with storage dawn:anvil_item_model
