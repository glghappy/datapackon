advancement revoke @s only dawn:consume_item/echo_scroll

execute store result score @s dawn.locate run locate structure minecraft:ancient_city

tellraw @s[scores={dawn.locate=1..}] [{"translate":"broadcast.dawn.ancient_city", "color": "white", "italic": false, "with": [{"score": {"name": "@s","objective": "dawn.locate"}}]}]

tellraw @s[scores={dawn.locate=0}] [{"translate":"broadcast.dawn.no", "color": "red", "italic": false}]
