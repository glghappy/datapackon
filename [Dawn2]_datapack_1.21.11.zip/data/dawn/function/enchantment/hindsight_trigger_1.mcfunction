
# advancement revoke @s only dawn:enchantment/hindsight_1

effect give @s resistance 3 1 false
