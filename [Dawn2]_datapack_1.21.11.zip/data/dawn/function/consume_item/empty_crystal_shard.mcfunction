advancement revoke @s only dawn:consume_item/empty_crystal_shard

execute as @s[level=8..] run return run function dawn:consume_item/empty_crystal_shard2

execute as @s[level=..7] run tellraw @s [{"translate":"broadcast.dawn.no_xp", "color": "red", "italic": false}]
