
effect clear @s slowness

effect clear @s mining_fatigue

effect clear @s nausea

effect clear @s blindness

effect clear @s weakness

effect clear @s poison

effect clear @s levitation

effect clear @s darkness



effect clear @s wind_charged

effect clear @s weaving

effect clear @s oozing

effect clear @s infested


attribute @s minecraft:movement_speed modifier add surging.movement_speed 0.1 add_multiplied_total
attribute @s minecraft:attack_damage modifier add surging.attack_damage 0.1 add_multiplied_total
attribute @s minecraft:attack_speed modifier add surging.attack_speed 0.1 add_multiplied_total


scoreboard players reset @s dawn.enchantment.stun


effect clear @s minecraft:hunger

effect clear @s minecraft:wither

# effect clear @s minecraft:instant_damage

effect clear @s minecraft:unluck