
# by：Minecraft_hyr

function dawn:damage/poison_check

