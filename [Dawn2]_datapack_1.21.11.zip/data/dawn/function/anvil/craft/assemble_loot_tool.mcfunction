
# 掉落物品
$loot replace block ~ ~ ~ container.16 loot dawn:tool/$(head_material)_$(handle_type)_$(head_type)

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_craft set value true

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
