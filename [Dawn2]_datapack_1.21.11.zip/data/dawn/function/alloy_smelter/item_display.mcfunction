
# -------------------------------------------------------------------------------------------------

stopsound @a[distance=..8] block minecraft:block.barrel.open
stopsound @a[distance=..8] block minecraft:block.barrel.close

# 木桶开启后----------------------------------------------------------------------------------------

# 燃料部分

# 依据燃料设置时长和等级
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.alloy_smelter.fuel_time matches 0..2 if items block ~ ~ ~ container.20 *[item_model="dawn:blaze_coal"] run function dawn:alloy_smelter/fuel {"fuel_time": 3602}

# 修改火焰装饰
execute if score @s dawn.alloy_smelter.fuel_time matches 1 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_0"
execute if score @s dawn.alloy_smelter.fuel_time matches 1..50 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_1"
execute if score @s dawn.alloy_smelter.fuel_time matches 51..100 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_2"
execute if score @s dawn.alloy_smelter.fuel_time matches 101..150 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_3"
execute if score @s dawn.alloy_smelter.fuel_time matches 151..200 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_4"
execute if score @s dawn.alloy_smelter.fuel_time matches 201..250 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_5"
execute if score @s dawn.alloy_smelter.fuel_time matches 251..300 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_6"
execute if score @s dawn.alloy_smelter.fuel_time matches 301..350 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_7"
execute if score @s dawn.alloy_smelter.fuel_time matches 351..400 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_8"
execute if score @s dawn.alloy_smelter.fuel_time matches 401..450 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_9"
execute if score @s dawn.alloy_smelter.fuel_time matches 451..500 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_10"
execute if score @s dawn.alloy_smelter.fuel_time matches 501..550 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_11"
execute if score @s dawn.alloy_smelter.fuel_time matches 551..600 run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_12"
execute if score @s dawn.alloy_smelter.fuel_time matches 601.. run data modify block ~ ~ ~ Items.[{Slot:11b}].components."minecraft:item_model" set value "dawn:smeltery_flame_13"

# 火焰持续消耗
scoreboard players remove @s[scores={dawn.alloy_smelter.fuel_time=1..}] dawn.alloy_smelter.fuel_time 1

# 熔炉发光
data modify entity @s item.components."minecraft:item_model" set value "dawn:alloy_smelter"

execute if score @s dawn.alloy_smelter.fuel_time matches 2.. run function dawn:alloy_smelter/light
execute if score @s dawn.alloy_smelter.fuel_time matches 1 run function dawn:alloy_smelter/light_destory

function dawn:brightness

# -------------------------------------------------------------------------------------------------

# 清除烧制状态
data modify entity @s item.components."minecraft:custom_data".smelting set value false

# 合成配方 （dawn.alloy_smelter.craft_finish） + 燃烧 {"smelting": 1b}
execute if function dawn:alloy_smelter/recipe/adamantium_ingot run function dawn:alloy_smelter/craft_material {"score": 7200, "material": "adamantium"}
execute if function dawn:alloy_smelter/recipe/aurelume_ingot run function dawn:alloy_smelter/craft_material {"score": 3600, "material": "aurelume"}
execute if function dawn:alloy_smelter/recipe/nihilite_ingot run function dawn:alloy_smelter/craft_material {"score": 5400, "material": "nihilite"}
execute if function dawn:alloy_smelter/recipe/blaze_steel_ingot run function dawn:alloy_smelter/craft_material {"score": 1680, "material": "blaze_steel"}
execute if function dawn:alloy_smelter/recipe/frost_steel_ingot run function dawn:alloy_smelter/craft_material {"score": 1680, "material": "frost_steel"}

# 燃料符合等级 且 出口未堵塞 —— 增长进度【-2 +3】
scoreboard players remove @s[scores={dawn.alloy_smelter.craft_time=1..}] dawn.alloy_smelter.craft_time 2
scoreboard players set @s[scores={dawn.alloy_smelter.craft_time=..-1}] dawn.alloy_smelter.craft_time 0
execute if score @s dawn.alloy_smelter.fuel_time matches 1.. if predicate dawn:alloy_smelter/output/can_output if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run scoreboard players add @s dawn.alloy_smelter.craft_time 3

    # 开发者模式
    execute if entity @p[distance=..8, tag=hyj] if score @s dawn.alloy_smelter.fuel_time matches 1.. if predicate dawn:alloy_smelter/output/can_output if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run scoreboard players add @s dawn.alloy_smelter.craft_time 297

# 如果不处于烧制状态，合成进度归0
execute unless data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run scoreboard players set @s dawn.alloy_smelter.craft_time 0

# 展示合成进度
scoreboard players set #calculate dawn.alloy_smelter.craft_calculate 22
scoreboard players operation @s dawn.alloy_smelter.craft_calculate = @s dawn.alloy_smelter.craft_finish
scoreboard players operation @s dawn.alloy_smelter.craft_calculate /= #calculate dawn.alloy_smelter.craft_calculate

scoreboard players operation @s dawn.alloy_smelter.craft_show = @s dawn.alloy_smelter.craft_time
scoreboard players operation @s dawn.alloy_smelter.craft_show /= @s dawn.alloy_smelter.craft_calculate
scoreboard players set @s[scores={dawn.alloy_smelter.craft_show=23..}] dawn.alloy_smelter.craft_show 22
execute store result storage dawn:alloy_smelter craft_show int 1 run scoreboard players get @s dawn.alloy_smelter.craft_show
function dawn:alloy_smelter/craft_show with storage dawn:alloy_smelter

# 烧制完成
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.alloy_smelter.craft_time >= @s dawn.alloy_smelter.craft_finish run function dawn:alloy_smelter/output

# -------------------------------------------------------------------------------------------------

# break
execute unless block ~ ~ ~ minecraft:barrel run function dawn:alloy_smelter/break

# -------------------------------------------------------------------------------------------------
