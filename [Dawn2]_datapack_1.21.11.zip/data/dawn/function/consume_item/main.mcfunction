
# deepslate_heart
scoreboard players remove @s[scores={dawn.effect.deepslate_heart=1..}] dawn.effect.deepslate_heart 1
scoreboard players reset @s[scores={dawn.effect.deepslate_heart=..0}] dawn.effect.deepslate_heart

attribute @s minecraft:armor modifier remove deepslate_heart.armor
attribute @s minecraft:knockback_resistance modifier remove deepslate_heart.knockback_resistance

attribute @s[scores={dawn.effect.deepslate_heart=1..}] minecraft:armor modifier add deepslate_heart.armor 5 add_value
attribute @s[scores={dawn.effect.deepslate_heart=1..}] minecraft:knockback_resistance modifier add deepslate_heart.knockback_resistance 0.8 add_value



