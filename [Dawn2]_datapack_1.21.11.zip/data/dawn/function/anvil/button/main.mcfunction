
# 
tag @s remove dawn.anvil.work

# 通用部分————————————————————

# 修复
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_repair:1b}}}] run function dawn:anvil/button/repair

# 强化品质
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_upgrade:1b}}}] run function dawn:anvil/button/upgrade

# 附魔
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_enchantment:1b}}}] run function dawn:anvil/button/enchantment

# 祛魔
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_disenchant:1b}}}] run function dawn:anvil/button/disenchant

# 经验水晶
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_crystal:1b}}}] run function dawn:anvil/button/crystal_forge

# 光效
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_glow:1b}}}] run function dawn:anvil/button/glow

# 合成部分————————————————————

# 双锭
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_double_ingot:1b}}}] run function dawn:anvil/button/craft_double_ingot

# 工具
execute if data block ~ ~ ~ Items[{Slot:16b, components:{"minecraft:custom_data":{temp_craft:1b}}}] run function dawn:anvil/button/craft_tool

