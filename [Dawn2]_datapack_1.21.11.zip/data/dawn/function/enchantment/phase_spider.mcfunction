
$spreadplayers ~ ~ 2 4 under $(pos_y) false @s

particle portal ~ ~ ~ 0.5 0.5 0.5 0.1 20
