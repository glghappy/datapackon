
# stopsound
stopsound @a * entity.item_frame.place

# Place
execute align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:meteorite"}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.meteorite"], view_range:8}
setblock ~ ~ ~ minecraft:crying_obsidian

# kill
kill @s
