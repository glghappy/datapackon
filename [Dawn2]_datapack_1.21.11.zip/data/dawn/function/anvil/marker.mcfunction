# 返还物品
function dawn:anvil/return_items

# 按钮（work）
execute unless predicate dawn:anvil/forging run tag @n[type=item_display, tag=dawn.anvil] add dawn.anvil.work

# 重置GUI
function dawn:anvil/gui

# 清除
execute unless block ~ ~ ~ minecraft:barrel run kill @s
