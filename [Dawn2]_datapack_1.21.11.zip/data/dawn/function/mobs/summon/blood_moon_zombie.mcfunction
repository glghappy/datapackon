
# Ghoul 食尸鬼 (ban_transform)(silent)
execute if predicate dawn:random/0.15 run return run function dawn:mobs/summon/ghoul

# Revenant 亡魂 (ban_transform)
execute if predicate dawn:random/0.1 run return run function dawn:mobs/summon/revenant

# Earth Elemental C (ban_transform)(equipment)(silent)
execute if predicate dawn:random/0.1 run return run function dawn:mobs/summon/earth_elemental_c

# Red Zombie 红衣僵尸
execute if predicate dawn:random/0.1 run return run function dawn:mobs/summon/red_zombie
