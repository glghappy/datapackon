
schedule function dawn:day/check 1s

scoreboard players operation #blood_moon dawn.day = #blood_moon dawn.gamerule
scoreboard players set #4 dawn.day 4
scoreboard players operation #blue_moon dawn.day = #blood_moon dawn.gamerule
scoreboard players operation #blue_moon dawn.day *= #4 dawn.day

# day-日期  calculate-判断是否血月
execute store result score #day dawn.day \
store result score #calculate1 dawn.day \
store result score #calculate2 dawn.day \
run time query day
scoreboard players operation #calculate1 dawn.day %= #blood_moon dawn.day
scoreboard players operation #calculate2 dawn.day %= #blue_moon dawn.day

# 不是血月

# 是血月
execute unless score #day dawn.day matches 0 \
unless score #calculate2 dawn.day matches 0 \
if score #calculate1 dawn.day matches 0 \

# 是蓝月
execute unless score #day dawn.day matches 0 \
if score #calculate2 dawn.day matches 0 \
