
tag @s add tagged

data modify entity @s acceleration_power set value 0.3

summon wither_skull ~ ~1 ~
data modify entity @n[type=wither_skull] Motion set from entity @s Motion
data modify entity @n[type=wither_skull] UUID set from entity @s UUID
data modify entity @n[type=wither_skull] acceleration_power set value 0.2

summon fireball ~ ~2 ~
data modify entity @n[type=fireball] Motion set from entity @s Motion
data modify entity @n[type=fireball] UUID set from entity @s UUID
data modify entity @n[type=fireball] acceleration_power set value 0.1