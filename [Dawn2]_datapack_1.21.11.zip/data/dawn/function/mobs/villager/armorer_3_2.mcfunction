
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:bell"}, buy:{count:36, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:10}
