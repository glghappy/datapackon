
# —————————————————————————————————————————————————————————————————————————————————————————————————

# attribute
execute as @a run function dawn:player/attribute/main

# —————————————————————————————————————————————————————————————————————————————————————————————————

# neg_level
execute as @a[scores={dawn.player.death=1..}] run function dawn:player/neg_level/remove
execute as @a[scores={dawn.player.neg_level=..-1}, level=1..] run function dawn:player/neg_level/main
execute as @a run function dawn:player/neg_level/attribute

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 脱战
execute as @a run function dawn:player/disengage/main

# —————————————————————————————————————————————————————————————————————————————————————————————————

# use bow
execute as @a[scores={dawn.player.used_bow=1..}] at @s run function dawn:player/bow/main
execute as @a[scores={dawn.player.used_crossbow=1..}] at @s run function dawn:player/bow/crossbow_main

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 营养与糖分
scoreboard players remove @a[scores={dawn.player.protein=1..}] dawn.player.protein 1
scoreboard players set @a[scores={dawn.player.protein=160001..}] dawn.player.protein 160000
scoreboard players remove @a[scores={dawn.player.phytonutrients=1..}] dawn.player.phytonutrients 1
scoreboard players set @a[scores={dawn.player.phytonutrients=160001..}] dawn.player.phytonutrients 160000
scoreboard players remove @a[scores={dawn.player.insulin=1..}] dawn.player.insulin 1

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 饥饿值调整 + 饥饿伤害
execute as @a run function dawn:player/food/main

# —————————————————————————————————————————————————————————————————————————————————————————————————

# Better Title
execute as @a run function dawn:player/gui/main
# # Better Title
# function dawn:player/gui/tick

# —————————————————————————————————————————————————————————————————————————————————————————————————

# stats-trigger
scoreboard players enable @a stats
execute as @a[scores={stats=1..}] run function dawn:player/stats

# —————————————————————————————————————————————————————————————————————————————————————————————————

# time-trigger
scoreboard players enable @a time
execute as @a[scores={time=1..}] at @s run function dawn:player/time

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 离开游戏
execute as @a[scores={dawn.player.leave_game=1..}] run function dawn:player/leave_game

# —————————————————————————————————————————————————————————————————————————————————————————————————

# twisted_flesh