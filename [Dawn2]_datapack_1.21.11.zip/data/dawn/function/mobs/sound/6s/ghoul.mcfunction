schedule function dawn:mobs/sound/6s/ghoul 6s

execute as @e[tag=ghoul] at @s run playsound dawn:mobs.ghoul.say hostile @a ~ ~ ~ 0.25