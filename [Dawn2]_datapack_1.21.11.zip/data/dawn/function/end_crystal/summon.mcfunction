summon end_crystal ~ ~ ~

scoreboard players reset @s dawn.end_crystal