
# -------------------------------------------------------------------------------------------------

stopsound @a[distance=..8] block minecraft:block.barrel.open
stopsound @a[distance=..8] block minecraft:block.barrel.close

# 木桶开启后----------------------------------------------------------------------------------------

# 重置按钮
# execute if predicate dawn:smeltery/input/no_input run scoreboard players set @s dawn.smeltery.button 0
execute unless function dawn:smeltery/recipe/input/have_input run scoreboard players set @s dawn.smeltery.button 0

# -------------------------------------------------------------------------------------------------

# 燃料部分

# 依据燃料设置时长和等级
# execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..1 if predicate dawn:smeltery/fuel/coal run function dawn:smeltery/fuel {"fuel_time": 51, "fuel_level": 1}
# execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..1 if predicate dawn:smeltery/fuel/lava_bucket run function dawn:smeltery/fuel {"fuel_time": 15001, "fuel_level": 2}
# execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..1 if predicate dawn:smeltery/fuel/blaze_rod run function dawn:smeltery/fuel {"fuel_time": 2401, "fuel_level": 3}
# execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..1 if predicate dawn:smeltery/fuel/blaze_coal run function dawn:smeltery/fuel {"fuel_time": 3601, "fuel_level": 4}
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..2 if function dawn:smeltery/fuel/coal run function dawn:smeltery/fuel {"fuel_time": 1202, "fuel_level": 1}
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..2 if function dawn:smeltery/fuel/lava_bucket run function dawn:smeltery/fuel {"fuel_time": 15002, "fuel_level": 2}
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..2 if function dawn:smeltery/fuel/blaze_rod run function dawn:smeltery/fuel {"fuel_time": 2402, "fuel_level": 3}
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.fuel_time matches 0..2 if function dawn:smeltery/fuel/blaze_coal run function dawn:smeltery/fuel {"fuel_time": 3602, "fuel_level": 4}

# 修改火焰装饰
execute if score @s dawn.smeltery.fuel_time matches 1 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_0"
execute if score @s dawn.smeltery.fuel_time matches 1..50 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_1"
execute if score @s dawn.smeltery.fuel_time matches 51..100 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_2"
execute if score @s dawn.smeltery.fuel_time matches 101..150 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_3"
execute if score @s dawn.smeltery.fuel_time matches 151..200 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_4"
execute if score @s dawn.smeltery.fuel_time matches 201..250 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_5"
execute if score @s dawn.smeltery.fuel_time matches 251..300 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_6"
execute if score @s dawn.smeltery.fuel_time matches 301..350 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_7"
execute if score @s dawn.smeltery.fuel_time matches 351..400 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_8"
execute if score @s dawn.smeltery.fuel_time matches 401..450 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_9"
execute if score @s dawn.smeltery.fuel_time matches 451..500 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_10"
execute if score @s dawn.smeltery.fuel_time matches 501..550 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_11"
execute if score @s dawn.smeltery.fuel_time matches 551..600 run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_12"
execute if score @s dawn.smeltery.fuel_time matches 601.. run data modify block ~ ~ ~ Items.[{Slot:10b}].components."minecraft:item_model" set value "dawn:smeltery_flame_13"

# 火焰持续消耗
scoreboard players remove @s[scores={dawn.smeltery.fuel_time=1..}] dawn.smeltery.fuel_time 1
execute unless score @s dawn.smeltery.fuel_time matches 1.. run scoreboard players set @s dawn.smeltery.fuel_level 0

# 熔炉发光
data modify entity @s[tag=dawn.cobblestone] item.components."minecraft:item_model" set value "dawn:cobblestone_smeltery"
data modify entity @s[tag=dawn.obsidian] item.components."minecraft:item_model" set value "dawn:obsidian_smeltery"
data modify entity @s[tag=dawn.netherrack] item.components."minecraft:item_model" set value "dawn:netherrack_smeltery"

execute if score @s dawn.smeltery.fuel_time matches 2.. run function dawn:smeltery/light
execute if score @s dawn.smeltery.fuel_time matches 1 run function dawn:smeltery/light_destory

function dawn:brightness

# -------------------------------------------------------------------------------------------------

# 检测【原料】是否变化 变化则重置冶炼炉

execute store result score @s dawn.smeltery.count run data get block ~ ~ ~ Items.[{Slot:1b}].count

data remove storage dawn:smeltery input_before
data remove entity @s item.components."minecraft:custom_data".input
data modify entity @s item.components."minecraft:custom_data".input set from block ~ ~ ~ Items.[{Slot:1b}]
data modify storage dawn:smeltery input_before set from entity @s item.components."minecraft:custom_data".input_before
function dawn:smeltery/input_check with storage dawn:smeltery
data remove entity @s item.components."minecraft:custom_data".input_before
data modify entity @s item.components."minecraft:custom_data".input_before set from entity @s item.components."minecraft:custom_data".input

# -------------------------------------------------------------------------------------------------

# 展示可烧制部件并记录相应输出数据

# 重置展示模型及相关数据
function dawn:smeltery/show_model_clear

# 展示模型
execute as @s[tag=dawn.cobblestone] if function dawn:smeltery/recipe/input/level_1 run function dawn:smeltery/function
execute as @s[tag=dawn.obsidian] if function dawn:smeltery/recipe/input/level_1_2 run function dawn:smeltery/function
execute as @s[tag=dawn.netherrack] if function dawn:smeltery/recipe/input/level_1_4 run function dawn:smeltery/function

# 燃料匹配
execute as @s[tag=dawn.cobblestone] if function dawn:smeltery/fuel/level_1 if function dawn:smeltery/recipe/input/level_1 run data modify entity @s item.components."minecraft:custom_data".can_work set value true

execute as @s[tag=dawn.obsidian] if function dawn:smeltery/fuel/level_1_2 if function dawn:smeltery/recipe/input/level_1 run data modify entity @s item.components."minecraft:custom_data".can_work set value true
execute as @s[tag=dawn.obsidian] if function dawn:smeltery/fuel/level_2 if function dawn:smeltery/recipe/input/level_2 run data modify entity @s item.components."minecraft:custom_data".can_work set value true

execute as @s[tag=dawn.netherrack] if function dawn:smeltery/fuel/level_1_4 if function dawn:smeltery/recipe/input/level_1 run data modify entity @s item.components."minecraft:custom_data".can_work set value true
execute as @s[tag=dawn.netherrack] if function dawn:smeltery/fuel/level_2_4 if function dawn:smeltery/recipe/input/level_2 run data modify entity @s item.components."minecraft:custom_data".can_work set value true
execute as @s[tag=dawn.netherrack] if function dawn:smeltery/fuel/level_3_4 if function dawn:smeltery/recipe/input/level_3 run data modify entity @s item.components."minecraft:custom_data".can_work set value true
execute as @s[tag=dawn.netherrack] if function dawn:smeltery/fuel/level_4 if function dawn:smeltery/recipe/input/level_4 run data modify entity @s item.components."minecraft:custom_data".can_work set value true

# -------------------------------------------------------------------------------------------------

# 开始合成

# 记录材质和单位材料燃烧时长 (dawn.smeltery.craft_finish)

# 烧制时长拉满
function dawn:smeltery/craft_material_clear

# 烧制配方——材质
execute if function dawn:smeltery/recipe/copper_vanilla run function dawn:smeltery/craft_material {"score": 900, "material_1": "copper", "material_2": "copper"}
execute if function dawn:smeltery/recipe/gold_vanilla run function dawn:smeltery/craft_material {"score": 1200, "material_1": "gold", "material_2": "golden"}

execute if function dawn:smeltery/recipe/copper run function dawn:smeltery/craft_material {"score": 900, "material_1": "copper", "material_2": "copper"}
execute if function dawn:smeltery/recipe/gold run function dawn:smeltery/craft_material {"score": 1200, "material_1": "gold", "material_2": "golden"}
execute if function dawn:smeltery/recipe/iron run function dawn:smeltery/craft_material {"score": 1200, "material_1": "iron", "material_2": "iron"}
execute if function dawn:smeltery/recipe/steel run function dawn:smeltery/craft_material {"score": 1500, "material_1": "steel", "material_2": "steel"}
execute if function dawn:smeltery/recipe/rose_gold run function dawn:smeltery/craft_material {"score": 1500, "material_1": "rose_gold", "material_2": "rose_golden"}
execute if function dawn:smeltery/recipe/ancient_metal run function dawn:smeltery/craft_material {"score": 1800, "material_1": "ancient_metal", "material_2": "ancient_metal"}
execute if function dawn:smeltery/recipe/mithril run function dawn:smeltery/craft_material {"score": 3000, "material_1": "mithril", "material_2": "mithril"}
execute if function dawn:smeltery/recipe/vibranium run function dawn:smeltery/craft_material {"score": 4200, "material_1": "vibranium", "material_2": "vibranium"}
execute if function dawn:smeltery/recipe/aurelume run function dawn:smeltery/craft_material {"score": 3600, "material_1": "aurelume", "material_2": "aurelume"}
execute if function dawn:smeltery/recipe/nihilite run function dawn:smeltery/craft_material {"score": 5400, "material_1": "nihilite", "material_2": "nihilite"}
execute if function dawn:smeltery/recipe/uru run function dawn:smeltery/craft_material {"score": 5400, "material_1": "uru", "material_2": "uru"}
execute if function dawn:smeltery/recipe/adamantium run function dawn:smeltery/craft_material {"score": 7200, "material_1": "adamantium", "material_2": "adamantium"}

execute if function dawn:smeltery/recipe/blaze_steel run function dawn:smeltery/craft_material {"score": 1680, "material_1": "blaze_steel", "material_2": "blaze_steel"}
execute if function dawn:smeltery/recipe/frost_steel run function dawn:smeltery/craft_material {"score": 1680, "material_1": "frost_steel", "material_2": "frost_steel"}

# 烧制配方——开发
# execute if entity @p[distance=..8, tag=hyj] run function dawn:smeltery/vip


scoreboard players set #craft_finish dawn.smeltery.craft_finish 90
scoreboard players operation @s dawn.smeltery.craft_finish *= @s dawn.smeltery.input
scoreboard players operation @s dawn.smeltery.craft_finish /= #craft_finish dawn.smeltery.craft_finish

scoreboard players set #calculate dawn.smeltery.craft_calculate 22
scoreboard players operation @s dawn.smeltery.craft_calculate = @s dawn.smeltery.craft_finish
scoreboard players operation @s dawn.smeltery.craft_calculate /= #calculate dawn.smeltery.craft_calculate

scoreboard players operation @s dawn.smeltery.craft_show = @s dawn.smeltery.craft_time
scoreboard players operation @s dawn.smeltery.craft_show /= @s dawn.smeltery.craft_calculate
scoreboard players set @s[scores={dawn.smeltery.craft_show=23..}] dawn.smeltery.craft_show 22
execute store result storage dawn:smeltery craft_show int 1 run scoreboard players get @s dawn.smeltery.craft_show
function dawn:smeltery/craft_show with storage dawn:smeltery

# 燃料符合等级 且 出口未堵塞 —— 增长进度【-2 +3】
scoreboard players remove @s[scores={dawn.smeltery.craft_time=1..}] dawn.smeltery.craft_time 2
scoreboard players set @s[scores={dawn.smeltery.craft_time=..-1}] dawn.smeltery.craft_time 0
# execute if score @s dawn.smeltery.fuel_time matches 1.. if predicate dawn:smeltery/output/can_output if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run function dawn:smeltery/craft_add
execute if score @s dawn.smeltery.fuel_time matches 1.. if predicate dawn:smeltery/output/can_output if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run scoreboard players add @s dawn.smeltery.craft_time 3

    # 开发者模式
    execute if entity @p[distance=..8, tag=hyj] if score @s dawn.smeltery.fuel_time matches 1.. if predicate dawn:smeltery/output/can_output if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} run scoreboard players add @s dawn.smeltery.craft_time 300

# 烧制完成
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} if score @s dawn.smeltery.craft_time >= @s dawn.smeltery.craft_finish run function dawn:smeltery/output

# 如果无燃料且合成进度归0，则清除烧炼状态
execute if data entity @s {item:{components:{"minecraft:custom_data":{"smelting": 1b}}}} unless score @s dawn.smeltery.fuel_time matches 1.. if score @s dawn.smeltery.craft_time matches 1 run function dawn:smeltery/craft_stop

# button/触发效果
execute as @s[tag=dawn.smeltery.work] run function dawn:smeltery/button

# -------------------------------------------------------------------------------------------------

# break
execute unless block ~ ~ ~ minecraft:barrel run function dawn:smeltery/break

# -------------------------------------------------------------------------------------------------