
#
tag @s add summon


# attribute
attribute @s minecraft:attack_damage base set 10


#
execute if items entity @s weapon.mainhand golden_axe[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:weapon/piglin_brute
