
# remove attribute
execute as @e[scores={dawn.enchantment.frost_shockwave=0..}] run function dawn:enchantment/frost_shockwave_function2

# add attribute
execute as @e[scores={dawn.enchantment.frost_shockwave=1..}] run function dawn:enchantment/frost_shockwave_function

# scoreboard
scoreboard players remove @e[scores={dawn.enchantment.frost_shockwave.cd=1..}] dawn.enchantment.frost_shockwave.cd 1
scoreboard players remove @e[scores={dawn.enchantment.frost_shockwave=1..}] dawn.enchantment.frost_shockwave 1
