
# -------------------------------------------------------------------------------------------------

# 检测原料体积 [dawn.smeltery.input]

execute if predicate dawn:smeltery/input/10 run scoreboard players set @s dawn.smeltery.input 10
execute if predicate dawn:smeltery/input/90 run scoreboard players set @s dawn.smeltery.input 90
execute if predicate dawn:smeltery/input/180 run scoreboard players set @s dawn.smeltery.input 180
execute if predicate dawn:smeltery/input/270 run scoreboard players set @s dawn.smeltery.input 270
execute if predicate dawn:smeltery/input/360 run scoreboard players set @s dawn.smeltery.input 360
execute if predicate dawn:smeltery/input/450 run scoreboard players set @s dawn.smeltery.input 450
execute if predicate dawn:smeltery/input/630 run scoreboard players set @s dawn.smeltery.input 630
execute if predicate dawn:smeltery/input/720 run scoreboard players set @s dawn.smeltery.input 720
execute if predicate dawn:smeltery/input/810 run scoreboard players set @s dawn.smeltery.input 810

scoreboard players operation @s dawn.smeltery.input *= @s dawn.smeltery.count

# -------------------------------------------------------------------------------------------------

# 展示可烧制部件并记录相应输出数据

# 计算展示的物品 [dawn.smeltery.show]
scoreboard players set @s dawn.smeltery.show 0
execute if score @s dawn.smeltery.input matches 10 run scoreboard players set @s dawn.smeltery.show 2
execute if score @s dawn.smeltery.input matches 90 run scoreboard players set @s dawn.smeltery.show 10
execute if score @s dawn.smeltery.input matches 180 run scoreboard players set @s dawn.smeltery.show 20
execute if score @s dawn.smeltery.input matches 270 run scoreboard players set @s dawn.smeltery.show 30
execute if score @s dawn.smeltery.input matches 360 run scoreboard players set @s dawn.smeltery.show 40
execute if score @s dawn.smeltery.input matches 450 run scoreboard players set @s dawn.smeltery.show 50
execute if score @s dawn.smeltery.input matches 540 run scoreboard players set @s dawn.smeltery.show 60
execute if score @s dawn.smeltery.input matches 630 run scoreboard players set @s dawn.smeltery.show 70
execute if score @s dawn.smeltery.input matches 720 run scoreboard players set @s dawn.smeltery.show 80
execute if score @s dawn.smeltery.input matches 810 run scoreboard players set @s dawn.smeltery.show 90
scoreboard players operation @s dawn.smeltery.show += @s dawn.smeltery.button

# 依据分数展示模型
# (0~1) empty模型
scoreboard players set @s[scores={dawn.smeltery.show=..9}] dawn.smeltery.button 0
execute if score @s dawn.smeltery.show matches 2..3 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=16..19}] dawn.smeltery.button 5
execute if score @s dawn.smeltery.show matches 10 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":1}
execute if score @s dawn.smeltery.show matches 11 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":9}
execute if score @s dawn.smeltery.show matches 12 run function dawn:smeltery/show_model {"folder": "component", "model": "hatchet", "name": "手斧", "count":1}
execute if score @s dawn.smeltery.show matches 13 run function dawn:smeltery/show_model {"folder": "component", "model": "knife", "name": "小刀", "count":1}
execute if score @s dawn.smeltery.show matches 14 run function dawn:smeltery/show_model {"folder": "component", "model": "shovel", "name": "锹", "count":1}
execute if score @s dawn.smeltery.show matches 15..16 run function dawn:smeltery/show_model {"folder": "component", "model": "stick", "name": "棒", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=27..29}] dawn.smeltery.button 6
execute if score @s dawn.smeltery.show matches 20 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":2}
execute if score @s dawn.smeltery.show matches 21 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":18}
execute if score @s dawn.smeltery.show matches 22 run function dawn:smeltery/show_model {"folder": "component", "model": "halberd", "name": "戟", "count":1}
execute if score @s dawn.smeltery.show matches 23 run function dawn:smeltery/show_model {"folder": "component", "model": "hoe", "name": "锄", "count":1}
execute if score @s dawn.smeltery.show matches 24 run function dawn:smeltery/show_model {"folder": "component", "model": "longsword", "name": "长剑", "count":1}
execute if score @s dawn.smeltery.show matches 25 run function dawn:smeltery/show_model {"folder": "component", "model": "scythe", "name": "镰刀", "count":1}
execute if score @s dawn.smeltery.show matches 26..27 run function dawn:smeltery/show_model {"folder": "component", "model": "sword", "name": "剑", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=35..39}] dawn.smeltery.button 4
execute if score @s dawn.smeltery.show matches 30 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":3}
execute if score @s dawn.smeltery.show matches 31 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":27}
execute if score @s dawn.smeltery.show matches 32 run function dawn:smeltery/show_model {"folder": "component", "model": "axe", "name": "斧", "count":1}
execute if score @s dawn.smeltery.show matches 33 run function dawn:smeltery/show_model {"folder": "bow_limb", "model": "bow_limb", "name": "弓臂", "count":1}
execute if score @s dawn.smeltery.show matches 34..35 run function dawn:smeltery/show_model {"folder": "component", "model": "pickaxe", "name": "镐", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=45..49}] dawn.smeltery.button 4
execute if score @s dawn.smeltery.show matches 40 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":4}
execute if score @s dawn.smeltery.show matches 41 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":36}
execute if score @s dawn.smeltery.show matches 42 run function dawn:smeltery/show_model {"folder": "component", "model": "battle_axe", "name": "战斧", "count":1}
execute if score @s dawn.smeltery.show matches 43 run function dawn:smeltery/show_model {"folder": "plating", "model": "boots", "name": "靴子", "count":1}
execute if score @s dawn.smeltery.show matches 44..45 run function dawn:smeltery/show_model {"folder": "component", "model": "mattock", "name": "鹤嘴锄", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=54..59}] dawn.smeltery.button 3
execute if score @s dawn.smeltery.show matches 50 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":5}
execute if score @s dawn.smeltery.show matches 51 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":45}
execute if score @s dawn.smeltery.show matches 52 run function dawn:smeltery/show_model {"folder": "plating", "model": "helmet", "name": "头盔", "count":1}
execute if score @s dawn.smeltery.show matches 53..54 run function dawn:smeltery/show_model {"folder": "component", "model": "war_hammer", "name": "战锤", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=62..69}] dawn.smeltery.button 1
execute if score @s dawn.smeltery.show matches 60 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":6}
execute if score @s dawn.smeltery.show matches 61..62 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":54}

scoreboard players set @s[scores={dawn.smeltery.show=73..79}] dawn.smeltery.button 2
execute if score @s dawn.smeltery.show matches 70 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":7}
execute if score @s dawn.smeltery.show matches 71 run function dawn:smeltery/show_model {"folder": "nugget", "model": "nugget", "name": "粒", "count":63}
execute if score @s dawn.smeltery.show matches 72..73 run function dawn:smeltery/show_model {"folder": "plating", "model": "leggings", "name": "护腿", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=82..89}] dawn.smeltery.button 1
execute if score @s dawn.smeltery.show matches 80 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":8}
execute if score @s dawn.smeltery.show matches 81..82 run function dawn:smeltery/show_model {"folder": "plating", "model": "chestplate", "name": "胸甲", "count":1}

scoreboard players set @s[scores={dawn.smeltery.show=92..}] dawn.smeltery.button 1
execute if score @s dawn.smeltery.show matches 90 run function dawn:smeltery/show_model {"folder": "ingot", "model": "ingot", "name": "锭", "count":9}
execute if score @s dawn.smeltery.show matches 91..92 run function dawn:smeltery/show_model {"folder": "block", "model": "block", "name": "块", "count":1}

# -------------------------------------------------------------------------------------------------

