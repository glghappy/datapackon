
attribute @s[level=..4] minecraft:max_health base set 6

attribute @s[level=5..9] minecraft:max_health base set 8

attribute @s[level=10..14] minecraft:max_health base set 10

attribute @s[level=15..19] minecraft:max_health base set 12

attribute @s[level=20..24] minecraft:max_health base set 14

attribute @s[level=25..29] minecraft:max_health base set 16

attribute @s[level=30..34] minecraft:max_health base set 18

attribute @s[level=35..39] minecraft:max_health base set 20

attribute @s[level=40..44] minecraft:max_health base set 22

attribute @s[level=45..49] minecraft:max_health base set 24

attribute @s[level=50..54] minecraft:max_health base set 26

attribute @s[level=55..59] minecraft:max_health base set 28

attribute @s[level=60..64] minecraft:max_health base set 30

attribute @s[level=65..69] minecraft:max_health base set 32

attribute @s[level=70..74] minecraft:max_health base set 34

attribute @s[level=75..79] minecraft:max_health base set 36

attribute @s[level=80..84] minecraft:max_health base set 38

attribute @s[level=85..] minecraft:max_health base set 40