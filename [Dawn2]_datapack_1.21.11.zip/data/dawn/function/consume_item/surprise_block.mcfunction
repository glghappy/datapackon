advancement revoke @s only dawn:consume_item/surprise_block

loot spawn ~ ~ ~ loot dawn:surprise_block_loot
