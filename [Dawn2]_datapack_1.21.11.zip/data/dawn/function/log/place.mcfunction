$setblock ~ ~ ~ $(id)[axis=$(axis)]
tellraw @p {text:"请使用正确的工具挖掘", color:"red"}
kill @s