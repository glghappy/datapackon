
# by：Minecraft_hyr

attribute @s minecraft:movement_speed modifier add stun.movement_speed -1 add_multiplied_total
attribute @s minecraft:jump_strength modifier add stun.jump_strength -1 add_multiplied_total
attribute @s minecraft:attack_damage modifier add stun.attack_damage -1 add_multiplied_total
attribute @s minecraft:attack_speed modifier add stun.attack_speed -1 add_multiplied_total
execute at @s run particle dust{color:[0.435, 0.373, 0.161], scale:1} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal
