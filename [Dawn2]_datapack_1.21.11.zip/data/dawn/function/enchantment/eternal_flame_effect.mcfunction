effect clear @s minecraft:poison
effect clear @s minecraft:wither