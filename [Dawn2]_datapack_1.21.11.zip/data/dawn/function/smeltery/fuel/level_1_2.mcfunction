
execute if items block ~ ~ ~ container.19 minecraft:coal run return 1
execute if items block ~ ~ ~ container.19 minecraft:lava_bucket run return 1

execute if score @s dawn.smeltery.fuel_level matches 1..2 run return 1
