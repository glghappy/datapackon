# say hi

# 复制工具
item replace block ~ ~ ~ container.16 from block ~ ~ ~ container.10

# 减少强化槽（2个）
scoreboard objectives add dawn.anvil.item.enhancement dummy
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".enhancement_slot
execute store result storage dawn:input enhancement int 1 run scoreboard players remove @s dawn.anvil.item.enhancement 2
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".enhancement_slot set from storage dawn:input enhancement

# 修改强化槽
function dawn:anvil/function/modify_enhancement_slot with storage dawn:input

# 减少基础强化槽（2个）
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".quality.base_enhancement_slot
scoreboard players remove @s dawn.anvil.item.enhancement 2
execute store result storage dawn:input base_enhancement int 1 run scoreboard players get @s dawn.anvil.item.enhancement
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".quality.base_enhancement_slot set from storage dawn:input base_enhancement

# 附魔叠加
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:enchantments" merge from block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".initial_enchantments

# 记录叠加附魔
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".engrave_enchantments merge from block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".initial_enchantments
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".have_engrave set value true

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_craft set value true

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
