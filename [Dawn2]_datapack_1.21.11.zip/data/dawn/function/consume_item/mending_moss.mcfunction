advancement revoke @s only dawn:consume_item/mending_moss

xp add @s 500 points
effect give @s minecraft:glowing 10 0 false
