
attribute @s minecraft:mining_efficiency modifier remove enchantment.momentum

$attribute @s minecraft:mining_efficiency modifier add enchantment.momentum $(enchantment_momentum) add_value
