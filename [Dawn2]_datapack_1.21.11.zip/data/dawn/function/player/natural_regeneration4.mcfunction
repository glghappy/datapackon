effect give @s minecraft:regeneration 1 2 true
effect give @s hunger 1 19 true
