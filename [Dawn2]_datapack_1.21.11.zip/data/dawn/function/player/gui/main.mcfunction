
# food bar
execute store result storage dawn:player food_int int 1 run scoreboard players get @s dawn.player.foodBar
execute as @s[gamemode=!creative, gamemode=!spectator, predicate=!dawn:player/vehicle] run function dawn:player/gui/food_bar with storage dawn:player

execute store result storage dawn:player food_int int 1 run scoreboard players get @s dawn.player.foodLevel_show
execute as @s[gamemode=!creative, gamemode=!spectator, predicate=!dawn:player/vehicle] run function dawn:player/gui/food_bar with storage dawn:player

execute store result storage dawn:player food_int int 1 run scoreboard players get @s dawn.player.foodSaturationLevel_show
execute as @s[gamemode=!creative, gamemode=!spectator, predicate=!dawn:player/vehicle] run function dawn:player/gui/food_bar2 with storage dawn:player

# -------------------------------------------------------------------------------------------------

# effect
execute if predicate dawn:player/malnutrition run function dawn:player/gui/malnutrition_1
execute if predicate dawn:player/insulin_resistance unless predicate dawn:player/malnutrition run function dawn:player/gui/malnutrition_2
execute if predicate dawn:player/insulin_resistance if predicate dawn:player/malnutrition run function dawn:player/gui/malnutrition_3

# -------------------------------------------------------------------------------------------------

# neg_level
execute store result storage dawn:player neg_level int 1 run scoreboard players get @s dawn.player.neg_level
execute as @s[scores={dawn.player.neg_level=..-1}, gamemode=!creative, gamemode=!spectator] run function dawn:player/gui/neg_level with storage dawn:player

# -------------------------------------------------------------------------------------------------

# 把 "当前组装好的面板" 写进指针指向的槽位，完成一次内容提交。
data modify storage title:io panels[1] set from storage title:io panel_buffer
data modify storage title:io panel_buffer set value []

# 每 tick 把目标面板拷贝过来，再塞进 actionbar
data modify storage title:io temp_panel set from storage title:io panels[1]
title @s actionbar {"nbt":"temp_panel","storage":"title:io","interpret": true}

# 清空创造面板
title @s[gamemode=!survival, gamemode=!adventure] actionbar ""
