
# 获取单位修复值 （dawn.anvil.item.operation）
scoreboard objectives add dawn.anvil.item.operation dummy
execute store result score @s dawn.anvil.item.operation run data get block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".repair.durability

# # 仅需一份材料
# execute if score @s dawn.anvil.item.damage <= @s dawn.anvil.item.operation run function dawn:anvil/function/repair3

# # 需要多份材料
# execute if score @s dawn.anvil.item.damage > @s dawn.anvil.item.operation run function dawn:anvil/function/repair4

# function dawn:anvil/function/repair4

# 获取理论所需材料份数 (dawn.anvil.item.operation2) (+1)
scoreboard objectives add dawn.anvil.item.operation2 dummy
scoreboard players operation @s dawn.anvil.item.operation2 = @s dawn.anvil.item.damage
scoreboard players operation @s dawn.anvil.item.operation2 /= @s dawn.anvil.item.operation
scoreboard players add @s dawn.anvil.item.operation2 1

# tellraw @a ["所需材料份数"]
# tellraw @a [{"score": {"name": "@e[type=item_display, tag=dawn.anvil, limit=1]","objective": "dawn.anvil.item.operation2"}}]

# 获取原料份数 (dawn.anvil.item.count)
scoreboard objectives add dawn.anvil.item.count dummy
execute store result score @s dawn.anvil.item.count run data get block ~ ~ ~ Items[{Slot:13b}].count

# tellraw @a ["原料份数"]
# tellraw @a [{"score": {"name": "@e[type=item_display, tag=dawn.anvil, limit=1]","objective": "dawn.anvil.item.count"}}]

# 取两者的较小值，储存耗材数值 (dawn.anvil.item.operation2) (dawn:material cost)
scoreboard players operation @s dawn.anvil.item.count < @s dawn.anvil.item.operation2
execute store result storage dawn:material cost int 1 run scoreboard players operation @s dawn.anvil.item.operation2 = @s dawn.anvil.item.count

# tellraw @a ["两者的较小值"]
# tellraw @a [{"score": {"name": "@e[type=item_display, tag=dawn.anvil, limit=1]","objective": "dawn.anvil.item.operation2"}}]

# 获取修复数值（修复份数 * 单份耐久） (dawn.anvil.item.operation2)
scoreboard players operation @s dawn.anvil.item.operation2 *= @s dawn.anvil.item.operation

# tellraw @a ["修复数值"]
# tellraw @a [{"score": {"name": "@e[type=item_display, tag=dawn.anvil, limit=1]","objective": "dawn.anvil.item.operation2"}}]

# 获取修复后耐久值，不超过0 (dawn.anvil.item.damage)
scoreboard players operation @s dawn.anvil.item.damage -= @s dawn.anvil.item.operation2
execute if score @s dawn.anvil.item.damage matches ..0 run scoreboard players set @s dawn.anvil.item.damage 0
execute store result storage dawn:damage damage int 1 run scoreboard players get @s dawn.anvil.item.damage

# 显示成品

# 复制物品
item replace block ~ ~ ~ container.16 from block ~ ~ ~ container.10

# 修复
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:damage" set from storage dawn:damage damage

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_repair set value true

# 记录耗材
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_cost set from storage dawn:material cost

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
