tag @s add crazy_wither

attribute @s armor base set 8
attribute @s flying_speed base set 1.2


data modify entity @s CustomName set value "Crazy Wither"
data modify entity @s DeathLootTable set value "dawn:entities/crazy_wither"


# loot replace entity @s weapon.mainhand loot dawn:armor/boss/crazy_wither_weapon

