
#无水晶-有龙-加分
execute if entity @e[type=ender_dragon] unless entity @e[type=end_crystal, distance=..0.5] run scoreboard players add @s dawn.end_crystal 1

#有龙-无水晶-分数达标-召唤水晶
execute as @s[scores={dawn.end_crystal=9600..}] if entity @e[type=ender_dragon] unless entity @e[type=end_crystal,distance=..0.5] run function dawn:end_crystal/summon

#无龙-kill
execute unless entity @e[type=ender_dragon] run kill @s
execute unless entity @e[type=ender_dragon] run kill @n[type=slime, distance=..0.5, tag=end_crystal]
