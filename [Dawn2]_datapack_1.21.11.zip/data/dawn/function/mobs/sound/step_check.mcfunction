scoreboard players set @s dawn.motion 0
execute if block ~ ~-1 ~ gravel run playsound dawn:mobs.step.gravel ambient @a ~ ~ ~ 0.3
execute if block ~ ~-1 ~ sand run playsound dawn:mobs.step.sand ambient @a ~ ~ ~ 0.3
execute if block ~ ~-1 ~ #mineable/axe run playsound dawn:mobs.step.wood ambient @a ~ ~ ~ 0.3
execute unless block ~ ~-1 ~ gravel unless block ~ ~-1 ~ sand unless block ~ ~-1 ~ #mineable/axe unless block ~ ~ ~ water run playsound dawn:mobs.step.step ambient @a ~ ~ ~ 0.3