
# 在【误放物品】时触发

# GUI
item replace block ~ ~ ~ container.0 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:alloy_smelter_gui"]

item replace block ~ ~ ~ container.4 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.5 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.6 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.7 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.8 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.9 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.10 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
# item replace block ~ ~ ~ container.11 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.12 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.13 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
# item replace block ~ ~ ~ container.14 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.15 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
# item replace block ~ ~ ~ container.16 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.17 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.18 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.19 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
# item replace block ~ ~ ~ container.20 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.21 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.22 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.23 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.24 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.25 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.26 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]
item replace block ~ ~ ~ container.27 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:empty"]

item replace block ~ ~ ~ container.11 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:smeltery_flame_0"]
item replace block ~ ~ ~ container.14 with firework_star[!minecraft:item_name, tooltip_display={hide_tooltip:true}, minecraft:custom_data={"dawn_clear":true}, minecraft:item_model="dawn:alloy_smelter_craft_0"]
