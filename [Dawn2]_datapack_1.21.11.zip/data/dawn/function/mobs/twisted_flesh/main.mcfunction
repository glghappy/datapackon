execute if entity @n[tag=corrupt_bleeding_weeper] run scoreboard players reset @s dawn.entity.twisted_flesh


execute if score @s dawn.entity.twisted_flesh matches 0..159 run particle dust{color:[0.796, 0.114, 0.114], scale:1} ~ ~ ~ 0.25 0.25 0.25 0.12 1 normal
execute if score @s dawn.entity.twisted_flesh matches 160.. run particle dust{color:[0.451, 0.051, 0.051], scale:1.2} ~ ~ ~ 0.25 0.25 0.25 0.15 1 normal


scoreboard objectives add dawn.entity.twisted_flesh dummy
scoreboard players add @s dawn.entity.twisted_flesh 1


execute if score @s dawn.entity.twisted_flesh matches 200.. run function dawn:mobs/twisted_flesh/summon
