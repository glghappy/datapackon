
# place item_display and barrel
execute as @e[tag=dawn.meteorite, type=glow_item_frame] at @s run function dawn:meteorite/place

# item_display (break)
execute as @e[tag=dawn.meteorite, type=item_display] at @s unless block ~ ~ ~ minecraft:crying_obsidian run function dawn:meteorite/break
