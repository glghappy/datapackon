
# 移除成品清除标记
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear


# 扣除材料
# item modify block ~ ~ ~ container.10 dawn:remove_1
# item modify block ~ ~ ~ container.13 dawn:remove_1
item replace block ~ ~ ~ container.10 with minecraft:air
item replace block ~ ~ ~ container.13 with minecraft:air


# 移除成品附加标记
data remove block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_craft

# 播放声音
playsound minecraft:block.anvil.use block @a ~ ~ ~