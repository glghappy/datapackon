
# 双锭合成配方

execute if predicate dawn:anvil/recipe/gold_double_ingot run function dawn:anvil/craft/hammer_double_ingot {"material": "gold", "damage": 8}

execute if predicate dawn:anvil/recipe/copper_double_ingot run function dawn:anvil/craft/hammer_double_ingot {"material": "copper", "damage": 12}

execute if predicate dawn:anvil/recipe/iron_double_ingot run function dawn:anvil/craft/hammer_double_ingot {"material": "iron", "damage": 24}

execute if predicate dawn:anvil/recipe/ancient_metal_double_ingot run function dawn:anvil/craft/hammer_double_ingot {"material": "ancient_metal", "damage": 48}

execute if predicate dawn:anvil/recipe/mithril_double_ingot run function dawn:anvil/craft/hammer_double_ingot {"material": "mithril", "damage": 160}

execute if predicate dawn:anvil/recipe/vibranium_double_ingot run function dawn:anvil/craft/hammer_double_ingot {"material": "vibranium", "damage": 320}

execute if predicate dawn:anvil/recipe/adamantium_double_ingot run function dawn:anvil/craft/hammer_double_ingot {"material": "adamantium", "damage": 640}



# 砧合成配方(借用“双锭”button)

execute if predicate dawn:anvil/recipe/golden_anvil run function dawn:anvil/craft/hammer_anvil {"material": "golden", "damage": 24}

execute if predicate dawn:anvil/recipe/copper_anvil run function dawn:anvil/craft/hammer_anvil {"material": "copper", "damage": 36}

execute if predicate dawn:anvil/recipe/iron_anvil run function dawn:anvil/craft/hammer_anvil {"material": "iron", "damage": 72}

execute if predicate dawn:anvil/recipe/ancient_metal_anvil run function dawn:anvil/craft/hammer_anvil {"material": "ancient_metal", "damage": 144}

execute if predicate dawn:anvil/recipe/mithril_anvil run function dawn:anvil/craft/hammer_anvil {"material": "mithril", "damage": 480}

execute if predicate dawn:anvil/recipe/vibranium_anvil run function dawn:anvil/craft/hammer_anvil {"material": "vibranium", "damage": 1280}

execute if predicate dawn:anvil/recipe/adamantium_anvil run function dawn:anvil/craft/hammer_anvil {"material": "adamantium", "damage": 1920}

