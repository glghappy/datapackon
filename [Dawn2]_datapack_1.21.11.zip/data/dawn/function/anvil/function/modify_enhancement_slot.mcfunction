
$data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:lore"[2] set value {"translate": "lore.dawn.enhancement_slot", "color": "gray", "italic": false, "with": [{"text": "$(enhancement)", "color": "white"}]}
