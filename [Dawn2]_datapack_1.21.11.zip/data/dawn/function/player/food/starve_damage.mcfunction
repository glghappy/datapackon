
damage @s 1 starve

scoreboard players reset @s dawn.player.starve
