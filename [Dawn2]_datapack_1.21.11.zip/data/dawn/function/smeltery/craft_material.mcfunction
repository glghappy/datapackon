
$scoreboard players set @s dawn.smeltery.craft_finish $(score)

$data modify entity @s item.components."minecraft:custom_data".output_material_1 set value "$(material_1)"
$data modify entity @s item.components."minecraft:custom_data".output_material_2 set value "$(material_2)"
