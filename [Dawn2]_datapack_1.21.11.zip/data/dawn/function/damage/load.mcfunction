
# poison
scoreboard objectives add dawn.effect.poison dummy

# bleeding
scoreboard objectives add dawn.entity.health dummy
scoreboard objectives add dawn.effect.bleeding dummy
scoreboard objectives add dawn.effect.bleeding_cd dummy