
scoreboard objectives add dawn.player.disengage dummy
