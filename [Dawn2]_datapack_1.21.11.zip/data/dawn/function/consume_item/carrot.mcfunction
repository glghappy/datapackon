advancement revoke @s only dawn:consume_item/carrot

scoreboard players add @s dawn.player.phytonutrients 7499
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
