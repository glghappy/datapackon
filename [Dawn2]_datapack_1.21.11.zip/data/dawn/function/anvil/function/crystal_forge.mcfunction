
# 获取成功
scoreboard objectives add dawn.anvil.item.can_forge dummy
execute store result score @s dawn.anvil.item.can_forge run data get block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".experience_crystal.can_forge
# execute if score @s dawn.anvil.item.can_forge matches 1 run say yes
execute if score @s dawn.anvil.item.can_forge matches 1 run function dawn:anvil/function/crystal_forge2

