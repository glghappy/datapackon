advancement revoke @s only dawn:consume_item/salad

scoreboard players add @s dawn.player.phytonutrients 2000
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
