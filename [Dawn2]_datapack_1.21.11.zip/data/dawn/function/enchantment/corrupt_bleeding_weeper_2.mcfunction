

execute as @e[distance=..24, type=!silverfish] run effect give @s infested 30 0 false

execute as @e[distance=..24, type=!silverfish] run effect give @s blindness 3 0 false

execute as @e[distance=..24, type=!silverfish] run effect give @s slowness 3 2 false

execute as @e[distance=..6, type=!silverfish, tag=!corrupt_bleeding_weeper, type=!item_frame, type=!glow_item_frame, type=!item] run damage @s 3 explosion by @n[tag=corrupt_bleeding_weeper]