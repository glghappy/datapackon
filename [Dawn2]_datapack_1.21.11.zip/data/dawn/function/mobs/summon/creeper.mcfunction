
#
tag @s add summon

# Frozen Creeper 冰冻苦力怕
execute if biome ~ ~ ~ #minecraft:spawns_cold_variant_farm_animals run return run function dawn:mobs/summon/frozen_creeper

# Sand Creeper 沙漠苦力怕
execute if biome ~ ~ ~ #minecraft:spawns_gold_rabbits run return run function dawn:mobs/summon/sand_creeper

# Stone Creeper 石化苦力怕
execute if predicate dawn:random/0.6 if dimension dawn:underworld run return run function dawn:mobs/summon/stone_creeper
execute if predicate dawn:random/0.4 if dimension minecraft:overworld if predicate dawn:location/cave run return run function dawn:mobs/summon/stone_creeper

# Shadow Creeper 暗影苦力怕
execute if predicate dawn:random/0.2 if dimension dawn:underworld run return run function dawn:mobs/summon/shadow_creeper
execute if predicate dawn:random/0.2 if dimension minecraft:overworld if predicate dawn:location/cave run return run function dawn:mobs/summon/shadow_creeper

# Infernal Creeper 地狱苦力怕
execute if predicate dawn:random/0.1 if dimension dawn:underworld run return run function dawn:mobs/summon/infernal_creeper
execute if predicate dawn:random/0.1 if dimension minecraft:overworld if predicate dawn:location/deepslate_cave run return run function dawn:mobs/summon/infernal_creeper


# 是血月
execute unless score #day dawn.day matches 0 \
unless score #calculate2 dawn.day matches 0 \
if score #calculate1 dawn.day matches 0 \
run function dawn:mobs/summon/blood_moon_creeper