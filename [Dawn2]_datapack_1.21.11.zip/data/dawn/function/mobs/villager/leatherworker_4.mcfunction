
tag @s add sell_4

# 7
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:4, id:"minecraft:turtle_scute"}, priceMultiplier: 0.05f, xp:30}

# 8
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:stone"}, buy:{count:3, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:15}
loot replace entity @s armor.head loot dawn:armor/leather_boots
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head

item replace entity @s armor.head with air
