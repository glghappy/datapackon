advancement revoke @s only dawn:consume_item/rabbit_stew

scoreboard players add @s dawn.player.protein 73944
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000

scoreboard players add @s dawn.player.phytonutrients 8216
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
