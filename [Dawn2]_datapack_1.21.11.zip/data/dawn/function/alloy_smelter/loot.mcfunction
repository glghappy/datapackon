
$loot replace block ~ ~ ~ container.16 loot dawn:ingot/$(material)_ingot
