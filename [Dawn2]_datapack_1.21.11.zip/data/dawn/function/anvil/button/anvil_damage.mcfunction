
# 铁砧耐久
scoreboard objectives add dawn.anvil.durability dummy
execute store result score @s dawn.anvil.durability run data get entity @s item.components."minecraft:custom_data".anvil.durability

# 扣除耐久
execute store result storage dawn:anvil.durability anvil.durability int 1 run scoreboard players operation @s dawn.anvil.durability -= @s dawn.anvil.item.operation

# 修改铁砧
data modify entity @s item.components."minecraft:custom_data".anvil.durability set from storage dawn:anvil.durability anvil.durability

data remove storage dawn:anvil.durability anvil.durability
