# place item_display and barrel
execute as @e[tag=dawn.smeltery, type=glow_item_frame] at @s run function dawn:smeltery/place

# marker
execute as @e[tag=dawn.smeltery, type=marker] at @s unless predicate dawn:smeltery/gui run function dawn:smeltery/marker

# item_display (break)
execute as @e[tag=dawn.smeltery, type=item_display] at @s run function dawn:smeltery/item_display
