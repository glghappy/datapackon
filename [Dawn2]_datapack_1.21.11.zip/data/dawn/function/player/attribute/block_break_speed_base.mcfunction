
attribute @s minecraft:block_break_speed base set 0.0625
