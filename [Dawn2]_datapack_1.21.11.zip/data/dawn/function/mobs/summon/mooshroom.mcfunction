
tag @s add summon

# Mushroom Zombie 真菌僵尸 (ban_transform)(PersistenceRequired)
summon minecraft:zombie ~ ~ ~ {CustomName: "Mushroom Zombie", Tags: ["summon", "ban_transform", "equipment_summon", "mushroom_zombie"], Health: 14.0f, equipment: {mainhand: {components: {"minecraft:max_stack_size": 1, "minecraft:enchantments": {"minecraft:attack_weakness": 1, "minecraft:attack_poison": 1, "minecraft:attack_slowness_short": 1, "minecraft:attack_hunger": 1}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_model": {}, "!minecraft:item_name": {}}, count: 1, id: "minecraft:firework_star"}, head: {components: {"!minecraft:attribute_modifiers": {}, "minecraft:equippable": {equip_sound: "minecraft:intentionally_empty", slot: "head", asset_id: "dawn:air"}, "!minecraft:enchantable": {}, "!minecraft:repairable": {}, "minecraft:enchantments": {"minecraft:binding_curse": 1}, "!minecraft:max_damage": {}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_model": {}, "!minecraft:item_name": {}, "!minecraft:damage": {}}, count: 1, id: "minecraft:leather_helmet"}}, drop_chances: {head: 0.0f, mainhand: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, attributes: [{id: "minecraft:max_health", base: 14.0d}, {id: "minecraft:follow_range", base: 12.0d}, {id: "minecraft:movement_speed", base: 0.35d}, {id: "minecraft:armor", base: 0.0d}], DeathLootTable: "dawn:entities/mushroom_zombie", PersistenceRequired:1b}

tp @s ~ -255 ~

kill @s