
advancement revoke @s only dawn:enchantment/recuperation_2

scoreboard players add @s dawn.enchantment.recuperation.cd 1080

effect give @s minecraft:fire_resistance 18 0 false

effect give @s minecraft:instant_health 1 2 true

effect give @s minecraft:speed 5 2 true

playsound dawn:enchantment.recuperation player @a ~ ~ ~ 0.8
