# 获取耐久数值
scoreboard objectives add dawn.anvil.durability dummy
scoreboard objectives add dawn.anvil.max_durability dummy
execute store result score @s dawn.anvil.durability run data get entity @n[type=minecraft:item_display] item.components."minecraft:custom_data".anvil.durability
execute store result score @s dawn.anvil.max_durability run data get entity @n[type=minecraft:item_display] item.components."minecraft:custom_data".anvil.max_durability

# 耐久耗尽
execute if score @s dawn.anvil.durability matches ..0 run function dawn:anvil/break

# playsound
execute if score @s dawn.anvil.durability matches ..0 run playsound block.anvil.destroy block @a ~ ~ ~

# 获取百分比
scoreboard objectives add dawn.anvil.durability.op dummy
scoreboard players set percent dawn.anvil.durability.op 100

# scoreboard players operation @s dawn.anvil.durability.op = @s dawn.anvil.durability
# scoreboard players operation @s dawn.anvil.max_durability /= percent dawn.anvil.durability.op
# scoreboard players operation @s dawn.anvil.durability.op /= @s dawn.anvil.max_durability

# 旧算法（超过2147483647上限，废弃）
scoreboard players operation @s dawn.anvil.durability.op = @s dawn.anvil.durability
scoreboard players operation @s dawn.anvil.durability.op *= percent dawn.anvil.durability.op
scoreboard players operation @s dawn.anvil.durability.op /= @s dawn.anvil.max_durability

# 可能结果 0~100 (dawn.anvil.durability.op)

# 耐久条显示
scoreboard objectives add dawn.durability_show dummy
scoreboard players operation @s dawn.durability_show = @s dawn.anvil.durability.op
scoreboard players remove @s dawn.durability_show 1
execute store result storage dawn:anvil_durability durability_show int 0.5 run scoreboard players get @s dawn.durability_show
function dawn:anvil/durability_show with storage dawn:anvil_durability

# 耐久名称
execute store result storage dawn:anvil_durability durability_percent int 1 run scoreboard players get @s dawn.anvil.durability.op
function dawn:anvil/durability_name with storage dawn:anvil_durability

# 铁砧纹理
function dawn:anvil/anvil_item_model
