
tag @s add sell_4

# 7
data modify entity @s Offers.Recipes[-2] set value {maxUses:16, sell:{count:1, id:"minecraft:emerald"}, buy:{count:24, id:"minecraft:feather"}, priceMultiplier: 0.05f, xp:30}

# 8
data modify entity @s Offers.Recipes[-1] set value {maxUses:6, sell:{count:1, id:"minecraft:stone"}, buy:{count:8, id:"minecraft:emerald"}, priceMultiplier: 0.05f, xp:15}
loot replace entity @s armor.head loot dawn:bow/steel_bow
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head

item replace entity @s armor.head with air
