
scoreboard players set @s dawn.enchantment.momentum 40
scoreboard players set @s dawn.enchantment.momentum.time 21

