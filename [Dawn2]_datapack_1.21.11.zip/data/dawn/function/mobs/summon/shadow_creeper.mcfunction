
# Shadow Creeper 暗影苦力怕
summon minecraft:creeper ~ ~ ~ {CustomName: "Shadow Creeper", Tags: ["summon", "shadow_creeper"], Fuse: 30s, equipment: {feet: {components: {"!minecraft:attribute_modifiers": {}, "minecraft:equippable": {equip_sound: "minecraft:block.stone.hit", slot: "feet", asset_id: "dawn:air"}, "!minecraft:enchantable": {}, "minecraft:item_model": "minecraft:barrier", "!minecraft:repairable": {}, "minecraft:enchantments": {"minecraft:dark_invisibility": 1}, "!minecraft:max_damage": {}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_name": {}, "!minecraft:damage": {}}, count: 1, id: "minecraft:leather_boots"}}, drop_chances: {mainhand: 0.0f, head: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, attributes: [{id: "minecraft:movement_speed", base: 0.25d}], ExplosionRadius: 2b}

tp @s ~ -255 ~

kill @s