# loot
execute as @s[tag=dawn.stone] run loot spawn ~ ~ ~ loot dawn:anvil/stone_anvil
execute as @s[tag=dawn.golden] run loot spawn ~ ~ ~ loot dawn:anvil/golden_anvil
execute as @s[tag=dawn.copper] run loot spawn ~ ~ ~ loot dawn:anvil/copper_anvil
execute as @s[tag=dawn.iron] run loot spawn ~ ~ ~ loot dawn:anvil/iron_anvil
# execute as @s[tag=dawn.rose_golden] run loot spawn ~ ~ ~ loot dawn:anvil/rose_golden_anvil
execute as @s[tag=dawn.ancient_metal] run loot spawn ~ ~ ~ loot dawn:anvil/ancient_metal_anvil
# execute as @s[tag=dawn.steel] run loot spawn ~ ~ ~ loot dawn:anvil/steel_anvil
execute as @s[tag=dawn.mithril] run loot spawn ~ ~ ~ loot dawn:anvil/mithril_anvil
execute as @s[tag=dawn.vibranium] run loot spawn ~ ~ ~ loot dawn:anvil/vibranium_anvil
execute as @s[tag=dawn.adamantium] run loot spawn ~ ~ ~ loot dawn:anvil/adamantium_anvil
