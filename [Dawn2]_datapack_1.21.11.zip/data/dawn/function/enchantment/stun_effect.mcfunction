
# scoreboard players remove @e[scores={dawn.enchantment.stun=1..}] dawn.enchantment.stun 1

# execute as @e[scores={dawn.enchantment.stun=1..}] run attribute @s minecraft:movement_speed modifier add stun.movement_speed -1 add_multiplied_total
# execute as @e[scores={dawn.enchantment.stun=0}] run attribute @s minecraft:movement_speed modifier remove stun.movement_speed

# execute as @e[scores={dawn.enchantment.stun=1..}] run attribute @s minecraft:jump_strength modifier add stun.jump_strength -1 add_multiplied_total
# execute as @e[scores={dawn.enchantment.stun=0}] run attribute @s minecraft:jump_strength modifier remove stun.jump_strength

# execute as @e[scores={dawn.enchantment.stun=1..}] run attribute @s minecraft:attack_damage modifier add stun.attack_damage -1 add_multiplied_total
# execute as @e[scores={dawn.enchantment.stun=0}] run attribute @s minecraft:attack_damage modifier remove stun.attack_damage

# execute as @e[scores={dawn.enchantment.stun=1..}] run attribute @s minecraft:attack_speed modifier add stun.attack_speed -1 add_multiplied_total
# execute as @e[scores={dawn.enchantment.stun=0}] run attribute @s minecraft:attack_speed modifier remove stun.attack_speed

# execute as @e[scores={dawn.enchantment.stun=1..}] at @s run particle dust{color:[0.435, 0.373, 0.161], scale:1} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal



# by：Minecraft_hyr

scoreboard players remove @e[type=!#dawn:non_living, scores={dawn.enchantment.stun=1..}] dawn.enchantment.stun 1
execute as @e[type=!#dawn:non_living, scores={dawn.enchantment.stun=1..}] run return run function dawn:enchantment/stun_effect_add
execute as @e[type=!#dawn:non_living, scores={dawn.enchantment.stun=0}] run function dawn:enchantment/stun_effect_remove
