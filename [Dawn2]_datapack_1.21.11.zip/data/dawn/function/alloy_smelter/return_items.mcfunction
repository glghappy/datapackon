#储存数据
data modify entity @s data.dawn.smeltery.Items set from block ~ ~ ~ Items

#移除可操作格子数据
data remove entity @s data.dawn.smeltery.Items[{Slot: 1b}]
data remove entity @s data.dawn.smeltery.Items[{Slot: 2b}]
data remove entity @s data.dawn.smeltery.Items[{Slot: 3b}]
data remove entity @s data.dawn.smeltery.Items[{Slot: 16b}]
data remove entity @s data.dawn.smeltery.Items[{Slot: 20b}]

#移除GUI本体数据
data remove entity @s data.dawn.smeltery.Items[{components:{"minecraft:custom_data":{dawn_clear:1b}}}]

#返还误放入物品
execute if data entity @s data.dawn.smeltery.Items[0] align y positioned ~ ~1 ~ run summon minecraft:item ~ ~ ~ {Item:{id: "minecraft:barrier", count: 1b}, Tags:["dawn.smeltery.gui.Items"]}
execute if data entity @s data.dawn.smeltery.Items[0] align y positioned ~ ~1 ~ run data modify entity @n[type=minecraft:item, tag=dawn.smeltery.gui.Items] Item set from entity @s data.dawn.smeltery.Items[0]
execute if data entity @s data.dawn.smeltery.Items[0] at @p run tp @n[type=minecraft:item, tag=dawn.smeltery.gui.Items] ~ ~ ~
execute if data entity @s data.dawn.smeltery.Items[0] at @p run tag @n[type=minecraft:item, tag=dawn.smeltery.gui.Items] remove dawn.smeltery.gui.Items

#清除数据
data remove entity @s data.dawn.craft_table.Items