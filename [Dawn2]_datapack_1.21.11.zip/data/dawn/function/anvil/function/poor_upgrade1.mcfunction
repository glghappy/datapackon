
# 检测强化石等级
scoreboard objectives add dawn.anvil.item.refining_gem dummy
execute store result score @s dawn.anvil.item.refining_gem run data get block ~ ~ ~ Items.[{Slot: 13b}].components."minecraft:custom_data".refining_gem

# 强化石符合要求
execute if score @s dawn.anvil.item.quality = @s dawn.anvil.item.refining_gem run function dawn:anvil/function/poor_upgrade2

