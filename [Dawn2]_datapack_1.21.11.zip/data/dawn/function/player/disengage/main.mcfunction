
scoreboard players remove @s[scores={dawn.player.disengage=1..}] dawn.player.disengage 1

tag @s[scores={dawn.player.disengage=1..}, tag=disengage] remove disengage
tag @s[scores={dawn.player.disengage=0}, tag=!disengage] add disengage
