
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:stone"}, buy:{count:9, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:5}
loot replace entity @s armor.head loot dawn:armor/iron_wooden_chestplate
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head
