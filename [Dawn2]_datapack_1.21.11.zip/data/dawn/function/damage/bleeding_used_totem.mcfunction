
advancement revoke @s only dawn:damage/bleeding

scoreboard players reset @s dawn.effect.bleeding
scoreboard players reset @s dawn.effect.bleeding_cd