
tag @s add frost_shockwave

scoreboard players set @s dawn.enchantment.frost_shockwave.cd 40

execute as @e[distance=..8, tag=!frost_shockwave, type=!item_frame, type=!glow_item_frame, type=!item] run damage @s 1.5 minecraft:freeze by @p[tag=frost_shockwave]

execute as @e[distance=..8, tag=!frost_shockwave, type=!item_frame, type=!glow_item_frame, type=!item] run scoreboard players set @s dawn.enchantment.frost_shockwave 40

tag @s remove frost_shockwave

particle dust{color:[1, 1, 1], scale:1} ~ ~1 ~ 4 0 4 0 240 normal