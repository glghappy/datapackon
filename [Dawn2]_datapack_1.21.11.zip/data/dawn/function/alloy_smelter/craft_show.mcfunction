
$data modify block ~ ~ ~ Items.[{Slot:14b}].components."minecraft:item_model" set value "dawn:alloy_smelter_craft_$(craft_show)"
