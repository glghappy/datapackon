
# 获取锤子等级 (dawn.anvil.hammer_level)
scoreboard objectives add dawn.anvil.hammer_level dummy
execute store result score @s dawn.anvil.hammer_level run data get block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".anvil.level

# 砧符合等级，可输出
execute as @s[tag=anvillevel.1] if score @s dawn.anvil.hammer_level matches 1..2 run function dawn:anvil/craft/hammer_main
execute as @s[tag=anvillevel.2] if score @s dawn.anvil.hammer_level matches 1..3 run function dawn:anvil/craft/hammer_main
execute as @s[tag=anvillevel.3] if score @s dawn.anvil.hammer_level matches 1..4 run function dawn:anvil/craft/hammer_main
execute as @s[tag=anvillevel.4] if score @s dawn.anvil.hammer_level matches 1..5 run function dawn:anvil/craft/hammer_main
execute as @s[tag=anvillevel.5] if score @s dawn.anvil.hammer_level matches 1..6 run function dawn:anvil/craft/hammer_main
execute as @s[tag=anvillevel.6] if score @s dawn.anvil.hammer_level matches 1..6 run function dawn:anvil/craft/hammer_main
