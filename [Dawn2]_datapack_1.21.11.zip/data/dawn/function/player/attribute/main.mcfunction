
# 获取等级
scoreboard players operation @s dawn.player.level.operation = @s dawn.player.level

# 玩家属性修改
function dawn:player/attribute/effect with storage dawn:gamemode

# 生命值
execute if score #max_health dawn.gamerule matches 0 run function dawn:player/attribute/max_health_base
execute if score #max_health dawn.gamerule matches 1 run function dawn:player/attribute/max_health_base_40

# 挖掘速度提升
execute store result storage dawn:player block_break_speed double 0.02 run scoreboard players get @s dawn.player.level.operation
function dawn:player/attribute/block_break_speed with storage dawn:player

# 攻击伤害提升
execute store result storage dawn:player attack_damage double 0.005 run scoreboard players get @s dawn.player.level.operation
function dawn:player/attribute/attack_damage with storage dawn:player
