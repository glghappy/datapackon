
scoreboard players add @s dawn.player.starve 1

execute as @s[scores={dawn.player.starve=80..}] run function dawn:player/food/starve_damage
