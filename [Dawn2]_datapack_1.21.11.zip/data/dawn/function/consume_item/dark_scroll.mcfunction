advancement revoke @s only dawn:consume_item/dark_scroll

execute store result score @s dawn.locate run locate structure dawn:dark_castle

tellraw @s[scores={dawn.locate=1..}] [{"translate":"broadcast.dawn.dark_castle", "color": "white", "italic": false, "with": [{"score": {"name": "@s","objective": "dawn.locate"}}]}]

tellraw @s[scores={dawn.locate=0}] [{"translate":"broadcast.dawn.no", "color": "red", "italic": false}]
