
scoreboard objectives add dawn.player.health health

scoreboard objectives add dawn.enchantment.truce dummy

scoreboard objectives add dawn.enchantment.recuperation.cd dummy

# recuperation
schedule function dawn:enchantment/recuperation_effect 1s

# surging
scoreboard objectives add dawn.enchantment.surging dummy

# enderman_repression
scoreboard objectives add dawn.enchantment.enderman_repression dummy

# stun
scoreboard objectives add dawn.enchantment.stun dummy

# momentum
scoreboard objectives add dawn.enchantment.momentum dummy
scoreboard objectives add dawn.enchantment.momentum.time dummy

# feral_fury
scoreboard objectives add dawn.enchantment.feral_fury.effect dummy
scoreboard objectives add dawn.enchantment.feral_fury.time dummy

# frost_shockwave
scoreboard objectives add dawn.enchantment.frost_shockwave dummy
scoreboard objectives add dawn.enchantment.frost_shockwave.cd dummy

# dash
scoreboard objectives add dawn.enchantment.dash dummy

# soul_devour
scoreboard objectives add dawn.enchantment.soul_devour dummy

# free_action
scoreboard objectives add dawn.enchantment.slowness dummy
scoreboard objectives add dawn.enchantment.free_action dummy

# blessing_of_water
scoreboard objectives add dawn.enchantment.blessing_of_water dummy

# attack_palsy
scoreboard objectives add dawn.enchantment.attack_palsy dummy
schedule function dawn:enchantment/attack_palsy_effect 2t

# sectumsempra
scoreboard objectives add dawn.enchantment.sectumsempra dummy

# ancient_charm
scoreboard objectives add dawn.enchantment.ancient_charm dummy
scoreboard objectives add dawn.enchantment.ancient_charm.attribute dummy

# eternal_frost
scoreboard objectives add dawn.enchantment.eternal_frost dummy

# kinetic_absorption
scoreboard objectives add dawn.enchantment.kinetic_absorption dummy

# corrupt_bleeding_weeper
scoreboard objectives add dawn.entity.corrupt_bleeding_weeper dummy
