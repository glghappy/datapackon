
execute store result storage dawn:entity pos_y int 1.1 run data get entity @s Pos[1]

function dawn:enchantment/phase_spider with storage dawn:entity