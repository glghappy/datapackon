
# by：Minecraft_hyr

attribute @s attack_damage modifier add truce.attack_damage -1 add_multiplied_total

execute if score @s dawn.enchantment.truce matches 20.. run return run particle dust{color:[0.012, 0.573, 0.153], scale:1} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal
execute if score @s dawn.enchantment.truce matches 1..20 run particle dust{color:[0.709, 0.999, 0.784], scale:1.5} ~ ~1 ~ 0.3 0.55 0.3 0.15 1 normal
