advancement revoke @s only dawn:consume_item/cod_stew

scoreboard players add @s dawn.player.protein 83678
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000

scoreboard players add @s dawn.player.phytonutrients 9298
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
