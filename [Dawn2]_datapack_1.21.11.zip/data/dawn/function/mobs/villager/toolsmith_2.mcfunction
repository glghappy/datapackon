
tag @s add sell_2

# 3
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:5, id:"minecraft:iron_ingot"}, priceMultiplier: 0.05f, demand:-12, xp:5}

# 4
function dawn:mobs/villager/toolsmith_2_1
execute if predicate dawn:random/0.5 run function dawn:mobs/villager/toolsmith_2_2

item replace entity @s armor.head with air
