
attribute @s minecraft:attack_damage modifier remove enchantment.feral_fury

$attribute @s minecraft:attack_damage modifier add enchantment.feral_fury $(enchantment_feral_fury_damage) add_value


attribute @s minecraft:attack_speed modifier remove enchantment.feral_fury

$attribute @s minecraft:attack_speed modifier add enchantment.feral_fury $(enchantment_feral_fury_speed) add_multiplied_base

