
$scoreboard players set @s dawn.alloy_smelter.craft_finish $(score)

$data modify entity @s item.components."minecraft:custom_data".output_material set value "$(material)"

data modify entity @s item.components."minecraft:custom_data".smelting set value true