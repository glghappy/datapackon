
effect give @s minecraft:wither 12 0 false
