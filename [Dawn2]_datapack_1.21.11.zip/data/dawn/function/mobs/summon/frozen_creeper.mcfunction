
# Frozen Creeper 冰冻苦力怕
summon minecraft:creeper ~ ~ ~ {CustomName: "Frozen Creeper", Tags:["frozen_creeper", "summon"], attributes: [{id: "minecraft:movement_speed", base: 0.23d}, {id: "minecraft:armor", base: 4.0d}], Fuse: 35s, ExplosionRadius: 3b, drop_chances: {mainhand: 0.0f, head: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}, equipment: {feet: {components: {"!minecraft:attribute_modifiers": {}, "!minecraft:enchantable": {}, "minecraft:equippable": {equip_sound: "minecraft:block.stone.hit", slot: "feet", asset_id: "dawn:air"}, "!minecraft:repairable": {}, "minecraft:item_model": "minecraft:barrier", "minecraft:enchantments": {"minecraft:freezing_immunity": 1}, "!minecraft:max_damage": {}, "minecraft:enchantment_glint_override": 0b, "!minecraft:item_name": {}, "!minecraft:damage": {}}, count: 1, id: "minecraft:leather_boots"}}}

tp @s ~ -255 ~

kill @s