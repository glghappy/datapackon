
schedule function dawn:enchantment/recuperation_effect 1s

scoreboard players remove @a[scores={dawn.enchantment.recuperation.cd=1..}] dawn.enchantment.recuperation.cd 1
