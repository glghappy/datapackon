
$effect give @s minecraft:regeneration $(soul_devour) 1 false

$effect give @s minecraft:strength $(soul_devour) 0 false
