advancement revoke @s only dawn:consume_item/mutton

scoreboard players add @s dawn.player.protein 10816
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000
