# break barrel again
execute if block ~ ~ ~ barrel run setblock ~ ~ ~ air destroy

# loot
loot spawn ~ ~ ~ loot dawn:alloy_smelter

# 移除熔炉发光
function dawn:alloy_smelter/light_destory

# kill item
execute as @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:barrel"}}] run kill @s

# kill self
kill @s
