
tag @s add sell_3

# 5
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:9, id:"minecraft:rabbit_hide"}, priceMultiplier: 0.05f, xp:20}

# 6
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:stone"}, buy:{count:4, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:10}
loot replace entity @s armor.head loot dawn:armor/leather_helmet
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head

item replace entity @s armor.head with air
