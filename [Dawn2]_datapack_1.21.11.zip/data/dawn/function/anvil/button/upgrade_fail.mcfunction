
# 扣除材料
# 原料
execute store result score @s dawn.anvil.item.count run data get block ~ ~ ~ Items[{Slot:13b}].count

# 记录数
execute store result score @s dawn.anvil.item.operation2 run data get block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_cost

# 扣除
execute store result storage dawn:count count int 1 run scoreboard players operation @s dawn.anvil.item.count -= @s dawn.anvil.item.operation2
execute if score @s dawn.anvil.item.count matches 0 run item replace block ~ ~ ~ container.13 with air
execute if score @s dawn.anvil.item.count matches 1.. run data modify block ~ ~ ~ Items[{Slot:13b}].count set from storage dawn:count count


# 播放声音
playsound minecraft:block.lava.extinguish block @a ~ ~ ~

