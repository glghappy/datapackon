
stopsound @a[distance=..8] block minecraft:block.barrel.open
stopsound @a[distance=..8] block minecraft:block.barrel.close

# 木桶开启后————————————————————

# 清除【输出格-16】
execute if predicate dawn:anvil/output/output_can_clear run item replace block ~ ~ ~ container.16 with air
# item replace block ~ ~ ~ container.16 with firework_star[minecraft:item_name="砧", minecraft:custom_data={"dawn_clear":true}, minecraft:custom_model_data=16660000]

# 检测等级-展示成品（工具调整）
execute if predicate dawn:anvil/input/have_input if predicate dawn:anvil/material/have_material unless predicate dawn:anvil/material/component if predicate dawn:anvil/output/can_output run function dawn:anvil/function/check_level

# 检测等级-展示成品（使用锤子合成——双锭/砧）
execute if predicate dawn:anvil/input/have_input if predicate dawn:anvil/material/hammer if predicate dawn:anvil/output/can_output run function dawn:anvil/craft/hammer_check_level

# 检测等级-展示成品（合成工具 or 盔甲 or 弓）
execute if predicate dawn:anvil/input/component_or_plating_or_bow_limb if predicate dawn:anvil/material/have_material if predicate dawn:anvil/output/can_output run function dawn:anvil/craft/assemble_check_level

# 检测双边等级-展示成品（刻印）
execute if predicate dawn:anvil/input/have_input unless predicate dawn:anvil/input/have_engrave unless predicate dawn:anvil/input/component if predicate dawn:anvil/material/component if predicate dawn:anvil/output/can_output run function dawn:anvil/craft/engrave_check_level

# button/触发效果
execute as @s[tag=dawn.anvil.work] run function dawn:anvil/button/main

# ——————————————————————————————

# break
execute unless block ~ ~ ~ minecraft:barrel run function dawn:anvil/break