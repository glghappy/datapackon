# stone → 1
# copper/golden → 2
# iron → 3
# ancient_metal → 4
# mithril → 5
# vibranium/adamantium → 6

# stone
execute as @s[tag=dawn.stone] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:stone_anvil", custom_data:{anvil:{material:stone}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.stone", "anvillevel.1"], view_range:8}
execute as @s[tag=dawn.stone] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.stone_anvil"}} replace

# copper
execute as @s[tag=dawn.copper] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:copper_anvil", custom_data:{anvil:{material:copper}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.copper", "anvillevel.2"], view_range:8}
execute as @s[tag=dawn.copper] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.copper_anvil"}} replace

# golden
execute as @s[tag=dawn.golden] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:golden_anvil", custom_data:{anvil:{material:golden}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.golden", "anvillevel.2"], view_range:8}
execute as @s[tag=dawn.golden] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.golden_anvil"}} replace

# iron
execute as @s[tag=dawn.iron] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:iron_anvil", custom_data:{anvil:{material:iron}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.iron", "anvillevel.3"], view_range:8}
execute as @s[tag=dawn.iron] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.iron_anvil"}} replace

# ancient_metal
execute as @s[tag=dawn.ancient_metal] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:ancient_metal_anvil", custom_data:{anvil:{material:ancient_metal}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.ancient_metal", "anvillevel.4"], view_range:8}
execute as @s[tag=dawn.ancient_metal] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.ancient_metal_anvil"}} replace

# mithril
execute as @s[tag=dawn.mithril] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:mithril_anvil", custom_data:{anvil:{material:mithril}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.mithril", "anvillevel.5"], view_range:8}
execute as @s[tag=dawn.mithril] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.mithril_anvil"}} replace

# vibranium
execute as @s[tag=dawn.vibranium] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:vibranium_anvil", custom_data:{anvil:{material:vibranium}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.vibranium", "anvillevel.6"], view_range:8}
execute as @s[tag=dawn.vibranium] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.vibranium_anvil"}} replace

# adamantium
execute as @s[tag=dawn.adamantium] align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:adamantium_anvil", custom_data:{anvil:{material:adamantium}}}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.anvil", "dawn.adamantium", "anvillevel.6"], view_range:8}
execute as @s[tag=dawn.adamantium] run setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.adamantium_anvil"}} replace

# Rotation
execute as @e[type=minecraft:item_display, limit=1, sort=nearest] at @s if entity @p[y_rotation=-45..45] run data modify entity @s Rotation set value [0.0f, 0.0f]
execute as @e[type=minecraft:item_display, limit=1, sort=nearest] at @s if entity @p[y_rotation=45..135] run data modify entity @s Rotation set value [90.0f, 0.0f]
execute as @e[type=minecraft:item_display, limit=1, sort=nearest] at @s if entity @p[y_rotation=135..-135] run data modify entity @s Rotation set value [180.0f, 0.0f]
execute as @e[type=minecraft:item_display, limit=1, sort=nearest] at @s if entity @p[y_rotation=-135..-45] run data modify entity @s Rotation set value [270.0f, 0.0f]

# summon marker
execute align xyz positioned ~.5 ~.5 ~.5 run summon minecraft:marker ~ ~ ~ {Tags:["dawn.anvil"]}

# modify Durability
data modify entity @n[type=minecraft:item_display] item.components."minecraft:custom_data".anvil.durability set from entity @s Item.components."minecraft:custom_data".anvil.durability
data modify entity @n[type=minecraft:item_display] item.components."minecraft:custom_data".anvil.max_durability set from entity @s Item.components."minecraft:custom_data".anvil.max_durability

# modify CustomModelData （来自框内实体数据）
# data modify entity @e[type=minecraft:item_display, limit=1, sort=nearest] item.components."minecraft:custom_model_data" set from entity @s Item.components."minecraft:custom_model_data"

# kill
kill @s

# playsound
playsound minecraft:block.anvil.place block @a