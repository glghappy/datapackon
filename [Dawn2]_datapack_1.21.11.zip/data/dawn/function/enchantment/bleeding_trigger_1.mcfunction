
scoreboard players set @s dawn.effect.bleeding 100