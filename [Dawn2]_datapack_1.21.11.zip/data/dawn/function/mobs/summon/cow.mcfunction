
tag @s add summon

attribute @s minecraft:max_health base set 20
data modify entity @s Health set value 20
