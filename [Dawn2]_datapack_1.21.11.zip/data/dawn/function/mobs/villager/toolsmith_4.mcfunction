
tag @s add sell_4

# 7
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:1, id:"minecraft:diamond"}, priceMultiplier: 0.05f, xp:30}

# 8
function dawn:mobs/villager/toolsmith_4_1
execute if predicate dawn:random/0.5 run function dawn:mobs/villager/toolsmith_4_2

item replace entity @s armor.head with air
