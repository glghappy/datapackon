
# 获取强化槽 (dawn.anvil.item.enhancement)
scoreboard objectives add dawn.anvil.item.enhancement dummy
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".enhancement_slot

# 获取初始强化槽 (dawn.anvil.item.enhancement_2)
scoreboard objectives add dawn.anvil.item.enhancement_2 dummy
execute store result score @s dawn.anvil.item.enhancement_2 run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".quality.base_enhancement_slot

# 双重剩余槽位
execute if score @s dawn.anvil.item.enhancement matches 2.. if score @s dawn.anvil.item.enhancement_2 matches 2.. run function dawn:anvil/craft/engrave_check_material
