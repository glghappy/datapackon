
# 检测工具和部件材质是否相同（0-成功， 1-失败）
scoreboard objectives add dawn.anvil.material_check dummy
data modify storage dawn:material_check type set from block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".material.type
execute store success score @s dawn.anvil.material_check run data modify storage dawn:material_check type set from block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".material.type
execute if score @s dawn.anvil.material_check matches 1 run function dawn:anvil/craft/engrave_check_type



# 检测工具手柄和手柄材质是否相同（0-成功， 1-失败） 直接跳过类型检测
data modify storage dawn:material_check type set from block ~ ~ ~ Items[{Slot:10b}].components."minecraft:custom_data".handle.type
execute store success score @s dawn.anvil.material_check run data modify storage dawn:material_check type set from block ~ ~ ~ Items[{Slot:13b}].components."minecraft:custom_data".material.type
execute if score @s dawn.anvil.material_check matches 1 if predicate dawn:anvil/material/stick run function dawn:anvil/craft/engrave_main
