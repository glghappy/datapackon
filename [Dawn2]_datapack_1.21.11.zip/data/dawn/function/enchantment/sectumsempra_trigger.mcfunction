# say trigger
execute store result score #entity dawn.enchantment.sectumsempra run attribute @s minecraft:max_health modifier value get enchantment.sectumsempra
execute store result storage dawn:entity sectumsempra byte 1 run scoreboard players remove #entity dawn.enchantment.sectumsempra 1

function dawn:enchantment/sectumsempra_trigger_effect with storage dawn:entity
