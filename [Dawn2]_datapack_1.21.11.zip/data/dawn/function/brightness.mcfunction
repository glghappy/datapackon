execute if predicate dawn:light/light_0 run data modify entity @s brightness.sky set value 0
execute if predicate dawn:light/light_1 run data modify entity @s brightness.sky set value 1
execute if predicate dawn:light/light_2 run data modify entity @s brightness.sky set value 2
execute if predicate dawn:light/light_3 run data modify entity @s brightness.sky set value 3
execute if predicate dawn:light/light_4 run data modify entity @s brightness.sky set value 4
execute if predicate dawn:light/light_5 run data modify entity @s brightness.sky set value 5
execute if predicate dawn:light/light_6 run data modify entity @s brightness.sky set value 6
execute if predicate dawn:light/light_7 run data modify entity @s brightness.sky set value 7
execute if predicate dawn:light/light_8 run data modify entity @s brightness.sky set value 8
execute if predicate dawn:light/light_9 run data modify entity @s brightness.sky set value 9
execute if predicate dawn:light/light_10 run data modify entity @s brightness.sky set value 10
execute if predicate dawn:light/light_11 run data modify entity @s brightness.sky set value 11
execute if predicate dawn:light/light_12 run data modify entity @s brightness.sky set value 12
execute if predicate dawn:light/light_13 run data modify entity @s brightness.sky set value 13
execute if predicate dawn:light/light_14 run data modify entity @s brightness.sky set value 14
execute if predicate dawn:light/can_see_sky run data modify entity @s brightness.sky set value 15

execute if predicate dawn:light/light_0 run data modify entity @s brightness.block set value 0
execute if predicate dawn:light/light_1 run data modify entity @s brightness.block set value 1
execute if predicate dawn:light/light_2 run data modify entity @s brightness.block set value 2
execute if predicate dawn:light/light_3 run data modify entity @s brightness.block set value 3
execute if predicate dawn:light/light_4 run data modify entity @s brightness.block set value 4
execute if predicate dawn:light/light_5 run data modify entity @s brightness.block set value 5
execute if predicate dawn:light/light_6 run data modify entity @s brightness.block set value 6
execute if predicate dawn:light/light_7 run data modify entity @s brightness.block set value 7
execute if predicate dawn:light/light_8 run data modify entity @s brightness.block set value 8
execute if predicate dawn:light/light_9 run data modify entity @s brightness.block set value 9
execute if predicate dawn:light/light_10 run data modify entity @s brightness.block set value 10
execute if predicate dawn:light/light_11 run data modify entity @s brightness.block set value 11
execute if predicate dawn:light/light_12 run data modify entity @s brightness.block set value 12
execute if predicate dawn:light/light_13 run data modify entity @s brightness.block set value 13
execute if predicate dawn:light/light_14 run data modify entity @s brightness.block set value 14

# execute if predicate dawn:light/light_14 run data modify entity @s brightness.block set value 14
# execute if predicate dawn:light/light_13 run data modify entity @s brightness.block set value 13
# execute if predicate dawn:light/light_12 run data modify entity @s brightness.block set value 12
# execute if predicate dawn:light/light_11 run data modify entity @s brightness.block set value 11
# execute if predicate dawn:light/light_10 run data modify entity @s brightness.block set value 10
# execute if predicate dawn:light/light_9 run data modify entity @s brightness.block set value 9
# execute if predicate dawn:light/light_8 run data modify entity @s brightness.block set value 8
# execute if predicate dawn:light/light_7 run data modify entity @s brightness.block set value 7
# execute if predicate dawn:light/light_6 run data modify entity @s brightness.block set value 6
# execute if predicate dawn:light/light_5 run data modify entity @s brightness.block set value 5
# execute if predicate dawn:light/light_4 run data modify entity @s brightness.block set value 4
# execute if predicate dawn:light/light_3 run data modify entity @s brightness.block set value 3
# execute if predicate dawn:light/light_2 run data modify entity @s brightness.block set value 2
# execute if predicate dawn:light/light_1 run data modify entity @s brightness.block set value 1
# execute if predicate dawn:light/light_0 run data modify entity @s brightness.block set value 0