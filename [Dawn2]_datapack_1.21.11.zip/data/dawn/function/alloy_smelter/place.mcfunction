
# stopsound
stopsound @a * entity.item_frame.place

# Place
execute align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:firework_star", count:1b, components:{"item_model": "dawn:alloy_smelter"}}, transformation:{left_rotation:[0.0f, 0.0f, 0.0f, 1.0f], translation:[0.0f, 0.0f, 0.0f], right_rotation:[0.0f, 0.0f, 0.0f, 1.0f], scale:[1.003f, 1.003f, 1.003f]}, brightness:{sky:15, block:0}, Tags:["dawn.alloy_smelter"], view_range:8}
setblock ~ ~ ~ barrel[facing=up]{CustomName:{"translate":"item.dawn.alloy_smelter"}} replace

# Rotation
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=-45..45] run data modify entity @s Rotation set value [180.0f, 0.0f]
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=45..135] run data modify entity @s Rotation set value [270.0f, 0.0f]
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=135..-135] run data modify entity @s Rotation set value [0.0f, 0.0f]
execute as @n[type=minecraft:item_display, distance=...5] at @s if entity @p[y_rotation=-135..-45] run data modify entity @s Rotation set value [90.0f, 0.0f]

# summon marker
execute align xyz positioned ~.5 ~.5 ~.5 run summon minecraft:marker ~ ~ ~ {Tags:["dawn.alloy_smelter"]}

# 设置初始值
execute as @n[type=minecraft:item_display, distance=...5] run scoreboard players set @s dawn.alloy_smelter.fuel_time 0

# kill
kill @s