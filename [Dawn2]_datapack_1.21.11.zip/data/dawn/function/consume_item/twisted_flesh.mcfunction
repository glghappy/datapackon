advancement revoke @s only dawn:consume_item/twisted_flesh

tag @s add twisted_flesh

scoreboard players add @s dawn.player.protein 16000
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000