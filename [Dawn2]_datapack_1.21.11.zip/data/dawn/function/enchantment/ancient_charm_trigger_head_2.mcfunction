
# execute store result score @s dawn.enchantment.ancient_charm.attribute run data get entity @s equipment.head.components."minecraft:attribute_modifiers"[{"type": "minecraft:armor"}].amount 100

# execute store result storage dawn:entity ancient_charm double 0.01 run scoreboard players add @s dawn.enchantment.ancient_charm.attribute 1

# item modify entity @s armor.head dawn:ancient_charm

# say hu