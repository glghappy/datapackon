data merge storage title:io {  \
    text: {"text":"\u5991","color":"white", "shadow_color":0},  \
    font: "dawn:food",  \
    neg_font: "dawn:food_neg",  \
    x: -11.5,  y: -63,  \
    align: "middle",  \
    origin: "up-right"  \
}
function title:new_text