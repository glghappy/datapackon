
# tag
tag @s add summon


# summon

# Earth Elemental E (ban_transform)(equipment)(silent)
execute if dimension minecraft:the_end if predicate dawn:random/0.08 run return run function dawn:mobs/summon/earth_elemental_e


# attribute
attribute @s minecraft:attack_damage base set 12