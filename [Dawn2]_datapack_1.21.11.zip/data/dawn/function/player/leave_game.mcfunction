function dawn:player/prologue

scoreboard players reset @s dawn.player.leave_game