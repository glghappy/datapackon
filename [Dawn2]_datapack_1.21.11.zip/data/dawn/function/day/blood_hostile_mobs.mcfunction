
effect give @s minecraft:strength 18 0 false
effect give @s minecraft:speed 18 0 false
effect give @s minecraft:infested 18 0 false
