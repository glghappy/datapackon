#储存数据
data modify entity @s data.dawn.anvil.Items set from block ~ ~ ~ Items

#移除可操作格子数据
data remove entity @s data.dawn.anvil.Items[{Slot: 10b}]
data remove entity @s data.dawn.anvil.Items[{Slot: 13b}]
data remove entity @s data.dawn.anvil.Items[{Slot: 16b}]

#移除GUI本体数据
data remove entity @s data.dawn.anvil.Items[{components:{"minecraft:custom_data":{dawn_clear:1b}}}]

#返还误放入物品
execute if data entity @s data.dawn.anvil.Items[0] align y positioned ~ ~1 ~ run summon minecraft:item ~ ~ ~ {Item:{id: "minecraft:barrier", count: 1b}, Tags:["dawn.anvil.gui.Items"]}
execute if data entity @s data.dawn.anvil.Items[0] align y positioned ~ ~1 ~ run data modify entity @n[type=minecraft:item, tag=dawn.anvil.gui.Items] Item set from entity @s data.dawn.anvil.Items[0]
execute if data entity @s data.dawn.anvil.Items[0] at @p run tp @n[type=minecraft:item, tag=dawn.anvil.gui.Items] ~ ~ ~
execute if data entity @s data.dawn.anvil.Items[0] at @p run tag @n[type=minecraft:item, tag=dawn.anvil.gui.Items] remove dawn.anvil.gui.Items

#清除数据
data remove entity @s data.dawn.craft_table.Items