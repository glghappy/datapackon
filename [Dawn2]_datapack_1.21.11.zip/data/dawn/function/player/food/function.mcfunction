
$scoreboard players set @s dawn.player.foodBar $(max_point)

$scoreboard players remove @s dawn.player.foodLevel_show $(remove)
scoreboard players set @s[scores={dawn.player.foodLevel_show=..0}] dawn.player.foodLevel_show 0

$scoreboard players set @s[scores={dawn.player.foodSaturationLevel_show=$(max_point)..}] dawn.player.foodSaturationLevel_show $(max_point)


# 如果隐藏饱和度大于显示饱和度，获得饥饿效果
execute if score @s dawn.player.foodSaturationLevel > @s dawn.player.foodSaturationLevel_show run effect give @s hunger 1 29 true


execute unless predicate dawn:player/hunger run scoreboard players add @s dawn.player.foodBar 6000
execute if predicate dawn:player/hunger run scoreboard players add @s dawn.player.foodBar 6100

execute unless predicate dawn:player/hunger run scoreboard players add @s dawn.player.foodLevel_show 6200
execute if predicate dawn:player/hunger run scoreboard players add @s dawn.player.foodLevel_show 6300

scoreboard players add @s dawn.player.foodSaturationLevel_show 6400