# break barrel again
execute if block ~ ~ ~ barrel run setblock ~ ~ ~ air destroy

# loot
execute as @s[tag=dawn.cobblestone] run loot spawn ~ ~ ~ loot dawn:smeltery/cobblestone_smeltery
execute as @s[tag=dawn.obsidian] run loot spawn ~ ~ ~ loot dawn:smeltery/obsidian_smeltery
execute as @s[tag=dawn.netherrack] run loot spawn ~ ~ ~ loot dawn:smeltery/netherrack_smeltery

# 移除熔炉发光
function dawn:smeltery/light_destory

# kill item
execute as @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:barrel"}}] run kill @s

# kill self
kill @s
