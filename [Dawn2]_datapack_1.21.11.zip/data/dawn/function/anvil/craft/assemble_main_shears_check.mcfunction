
$execute if items block ~ ~ ~ container.13 *[custom_data~{material:{"type": "$(head_material)"}}] \
run function dawn:anvil/craft/assemble_loot_shears with storage dawn:anvil_item_model