schedule function dawn:mobs/sound/6s/earth_elemental 6s

execute as @e[tag=earth_elemental] at @s run playsound dawn:mobs.earth_elemental.say hostile @a ~ ~ ~ 0.4