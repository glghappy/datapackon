
# 获取盔甲基底材质
data modify storage dawn:anvil_item_model armor_material set from block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".material.type

# 获取盔甲基底类型
data modify storage dawn:anvil_item_model armor_type set from block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".item.type

# 获取盔甲内衬
execute if predicate dawn:anvil/material/lining run data modify storage dawn:anvil_item_model lining set from block ~ ~ ~ Items.[{Slot: 13b}].components."minecraft:custom_data".material.type

# 合成物品
execute if predicate dawn:anvil/material/lining run function dawn:anvil/craft/assemble_loot_armor with storage dawn:anvil_item_model
