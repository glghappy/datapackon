scoreboard players add @s dawn.player.neg_level 1
xp add @s -1 levels