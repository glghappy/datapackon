
# Red Zombie 红衣僵尸
summon minecraft:zombie ~ ~ ~ {CustomName: "Red Zombie", Tags: ["summon", "equipment_summon", "red_zombie"], Health: 30.0f, CanBreakDoors: 1b, CanPickUpLoot: 1b, attributes: [{id: "minecraft:max_health", base: 30.0d}, {id: "minecraft:follow_range", base: 128.0d}, {id: "minecraft:attack_damage", base: 7.0d}, {id: "minecraft:movement_speed", base: 0.27d}, {id: "minecraft:armor", base: 3.0d}]}

tp @s ~ -255 ~

kill @s