advancement revoke @s only dawn:enchantment/kinetic_absorption
scoreboard players reset @s dawn.enchantment.kinetic_absorption
