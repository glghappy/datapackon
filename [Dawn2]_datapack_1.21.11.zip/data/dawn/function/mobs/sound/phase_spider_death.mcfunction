
playsound dawn:mobs.phase_spider.death hostile @a ~ ~ ~ 0.5

kill @s