
$execute store result storage dawn:anvil anvil_cost int $(item_repair_multiply) run scoreboard players get @s dawn.anvil.item.operation

$say $(item_repair_multiply)