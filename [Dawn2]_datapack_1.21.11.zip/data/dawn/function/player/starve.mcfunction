damage @s 1 starve by @s
scoreboard players reset @s dawn.player.starve