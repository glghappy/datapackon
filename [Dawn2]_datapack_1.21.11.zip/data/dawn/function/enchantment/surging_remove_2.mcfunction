
advancement revoke @s only dawn:enchantment/surging_remove_2

scoreboard players remove @s dawn.enchantment.surging 8
scoreboard players set @s[scores={dawn.enchantment.surging=..-1}] dawn.enchantment.surging 0
