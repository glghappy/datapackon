
$data merge storage title:io {  \
    text: {"text":"\u$(food_int)","color":"white", "shadow_color":0},  \
    font: "dawn:food",  \
    neg_font: "dawn:food_neg",  \
    x: 52,  y: 29,  \
    align: "middle",  \
    origin: "down"  \
}
function title:new_text
