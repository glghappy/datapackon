
playsound dawn:mobs.ghoul.death hostile @a ~ ~ ~ 0.5

kill @s