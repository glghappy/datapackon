
advancement revoke @s only dawn:enchantment/recuperation_3

scoreboard players add @s dawn.enchantment.recuperation.cd 1080

effect give @s minecraft:fire_resistance 18 0 false

effect give @s minecraft:instant_health 1 3 true

effect give @s minecraft:speed 5 3 true

playsound dawn:enchantment.recuperation player @a ~ ~ ~ 0.8
