# 箭矢速度
execute store result score @s dawn.arrow_motion_0 run data get entity @s Motion[0] 1000000
execute store result score @s dawn.arrow_motion_1 run data get entity @s Motion[1] 1000000
execute store result score @s dawn.arrow_motion_2 run data get entity @s Motion[2] 1000000

execute store result score @s dawn.arrow_motion_x run data get entity @p SelectedItem.components."minecraft:custom_data".arrow_speed
scoreboard players add @s dawn.arrow_motion_x 100

execute unless score @s dawn.arrow_motion_x matches 100 store result entity @s Motion[0] double 0.00000001 run scoreboard players operation @s dawn.arrow_motion_0 *= @s dawn.arrow_motion_x
execute unless score @s dawn.arrow_motion_x matches 100 store result entity @s Motion[1] double 0.00000001 run scoreboard players operation @s dawn.arrow_motion_1 *= @s dawn.arrow_motion_x
execute unless score @s dawn.arrow_motion_x matches 100 store result entity @s Motion[2] double 0.00000001 run scoreboard players operation @s dawn.arrow_motion_2 *= @s dawn.arrow_motion_x

tag @s add tagged
