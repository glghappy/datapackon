
execute if items block ~ ~ ~ container.19 minecraft:coal run return 1
execute if items block ~ ~ ~ container.19 minecraft:lava_bucket run return 1
execute if items block ~ ~ ~ container.19 minecraft:blaze_rod run return 1
execute if items block ~ ~ ~ container.19 *[item_model="dawn:blaze_coal"] run return 1

execute if score @s dawn.smeltery.fuel_level matches 1..4 run return 1
