scoreboard objectives add dawn.effect.poison dummy
