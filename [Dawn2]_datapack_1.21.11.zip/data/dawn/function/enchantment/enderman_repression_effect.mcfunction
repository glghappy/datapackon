
scoreboard players remove @e[scores={dawn.enchantment.enderman_repression=1..}] dawn.enchantment.enderman_repression 1

execute as @e[scores={dawn.enchantment.enderman_repression=1..}] at @s run tp @s @s

execute as @e[scores={dawn.enchantment.enderman_repression=1..}] at @s run particle dust{color:[0.556, 0.373, 0.153], scale:1} ~ ~1 ~ 0.25 0.75 0.25 0.12 1 normal

