
# #


# execute if block ~ ~-1 ~ deepslate if predicate dawn:random/0.1 run return run function dawn:mobs/summon/revenant


# execute if dimension dawn:underworld if predicate dawn:random/0.1 run return run function dawn:mobs/summon/ancient_zombie
# execute if dimension dawn:underworld if predicate dawn:random/0.08 run return run function dawn:mobs/summon/ancient_zombie_guardian
# execute if dimension dawn:underworld if predicate dawn:random/0.06 run return run function dawn:mobs/summon/ancient_zombie_lord



# tag
tag @s add summon


# summon

# Mushroom Zombie 真菌僵尸 (ban_transform)(PersistenceRequired)
execute if dimension dawn:underworld if predicate dawn:random/0.1 run return run function dawn:mobs/summon/mushroom_zombie

# Frozen Zombie 冻尸 (ban_transform)
execute if biome ~ ~ ~ #minecraft:spawns_cold_variant_farm_animals run return run function dawn:mobs/summon/frozen_zombie

# Ghoul 食尸鬼 (ban_transform)(silent)
execute if predicate dawn:location/cave if predicate dawn:random/0.15 run return run function dawn:mobs/summon/ghoul

# Revenant 亡魂 (ban_transform)
execute if predicate dawn:location/deepslate_cave if predicate dawn:random/0.1 run return run function dawn:mobs/summon/revenant

# Earth Elemental C (ban_transform)(equipment)(silent)
execute if predicate dawn:location/stone_cave if predicate dawn:random/0.1 run return run function dawn:mobs/summon/earth_elemental_c
execute if dimension dawn:underworld if predicate dawn:random/0.05 run return run function dawn:mobs/summon/earth_elemental_c

# Earth Elemental O (ban_transform)(equipment)(silent)
execute if predicate dawn:location/deepslate_cave if predicate dawn:random/0.1 run return run function dawn:mobs/summon/earth_elemental_o
execute if dimension dawn:underworld if predicate dawn:random/0.05 run return run function dawn:mobs/summon/earth_elemental_o

# Ancient Zombie 远古僵尸 (ban_transform)
execute if dimension dawn:underworld if predicate dawn:random/0.15 run return run function dawn:mobs/summon/ancient_zombie

# Ancient Zombie Guardian 远古僵尸守卫 (ban_transform)
execute if dimension dawn:underworld if predicate dawn:random/0.08 run return run function dawn:mobs/summon/ancient_zombie_guardian

# Ancient Zombie Lord 远古僵尸领主 (ban_transform)(lord)
execute if dimension dawn:underworld if predicate dawn:random/0.06 run return run function dawn:mobs/summon/ancient_zombie_lord

# Red Zombie 红衣僵尸
execute if dimension dawn:underworld if predicate dawn:random/0.75 run return run function dawn:mobs/summon/red_zombie

# 是血月
execute unless score #day dawn.day matches 1 \
unless score #calculate2 dawn.day matches 1 \
if score #calculate1 dawn.day matches 1 \
run function dawn:mobs/summon/blood_moon_zombie


# attribute
attribute @s minecraft:follow_range base set 64
data modify entity @s CanPickUpLoot set value 1b
data modify entity @s CanBreakDoors set value 1b


# weapon
execute if items entity @s weapon.mainhand iron_sword[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:tool/iron_wooden_sword
execute if items entity @s weapon.mainhand iron_shovel[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:tool/iron_wooden_shovel
