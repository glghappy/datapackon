
# 显示成品

# 复制物品
item replace block ~ ~ ~ container.16 from block ~ ~ ~ container.10

# 修改光效
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:enchantment_glint_override" set value true

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_glow set value true

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
