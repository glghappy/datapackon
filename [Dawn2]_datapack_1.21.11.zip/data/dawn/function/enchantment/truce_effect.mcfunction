
# scoreboard players remove @e[scores={dawn.enchantment.truce=1..}] dawn.enchantment.truce 1

# execute as @e[scores={dawn.enchantment.truce=1..}] run attribute @s attack_damage modifier add truce.attack_damage -1 add_multiplied_total
# execute as @e[scores={dawn.enchantment.truce=0}] run attribute @s attack_damage modifier remove truce.attack_damage

# execute as @e[scores={dawn.enchantment.truce=1..20}] at @s run particle dust{color:[0.709, 0.999, 0.784], scale:1.5} ~ ~1 ~ 0.3 0.55 0.3 0.15 1 normal

# execute as @e[scores={dawn.enchantment.truce=20..}] at @s run particle dust{color:[0.012, 0.573, 0.153], scale:1} ~ ~1 ~ 0.25 0.5 0.25 0.12 1 normal

# —————————————————————————————————————————————————————————————————————————————————————————————————

# by：Minecraft_hyr

scoreboard players remove @e[type=!#dawn:non_living, scores={dawn.enchantment.truce=1..}] dawn.enchantment.truce 1

execute as @e[type=!#dawn:non_living, scores={dawn.enchantment.truce=1..}] at @s run function dawn:enchantment/truce_effect_2
execute as @e[type=!#dawn:non_living, scores={dawn.enchantment.truce=0}] run attribute @s attack_damage modifier remove truce.attack_damage
