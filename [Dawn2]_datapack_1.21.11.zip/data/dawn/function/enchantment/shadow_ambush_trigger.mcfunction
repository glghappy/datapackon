
effect clear @s invisibility