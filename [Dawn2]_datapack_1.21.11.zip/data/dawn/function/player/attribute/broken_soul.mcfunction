
attribute @s minecraft:attack_damage modifier remove broken_soul.attack_damage

$attribute @s minecraft:attack_damage modifier add broken_soul.attack_damage $(broken_soul) add_multiplied_total


attribute @s minecraft:block_break_speed modifier remove broken_soul.block_break_speed

$attribute @s minecraft:block_break_speed modifier add broken_soul.block_break_speed $(broken_soul) add_multiplied_total
