
$data modify block ~ ~ ~ Items.[{Slot:5b}].components."minecraft:item_model" set value "dawn:smeltery_craft_$(craft_show)"
