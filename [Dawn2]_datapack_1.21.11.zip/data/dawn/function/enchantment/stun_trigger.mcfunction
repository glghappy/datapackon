
scoreboard players set @s dawn.enchantment.stun 50
