attribute @s minecraft:attack_speed modifier remove enchantment.frost_shockwave
attribute @s minecraft:movement_speed modifier remove enchantment.frost_shockwave

scoreboard players reset @s[scores={dawn.enchantment.frost_shockwave=0}] dawn.enchantment.frost_shockwave