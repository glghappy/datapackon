
tag @s add sell_1

# 
loot replace entity @s armor.head loot dawn:tool/copper_shears
data modify entity @s Offers.Recipes[{sell:{id:"minecraft:shears"}}].sell set from entity @s equipment.head

item replace entity @s armor.head with air
