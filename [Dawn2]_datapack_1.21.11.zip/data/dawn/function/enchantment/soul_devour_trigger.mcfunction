
execute store result storage dawn:entity soul_devour int 0.25 run attribute @s minecraft:max_health get
