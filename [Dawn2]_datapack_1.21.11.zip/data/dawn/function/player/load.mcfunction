
# —————————————————————————————————————————————————————————————————————————————————————————————————

# attribute
scoreboard objectives add dawn.player.level level
scoreboard objectives add dawn.player.level.operation dummy

# —————————————————————————————————————————————————————————————————————————————————————————————————

# neg_level
scoreboard objectives add dawn.player.death deathCount
scoreboard objectives add dawn.player.neg_level dummy

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 脱战
function dawn:player/disengage/load

# —————————————————————————————————————————————————————————————————————————————————————————————————

# use bow
scoreboard objectives add dawn.player.used_bow minecraft.used:minecraft.bow
scoreboard objectives add dawn.player.used_crossbow minecraft.used:minecraft.crossbow
scoreboard objectives add dawn.arrow_motion_0 dummy
scoreboard objectives add dawn.arrow_motion_1 dummy
scoreboard objectives add dawn.arrow_motion_2 dummy
scoreboard objectives add dawn.arrow_motion_x dummy

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 营养与糖分
scoreboard objectives add dawn.player.protein dummy
scoreboard objectives add dawn.player.phytonutrients dummy
scoreboard objectives add dawn.player.insulin dummy

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 饥饿值调整
scoreboard objectives add dawn.player.foodBar dummy
scoreboard objectives add dawn.player.foodLevel food
scoreboard objectives add dawn.player.foodSaturationLevel dummy
scoreboard objectives add dawn.player.foodLevel_show dummy
scoreboard objectives add dawn.player.foodSaturationLevel_show dummy

# 饥饿伤害
scoreboard objectives add dawn.player.starve dummy

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 自然饥饿与生命回复
scoreboard objectives add dawn.player.natural_hunger dummy
scoreboard objectives add dawn.player.natural_hunger_time dummy
schedule function dawn:player/natural_hunger 1s

scoreboard objectives add dawn.player.natural_regeneration dummy
scoreboard objectives add dawn.player.natural_regeneration_time dummy
schedule function dawn:player/natural_regeneration 1s

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 开场白
execute as @a run function dawn:player/prologue

# —————————————————————————————————————————————————————————————————————————————————————————————————

# stats-trigger
scoreboard objectives add stats trigger
scoreboard objectives add dawn.player.protein2 dummy
scoreboard objectives add dawn.player.phytonutrients2 dummy
scoreboard objectives add dawn.player.insulin2 dummy
scoreboard objectives add dawn.player.value dummy

# —————————————————————————————————————————————————————————————————————————————————————————————————

# time-trigger
scoreboard objectives add time trigger
scoreboard objectives add dawn.time.h dummy
scoreboard players set #1000 dawn.time.h 1000
scoreboard objectives add dawn.time.m dummy
scoreboard players set #17 dawn.time.m 17

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 离开游戏
scoreboard objectives add dawn.player.leave_game minecraft.custom:minecraft.leave_game

# —————————————————————————————————————————————————————————————————————————————————————————————————

# 生命
scoreboard objectives add dawn.player.health health
scoreboard objectives add dawn.player.max_health dummy