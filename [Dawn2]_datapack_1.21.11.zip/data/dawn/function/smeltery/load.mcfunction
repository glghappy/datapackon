
# marker.mcfunction

# （在place中设置初始值为-1）
scoreboard objectives add dawn.smeltery.button dummy

# -------------------------------------------------------------------------------------------------

# item_display.mcfunction

# 燃料部分
scoreboard objectives add dawn.smeltery.fuel_time dummy
scoreboard objectives add dawn.smeltery.fuel_level dummy

# 检测原料 数量/ID 是否变化 变化则重置冶炼炉
scoreboard objectives add dawn.smeltery.count dummy
scoreboard objectives add dawn.smeltery.count_before dummy

# 检测原料体积
scoreboard objectives add dawn.smeltery.input dummy

# 展示可烧制部件
scoreboard objectives add dawn.smeltery.show dummy

# 开始合成
scoreboard objectives add dawn.smeltery.craft_time dummy
scoreboard objectives add dawn.smeltery.craft_finish dummy
scoreboard objectives add dawn.smeltery.craft_calculate dummy
scoreboard objectives add dawn.smeltery.craft_show dummy



# 数量检测
scoreboard objectives add dawn.smeltery.check dummy