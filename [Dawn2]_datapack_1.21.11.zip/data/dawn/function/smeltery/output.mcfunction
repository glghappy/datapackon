
# 清除烧制状态
data modify entity @s item.components."minecraft:custom_data".smelting set value false

# 清除合成时间
scoreboard players set @s dawn.smeltery.craft_time 0

# 清除原料
item replace block ~ ~ ~ container.1 with air

# 掉落物品
data modify storage dawn:smeltery folder set from entity @s item.components."minecraft:custom_data".output_folder
data modify storage dawn:smeltery material set from entity @s item.components."minecraft:custom_data".output_material_2

execute if data entity @s {item:{components:{"minecraft:custom_data":{"output_folder": "nugget"}}}} run data modify storage dawn:smeltery material set from entity @s item.components."minecraft:custom_data".output_material_1
execute if data entity @s {item:{components:{"minecraft:custom_data":{"output_folder": "ingot"}}}} run data modify storage dawn:smeltery material set from entity @s item.components."minecraft:custom_data".output_material_1
execute if data entity @s {item:{components:{"minecraft:custom_data":{"output_folder": "block"}}}} run data modify storage dawn:smeltery material set from entity @s item.components."minecraft:custom_data".output_material_1

data modify storage dawn:smeltery type set from entity @s item.components."minecraft:custom_data".output_type
data modify storage dawn:smeltery count set from entity @s item.components."minecraft:custom_data".output_count

function dawn:smeltery/loot with storage dawn:smeltery

