
# 掉落物品
$loot replace block ~ ~ ~ container.16 loot dawn:double_ingot/$(material)_double_ingot

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_double_ingot set value true

# 记录锤子耐久消耗
$data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_damage set value $(damage)

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
