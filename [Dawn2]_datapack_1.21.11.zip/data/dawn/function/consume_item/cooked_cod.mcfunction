advancement revoke @s only dawn:consume_item/cooked_cod

scoreboard players add @s dawn.player.protein 41080
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000
