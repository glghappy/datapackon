
# loot
loot spawn ~ ~ ~ loot dawn:nugget/vibranium_nugget
# execute if entity @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:crying_obsidian"}}] run function dawn:block/loot2

# kill item
execute as @n[type=item, distance=..2, nbt={OnGround:0b, Age:0s, Item:{id:"minecraft:crying_obsidian"}}] run kill @s

# add time
scoreboard players add @s dawn.meteorite.break 1

# setblock
execute unless score @s dawn.meteorite.break matches 16.. run setblock ~ ~ ~ minecraft:crying_obsidian

# damage player
execute as @a[distance=..16] run damage @s 3 minecraft:freeze
effect give @a[distance=..16] minecraft:slowness 14 2 false
effect give @a[distance=..16] minecraft:mining_fatigue 14 2 false

# check
execute if score @s dawn.meteorite.break matches 16.. run kill @s
