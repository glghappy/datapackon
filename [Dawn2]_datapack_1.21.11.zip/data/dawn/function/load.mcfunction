
# enchantment
function dawn:enchantment/load

# anvil
function dawn:anvil/load

# smeltery
function dawn:smeltery/load

# alloy_smelter
function dawn:alloy_smelter/load

# meteorite
scoreboard objectives add dawn.meteorite.break dummy

# underworld_portal
scoreboard objectives add dawn.portal.underworld.y dummy

# gamerule
function dawn:gamerule/load

# day
function dawn:day/load

# consume_item
scoreboard objectives add dawn.effect.deepslate_heart dummy

# player
function dawn:player/load

# damage
function dawn:damage/load

# consume_item
scoreboard objectives add dawn.locate dummy

# mobs
function dawn:mobs/load

# end_crystal
scoreboard objectives add dawn.end_crystal dummy


# function dawn:crafting_table/load


# function dawn:player_hurt_entity/load

# function dawn:entity_hurt_player/load

# function dawn:underworld_key/load

# function dawn:effect/load

# function dawn:portal/load


# function dawn:sounds/load

# forceload add 20210225 20210225


