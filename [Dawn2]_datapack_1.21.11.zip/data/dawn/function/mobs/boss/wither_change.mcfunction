
tag @s add level2

data modify entity @s Health set value 600
data modify entity @s Invul set value 225
data modify entity @s drop_chances set value {head: 0.0f, mainhand: 0.0f, feet: 0.0f, chest: 0.0f, legs: 0.0f, offhand: 0.0f}



return run function dawn:mobs/boss/crazy_wither