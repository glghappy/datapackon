schedule function dawn:player/natural_regeneration 1s

