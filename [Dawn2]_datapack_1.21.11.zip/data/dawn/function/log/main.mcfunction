data modify storage dawn:log id set from entity @s Item.id
data modify storage dawn:log axis set from entity @s Item.components."minecraft:custom_data".axis
function dawn:log/place with storage dawn:log