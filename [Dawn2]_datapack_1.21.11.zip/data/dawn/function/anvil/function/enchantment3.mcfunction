
# 显示成品

# 复制物品
item replace block ~ ~ ~ container.16 from block ~ ~ ~ container.10

# 附魔
$item modify block ~ ~ ~ container.16 dawn:enchantment/$(enchantment)

# 记录耗材
$data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_cost set value $(count)

# 减少强化槽
scoreboard objectives add dawn.anvil.item.enhancement dummy
execute store result score @s dawn.anvil.item.enhancement run data get block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".enhancement_slot
execute store result storage dawn:input enhancement int 1 run scoreboard players remove @s dawn.anvil.item.enhancement 1
data modify block ~ ~ ~ Items.[{Slot: 16b}].components."minecraft:custom_data".enhancement_slot set from storage dawn:input enhancement

# 修改强化槽
function dawn:anvil/function/modify_enhancement_slot with storage dawn:input

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_enchantment set value true

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
