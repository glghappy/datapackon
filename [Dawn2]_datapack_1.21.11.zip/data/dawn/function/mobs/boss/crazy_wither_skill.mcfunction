
tag @s add tagged

data modify entity @s acceleration_power set value 0.2

summon fireball ~ ~ ~

data modify entity @n[type=fireball] Motion set from entity @s Motion
data modify entity @n[type=fireball] UUID set from entity @s UUID
data modify entity @n[type=fireball] acceleration_power set value 0.1