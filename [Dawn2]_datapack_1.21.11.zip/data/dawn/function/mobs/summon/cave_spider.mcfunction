
#
tag @s add summon

#
attribute @s max_health base set 6
data modify entity @s Health set value 6