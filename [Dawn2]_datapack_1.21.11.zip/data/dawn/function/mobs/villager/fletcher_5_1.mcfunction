
data modify entity @s Offers.Recipes[-1] set value {maxUses:3, sell:{count:1, id:"minecraft:stone"}, buy:{count:24, id:"minecraft:emerald"}, priceMultiplier: 0.05f, xp:30}
loot replace entity @s armor.head loot dawn:bow/mithril_bow
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head
