
execute if items block ~ ~ ~ container.1 minecraft:copper_ingot run return 90
execute if items block ~ ~ ~ container.1 minecraft:raw_copper run return 90
execute if items block ~ ~ ~ container.1 minecraft:copper_ore run return 90
execute if items block ~ ~ ~ container.1 minecraft:deepslate_copper_ore run return 90

execute if items block ~ ~ ~ container.1 #minecraft:copper_door run return 180

execute if items block ~ ~ ~ container.1 #minecraft:copper_trapdoor run return 270

execute if items block ~ ~ ~ container.1 #minecraft:cut_copper_slab run return 360

execute if items block ~ ~ ~ container.1 #minecraft:copper_bulb run return 540

execute if items block ~ ~ ~ container.1 minecraft:raw_copper_block run return 810
execute if items block ~ ~ ~ container.1 #minecraft:copper_block run return 810
execute if items block ~ ~ ~ container.1 #minecraft:chiseled_copper run return 810
execute if items block ~ ~ ~ container.1 #minecraft:copper_grate run return 810
execute if items block ~ ~ ~ container.1 #minecraft:cut_copper run return 810
execute if items block ~ ~ ~ container.1 #minecraft:cut_copper_stairs run return 810
