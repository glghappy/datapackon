
scoreboard players add @s dawn.enchantment.feral_fury.effect 1
scoreboard players set @s[scores={dawn.enchantment.feral_fury.effect=30..}] dawn.enchantment.feral_fury.effect 30

scoreboard players set @s dawn.enchantment.feral_fury.time 800
