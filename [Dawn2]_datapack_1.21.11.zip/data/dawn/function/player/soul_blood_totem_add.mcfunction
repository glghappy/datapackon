clear @s zombie_head 1

execute unless items entity MC_HeYeJun weapon.offhand * run return run loot replace entity @s weapon.offhand loot dawn:soul_blood_totem

execute if items entity MC_HeYeJun weapon.offhand * run loot spawn ~ ~ ~ loot dawn:soul_blood_totem