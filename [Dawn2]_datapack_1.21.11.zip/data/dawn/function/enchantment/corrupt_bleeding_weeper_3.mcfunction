
scoreboard players add @s dawn.entity.corrupt_bleeding_weeper 1

execute if score @s dawn.entity.corrupt_bleeding_weeper matches 200.. run function dawn:enchantment/corrupt_bleeding_weeper_4

effect give @e[type=#minecraft:undead, distance=..24] fire_resistance 9 0 false