execute if items block ~ ~ ~ container.1 *[custom_data~{material:{type:"ancient_metal"}}] run return 1

execute if items block ~ ~ ~ container.1 *[custom_data~{material:{type:"ancient_metal_chainmail"}}] run return 1