
# tag
tag @s add summon


# summon
execute if dimension minecraft:the_nether if predicate dawn:random/0.08 run return run function dawn:mobs/summon/ancient_wither_skeleton_lord


# attribute
attribute @s minecraft:max_health base set 12
data modify entity @s Health set value 12
attribute @s minecraft:attack_damage base set 7


# weapon
execute if items entity @s weapon.mainhand stone_sword[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.mainhand loot dawn:weapon/wither_skeleton
execute if items entity @s weapon.offhand stone_sword[!custom_data~{"mod_id": "dawn"}] run loot replace entity @s weapon.offhand loot dawn:weapon/wither_skeleton
