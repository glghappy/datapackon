# place item_display and barrel
execute as @e[tag=dawn.anvil, type=glow_item_frame] at @s run function dawn:anvil/place

# marker
execute as @e[tag=dawn.anvil, type=marker] at @s unless predicate dawn:anvil/gui run function dawn:anvil/marker

# item_display (break)
execute as @e[tag=dawn.anvil, type=item_display] at @s run function dawn:anvil/item_display
