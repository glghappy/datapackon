
# 掉落物品
$loot replace block ~ ~ ~ container.16 loot dawn:armor/$(armor_material)_$(lining)_$(armor_type)

# 记录成功
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".temp_craft set value true

# 无法取出
data modify block ~ ~ ~ Items[{Slot:16b}].components."minecraft:custom_data".dawn_clear set value true
