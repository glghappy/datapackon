
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:stone"}, buy:{count:6, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:5}
loot replace entity @s armor.head loot dawn:tool/iron_wooden_mattock
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head
