
scoreboard players reset @s dawn.enchantment.blessing_of_water

effect give @s minecraft:regeneration 1 2 true

particle dust{color:[0.992, 0.380, 0.420], scale:1} ~ ~.5 ~ 0.55 0.55 0.55 0 10 normal

particle dust{color:[0.384, 0.933, 0.992], scale:1.2} ~ ~.5 ~ 0.55 0.55 0.55 0 10 normal
