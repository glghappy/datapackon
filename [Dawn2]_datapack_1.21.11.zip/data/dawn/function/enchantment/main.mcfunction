
# truce
function dawn:enchantment/truce_effect

# surging
execute as @a at @s run function dawn:enchantment/surging_main

# enderman_repression
function dawn:enchantment/enderman_repression_effect

# stun
function dawn:enchantment/stun_effect

# momentum
execute as @a run function dawn:enchantment/momentum_effect

# feral_fury
execute as @a run function dawn:enchantment/feral_fury_effect

# frost_shockwave
function dawn:enchantment/frost_shockwave_effect

# dash
execute as @a run function dawn:enchantment/dash_effect

# free_action
