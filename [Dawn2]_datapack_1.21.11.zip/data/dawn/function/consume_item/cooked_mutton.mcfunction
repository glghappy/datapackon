advancement revoke @s only dawn:consume_item/cooked_mutton

scoreboard players add @s dawn.player.protein 60528
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000
