
# 获取材质
data modify storage dawn:anvil_item_model head_material set from block ~ ~ ~ Items.[{Slot: 10b}].components."minecraft:custom_data".material.type

# 检测材质是否相同 并 合成物品
function dawn:anvil/craft/assemble_main_shears_check with storage dawn:anvil_item_model

