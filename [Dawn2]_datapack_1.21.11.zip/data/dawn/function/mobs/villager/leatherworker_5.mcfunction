
tag @s add sell_5

# 9
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:leather_horse_armor"}, buy:{count:6, id:"minecraft:emerald"}, priceMultiplier: 0.05f, xp:30}

# 10
data modify entity @s Offers.Recipes[-1] set value {maxUses:12, sell:{count:1, id:"minecraft:saddle"}, buy:{count:6, id:"minecraft:emerald"}, priceMultiplier: 0.05f, xp:30}