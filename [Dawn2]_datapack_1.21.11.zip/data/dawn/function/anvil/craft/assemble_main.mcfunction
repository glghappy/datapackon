
# 合成工具
execute if predicate dawn:anvil/input/component run function dawn:anvil/craft/assemble_main_tool

# # 合成剪刀
# execute if predicate dawn:anvil/input/component run function dawn:anvil/craft/assemble_main_tool

# 合成盔甲
execute if predicate dawn:anvil/input/plating run function dawn:anvil/craft/assemble_main_armor

# 合成弓
execute if predicate dawn:anvil/input/bow_limb if predicate dawn:anvil/material/bow_string run function dawn:anvil/craft/assemble_main_bow


# 合成剪刀
execute \
    if items block ~ ~ ~ container.10 *[custom_data~{item:{"category": "component", "type": "knife"}}] \
    if items block ~ ~ ~ container.13 *[custom_data~{item:{"category": "component", "type": "knife"}}] \
run function dawn:anvil/craft/assemble_main_shears

