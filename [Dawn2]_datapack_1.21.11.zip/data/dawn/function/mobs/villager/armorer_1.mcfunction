
tag @s add sell_1

# 1
data modify entity @s Offers.Recipes[-2] set value {maxUses:12, sell:{count:1, id:"minecraft:emerald"}, buy:{count:15, id:"minecraft:coal"}, priceMultiplier: 0.05f, demand:-16, xp:2}

# 2
function dawn:mobs/villager/armorer_1_1
execute if predicate dawn:random/0.5 run function dawn:mobs/villager/armorer_1_2

item replace entity @s armor.head with air
