
attribute @s minecraft:max_health modifier remove soul_blood_totem
$attribute @s minecraft:max_health modifier add soul_blood_totem $(soul_blood_totem) add_value