
# by：Minecraft_hyr

execute if predicate dawn:entity/poison/0 run return run scoreboard players add @s dawn.effect.poison 10
execute if predicate dawn:entity/poison/1 run return run scoreboard players add @s dawn.effect.poison 22
execute if predicate dawn:entity/poison/2 run return run scoreboard players add @s dawn.effect.poison 43
execute if predicate dawn:entity/poison/3 run return run scoreboard players add @s dawn.effect.poison 85
execute if predicate dawn:entity/poison/4 run return run scoreboard players add @s dawn.effect.poison 250
