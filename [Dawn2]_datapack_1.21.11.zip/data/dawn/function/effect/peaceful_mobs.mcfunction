particle minecraft:heart ~ ~1 ~ 0.5 0.5 0.5 0 2 normal
effect give @s regeneration 2 2 true