advancement revoke @s only dawn:consume_item/vegetable_soup

scoreboard players add @s dawn.player.phytonutrients 22496
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
