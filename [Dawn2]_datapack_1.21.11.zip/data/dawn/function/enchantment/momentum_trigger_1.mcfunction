
scoreboard players set @s dawn.enchantment.momentum 25
scoreboard players set @s dawn.enchantment.momentum.time 21
