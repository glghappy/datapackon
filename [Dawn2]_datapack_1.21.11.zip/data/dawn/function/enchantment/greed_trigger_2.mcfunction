
effect give @s minecraft:wither 12 1 false
