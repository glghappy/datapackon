
# 获取损坏值 （dawn.anvil.item.damage）
scoreboard objectives add dawn.anvil.item.damage dummy
execute store result score @s dawn.anvil.item.damage run data get block ~ ~ ~ Items[{Slot:10b}].components."minecraft:damage"

# 需要修复
# execute if score @s dawn.anvil.item.damage matches 1.. run say need
# execute if score @s dawn.anvil.item.damage matches 1 run say nonono
execute if score @s dawn.anvil.item.damage matches 1.. run function dawn:anvil/function/repair2