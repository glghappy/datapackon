advancement revoke @s only dawn:consume_item/chicken_soup

scoreboard players add @s dawn.player.protein 66550
scoreboard players set @s[scores={dawn.player.protein=160000..}] dawn.player.protein 160000

scoreboard players add @s dawn.player.phytonutrients 7394
scoreboard players set @s[scores={dawn.player.phytonutrients=160000..}] dawn.player.phytonutrients 160000
