
tag @s add sell_5

# 9
data modify entity @s Offers.Recipes[-2] set value {maxUses:3, sell:{count:1, id:"minecraft:stone"}, buy:{count:16, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:30}
loot replace entity @s armor.head loot dawn:tool/mithril_wooden_sword
data modify entity @s Offers.Recipes[-2].sell set from entity @s equipment.head

# 10
data modify entity @s Offers.Recipes[-1] set value {maxUses:3, sell:{count:1, id:"minecraft:stone"}, buy:{count:24, id:"minecraft:emerald"}, priceMultiplier: 0.2f, xp:30}
loot replace entity @s armor.head loot dawn:tool/mithril_wooden_pickaxe
data modify entity @s Offers.Recipes[-1].sell set from entity @s equipment.head

item replace entity @s armor.head with air
