
# 重置烧炼状态
data modify entity @s item.components."minecraft:custom_data".smelting set value false
